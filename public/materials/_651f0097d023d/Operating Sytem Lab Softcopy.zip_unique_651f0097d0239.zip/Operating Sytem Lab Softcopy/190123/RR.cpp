#include "bits/stdc++.h"
using namespace std;
 
#define br cout<<"\n"
/*DEBUG*/
template <class T>
void what(T t) 
{
    cout<< " "<<t <<endl ;
}
template<class T,class... Args>
void what(T t,Args... args)
{
    cout<<" "<<t<<"; ";
    what(args...);
}
 
/*STL definations*/
#define pb push_back
 
typedef long long ll; // comments that are mixed in with code
typedef pair<int, int> ii; // are aligned to the right like this
typedef vector<ii> vii;
typedef vector<int> vi;
#define INF 1000000000 // 1 billion, safer than 2B for Floyd Warshall’s
 
#define FOR(i,n) for(int i=0;i<n;i++)
#define FROM(a,i,n) for(int i=a;i<n;i++)
#define vin(macroVec) for(auto &macroA:macroVec) cin>>macroA;
 
/*Output macros*/
#define YES cout<<"YES\n";
#define NO cout<<"NO\n";
#define printCase(ck) cout<<"Case "<<ck<<": ";
 struct job{
 	int at,bt,btp,rf;
 };
 
 bool cmp(job &a,job &b){
 	return a.at<b.at;
 }
void solve(){
	vector <job> jobs;
	int n,k;
	cin>>n>>k;
	FOR(i,n){
		int at,bt;
		cin>>at>>bt;
		job j;
		j.at=at;
		j.bt=bt;
		j.btp=bt;
		j.rf=0;
		jobs.pb(j);
	}
	sort(jobs.begin(),jobs.end(),cmp);
	
	int t=0,p=0;
	queue <job> q;
	for(auto a:jobs) q.push(a);
	double wait_t=0;
	while(true){
		if(q.size()==0) break;
		// while(p<jobs.size()&&jobs[p].at<=t){
			// what(jobs[p].at,"INSERTED");
			// q.push(jobs[p++]);
		// }
		t++;
		if(q.size()>0&&q.front().at<=t){
			what("Running ",q.front().at);
			q.front().rf++;
			q.front().btp--;
			if(q.front().btp==0){
				cout<<"WITH AT: "<<q.front().at<<" ENDS AT "<<t<<" TAT: "<<t-q.front().at;br;
				wait_t+=t-q.front().at-q.front().bt;
				q.pop();
			}else{
				if(q.front().rf==k){
					q.front().rf=0;
					//what(q.front().at,"RUN for ",t);
					q.push(q.front());
					q.pop();
				}else{
					//run again
				}
			}
		}
	}
	
	cout<<wait_t/jobs.size();br;
	
	
 }
int main(){
	solve();
}