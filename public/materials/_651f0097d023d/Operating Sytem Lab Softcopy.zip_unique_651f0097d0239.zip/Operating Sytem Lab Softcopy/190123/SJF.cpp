#include "bits/stdc++.h"
using namespace std;
 
class Compare {
    public:
       bool operator()(pair <int,int> a, pair<int,int> b){
           return a.second>b.second;
      }
};
void solve(){
	int n;
	cin>>n;
	vector <pair<int,int>> v(n);
	for(auto &a:v){
		cin>>a.first>>a.second;
	}
	sort(v.begin(),v.end());
	priority_queue <pair<int,int>,vector <pair<int,int>>,Compare> pq;
	int exe=0;
	double tw=0;
	for(int i=0;i<n||!pq.empty();){
		if(pq.empty()){
			pq.push(v[i]);
			i++;
		}
		pair <int,int> j=pq.top();
		pq.pop();
		exe=max(j.first,exe);
		exe+=j.second;
		while(i<n&&v[i].first<=exe){
			pq.push(v[i]);
			i++;
		}
		int tat=exe-j.first;
		int wt=tat-j.second;
		tw+=wt;
		//what(j.first,j.second,":",tat,wt,exe);
	}
	cout<<tw/n<<endl;
 }
int main(){
	solve();
}