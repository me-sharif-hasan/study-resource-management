import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) throws Exception{
        Queue <String> q=new ArrayDeque<>();
        for(int i=0;i<100;i++){
            if((i/10)%2==1){
                Producer p=new Producer(q);
                p.start();
                TimeUnit.MILLISECONDS.sleep(1000);
            }else{
                Consumer c=new Consumer(q);
                c.start();
                TimeUnit.MILLISECONDS.sleep(1000);
            }
        }
    }
}
