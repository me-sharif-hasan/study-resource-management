import java.sql.Time;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

public class Producer extends Common{
    Queue <String> q;
    public Producer(Queue <String> queue){
        q=queue;
    }
    public void run(){
        Empty.p(this);
        while (paused);
        BinarySemaphore.p(this);
        while (paused);
        produce();
        BinarySemaphore.v();
        Full.v();
    }
    static int itemid=1;
    public void produce(){
        q.add("This is a item. id= "+itemid);
        System.out.println(itemid+" produced!");
        itemid++;
    }
}
