public class Common extends Thread{
    volatile boolean paused=false;
    public void pause(){
        paused=true;
    }
    public void go(){
        paused=false;
    }
}
