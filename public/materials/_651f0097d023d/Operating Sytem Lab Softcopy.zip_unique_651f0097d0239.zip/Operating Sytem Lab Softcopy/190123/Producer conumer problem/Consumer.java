import java.util.Queue;

public class Consumer extends Common{
        Queue<String> q;
        public Consumer(Queue <String> queue){
            q=queue;
        }
        public void run(){
            Full.p(this);
            while (paused);
            BinarySemaphore.p(this);
            while (paused);
            consume();
            BinarySemaphore.v();
            Empty.v();
        }

        public void consume(){
            String r=q.peek();
            q.remove();
            System.out.println(r+" consumed!");
        }

}
