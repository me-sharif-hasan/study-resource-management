import java.util.ArrayDeque;
import java.util.Queue;

public class Empty {
    public static int s=5;
    public static Queue<Common> q=new ArrayDeque<>();
    public static void p(Common c){
        s-=1;
        if(s<0){
            c.pause();
            q.add(c);
            System.out.println("Producer Thread "+c.threadId()+" blocked! ");
        }
    }

    public static void v(){
        s+=1;
        if(s<=0){
            Common c=q.peek();
            assert c != null;
            q.remove();
            c.go();
            System.out.println("Producer Thread "+c.threadId()+" resumed! ");
        }
    }
}
