#include "bits/stdc++.h"
using namespace std;
 
#define br cout<<"\n"
/*DEBUG*/
template <class T>
void what(T t) 
{
    cout<< " "<<t <<endl ;
}
template<class T,class... Args>
void what(T t,Args... args)
{
    cout<<" "<<t<<"; ";
    what(args...);
}
 
/*STL definations*/
#define pb push_back
 
typedef long long ll; // comments that are mixed in with code
typedef pair<int, int> ii; // are aligned to the right like this
typedef vector<ii> vii;
typedef vector<int> vi;
#define INF 1000000000 // 1 billion, safer than 2B for Floyd Warshall’s
 
#define FOR(i,n) for(int i=0;i<n;i++)
#define FROM(a,i,n) for(int i=a;i<n;i++)
#define vin(macroVec) for(auto &macroA:macroVec) cin>>macroA;
 
/*Output macros*/
#define YES cout<<"YES\n";
#define NO cout<<"NO\n";
#define printCase(ck) cout<<"Case "<<ck<<": ";
 struct job{
 	int at,bt,ct,tbt;
 };
void solve(){
	int n,k;
	cin>>n>>k;
	
	queue <job> q;
	map <int,stack<job>> mp;
	
	FOR(i,n){
		job j;
		cin>>j.at>>j.bt;
		j.tbt=j.bt;
		mp[j.at].push(j);
	}
	vector <job> jobs;
	int t=0;
	while(true){
		if(n<=0&&q.empty()) break;
		if(mp[t].size()>0){
			q.push(mp[t].top());
			mp[t].pop();
			n--;
		}
		bool poped=0;
		FOR(i,k){
			if(!q.empty()){
				q.front().bt--;
				if(q.front().bt<=0){
					q.front().ct=t+1;
					//what(q.front().at,q.front().tbt,q.front().ct);
					jobs.pb(q.front());
					q.pop();
					poped=1;
				}
			}
			t++;
			if(mp[t].size()>0){
				q.push(mp[t].top());
				mp[t].pop();
				n--;
			}
		}
		if(!poped){
			q.push(q.front());
			q.pop();
		}
	}
	
	double tw=0;
	for(auto a:jobs){
		int tat=a.ct-a.at;
		int wt=tat-a.tbt;
		tw+=wt;
		//what(a.at,a.tbt,tat,wt);
	}
	cout<<tw/jobs.size()<<endl;
 }
int main(){
	solve();
}