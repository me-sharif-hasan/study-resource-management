#include "bits/stdc++.h"
using namespace std;

#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
 
#define br cout<<"\n"
/*DEBUG*/
template <class T>
void what(T t) 
{
    cout<< " "<<t <<endl ;
}
template<class T,class... Args>
void what(T t,Args... args)
{
    cout<<" "<<t<<"; ";
    what(args...);
}
 
/*STL definations*/
#define pb push_back
 
typedef long long ll; // comments that are mixed in with code
typedef pair<int, int> ii; // are aligned to the right like this
typedef vector<ii> vii;
typedef vector<int> vi;
#define INF 1000000000 // 1 billion, safer than 2B for Floyd Warshall’s

typedef tree<int, null_type, less<int>, rb_tree_tag,
             tree_order_statistics_node_update> ordered_multiset;
 
#define FOR(i,n) for(int i=0;i<n;i++)
#define FROM(a,i,n) for(int i=a;i<n;i++)
#define vin(macroVec) for(auto &macroA:macroVec) cin>>macroA;
 
/*Output macros*/
#define YES cout<<"YES\n";
#define NO cout<<"NO\n";
#define printCase(ck) cout<<"Case "<<ck<<": ";
 
 void firstFit(int memoryHoles[], int m, int requiredMemorySizes[], int n){
	int allocationMatrixMatrix[n];
	memset(allocationMatrixMatrix, -1, sizeof(allocationMatrixMatrix));
	for (int i = 0; i < n; i++){
		for (int j = 0; j < m; j++){
			if (memoryHoles[j] >= requiredMemorySizes[i]){
				allocationMatrixMatrix[i] = j;
				memoryHoles[j] -= requiredMemorySizes[i];
				break;
			}
		}
	}

	cout << "\nPricess ID.\tProcess Size\tMemory Block.\n";
	for (int i = 0; i < n; i++){
		cout << " " << i+1 << "\t\t"
			<< requiredMemorySizes[i] << "\t\t";
		if (allocationMatrixMatrix[i] != -1)
			cout << allocationMatrixMatrix[i] + 1;
		else
			cout << "Not Allocated";
		cout << endl;
	}
}


void bestFit(int memoryHoles[], int m, int requiredMemorySizes[], int n) 
{ 
    int allocationMatrix[n]; 
    for (int i = 0; i < n; i++) 
        allocationMatrix[i] = -1; 
    for (int i = 0; i < n; i++) { 
        int found = -1; 
        for (int j = 0; j < m; j++)  { 
            if (memoryHoles[j] >= requiredMemorySizes[i]) { 
                if (found == -1) 
                    found = j; 
                else if (memoryHoles[found] > memoryHoles[j]) 
                    found = j; 
            } 
        } 
        if (found != -1) { 
            allocationMatrix[i] = found; 
            memoryHoles[found] -= requiredMemorySizes[i]; 
        } 
    } 
  
    cout << "\nPricess ID.\tProcess Size\t\n"; 
    for (int i = 0; i < n; i++) 
    { 
        cout << " " << i+1 << "\t\t" << requiredMemorySizes[i] << "\t\t"; 
        if (allocationMatrix[i] != -1) 
            cout << allocationMatrix[i] + 1; 
        else
            cout << "Not Allocated"; 
        cout << endl; 
    } 
} 
 
 
 void worstFit(int memoryHoles[], int m, int requiredMemorySizes[],int n) 
{ 
    int allocationMatrix[n]; 
    memset(allocationMatrix, -1, sizeof(allocationMatrix)); 
    for (int i=0; i<n; i++){ 
        int foundindex = -1; 
        for (int j=0; j<m; j++){ 
            if (memoryHoles[j] >= requiredMemorySizes[i]) 
            { 
                if (foundindex == -1) 
                    foundindex = j; 
                else if (memoryHoles[foundindex] < memoryHoles[j]) 
                    foundindex = j; 
            } 
        } 
        if (foundindex != -1) { 
            allocationMatrix[i] = foundindex; 
            memoryHoles[foundindex] -= requiredMemorySizes[i]; 
        } 
    } 
  
    cout << "\nPricess ID.\tProcess Size\tMemory Block.\n"; 
    for (int i = 0; i < n; i++) 
    { 
        cout << "   " << i+1 << "\t\t" << requiredMemorySizes[i] << "\t\t"; 
        if (allocationMatrix[i] != -1) 
            cout << allocationMatrix[i] + 1; 
        else
            cout << "Not Allocated"; 
        cout << endl; 
    } 
} 

void solve(){
	int n;
	cout<<"Number of holes: ";
	cin>>n;
	int memhole[n];
	cout<<"Enter the holes: ";
	for(auto &a:memhole) cin>>a;
	int m;
	cout<<"Enter number of process: ";
	cin>>m;
	int processes[m];
	cout<<"Process size: ";
	for(auto &a:processes) cin>>a;
	
	int op;
	while(true){
		cout<<"Choose algorithm:\n(1) first fit\n(2)best fit\n(3) worst fit\n(-1) break";
		cin>>op;
		if(op==-1) break;
		if(op==1) firstFit(memhole,n,processes,m);
		else if(op==2) bestFit(memhole,n,processes,m);
		else if(op==3) worstFit(memhole,n,processes,m);
	}
 }
int main(){
	solve();
}