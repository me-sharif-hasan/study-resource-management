#include "bits/stdc++.h"
using namespace std;

 
 long long bpow(long long a,long long b,long long n){
 	if(b==0) return 1;
 	long long x=bpow(a,b/2,n)%n;
 	long long d=(x*x)%n;
 	if(b%2==1) d=(d*a)%n;
 	return d;
 }
 
void solve(){
	long long p=7,q=13;
	long long n=p*q;
	long long d=(p-1)*(q-1);
	
	long long ke=0;
	for(long long i=5;i>1;i--){
		if(__gcd(i,d)==1){
			ke=i;
			break;
		}
	}
	
	long long kd=0;
	for(long long i=100;i>1;i--){
		if((ke*i)%d==1){
			kd=i;
			break;
		}
	}
	
	
	long long m=69;
	long long c=bpow(m,ke,n);
	
	long long rm=bpow(c,kd,n);
	
	printf("Public key=%d\nPrivate key=%d\nN=%d\nMessage=%d\nCyphertext=%d\nDecryption proof=%d\n",ke,kd,n,m,c,rm);
	
 }
int main(){
	solve();
}