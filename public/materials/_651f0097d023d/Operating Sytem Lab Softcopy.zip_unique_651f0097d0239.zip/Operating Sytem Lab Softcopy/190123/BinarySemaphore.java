import java.util.ArrayDeque;
import java.util.Queue;

public class BinarySemaphore {
    static boolean s=true;
    static Queue <Common> q=new ArrayDeque<>();
    public static void p(Common c){
        if(!s){
            c.pause();
            q.add(c);
            System.out.println("Thread "+c.threadId()+" blocked!");
        }else{
            s=false;
        }
    }

    public static void v(){
        if(!q.isEmpty()){
            Common c=q.peek();
            q.remove();
            c.go();
            System.out.println("Thread "+c.threadId()+" resumed!");
        }else{
            s=true;
        }
    }
}
