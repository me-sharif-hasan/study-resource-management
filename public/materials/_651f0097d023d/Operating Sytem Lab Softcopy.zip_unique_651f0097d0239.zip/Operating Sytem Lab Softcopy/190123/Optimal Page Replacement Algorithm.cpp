#include "bits/stdc++.h"
using namespace std;

#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
 
#define br cout<<"\n"
/*DEBUG*/
template <class T>
void what(T t) 
{
    cout<< " "<<t <<endl ;
}
template<class T,class... Args>
void what(T t,Args... args)
{
    cout<<" "<<t<<"; ";
    what(args...);
}
 
/*STL definations*/
#define pb push_back
 
typedef long long ll; // comments that are mixed in with code
typedef pair<int, int> ii; // are aligned to the right like this
typedef vector<ii> vii;
typedef vector<int> vi;
#define INF 1000000000 // 1 billion, safer than 2B for Floyd Warshall’s

typedef tree<int, null_type, less<int>, rb_tree_tag,
             tree_order_statistics_node_update> ordered_multiset;
 
#define FOR(i,n) for(int i=0;i<n;i++)
#define FROM(a,i,n) for(int i=a;i<n;i++)
#define vin(macroVec) for(auto &macroA:macroVec) cin>>macroA;
 
/*Output macros*/
#define YES cout<<"YES\n";
#define NO cout<<"NO\n";
#define printCase(ck) cout<<"Case "<<ck<<": ";
 
void solve(){
	int n;
	cout<<"Length of page request string: ";
	cin>>n;
	vector <int> v(n);
	vin(v);
	int ps;
	cout<<"Number of frames: ";
	cin>>ps;
	br;
	
	int pages[n][ps];
	for(auto &a:pages){
		for(auto &b:a) b=-1;
	}
	
	double hit=0;
	FOR(i,n){
		bool found=0;
		if(i>0){
			FOR(j,ps){
				pages[i][j]=pages[i-1][j];
			}
		}
		
		// for(auto a:pages[i]) cout<<a<<" ";br;
		for(auto a:pages[i]){
			if(a==v[i]){
				found=1;
				break;
			}
		}
		if(found) hit++;
		else{
			int idx=0;
			map <int,int> usedLog;
			FOR(j,ps){
				usedLog[j]=INT_MAX;
				FROM(i,k,n){
					if(v[k]==pages[i][j]){
						usedLog[j]=k;
						break;
					}
				}
			}
			
			FOR(j,ps){
				if(usedLog[idx]<usedLog[j]) idx=j;
			}
			
			pages[i][idx]=v[i];
			
		}
	}
	
	// what(hit);
	cout<<"Hit ratio: "<<hit/n<<" and miss ratio: "<<(n-hit)/n<<endl;
	
 }
int main(){
	solve();
}