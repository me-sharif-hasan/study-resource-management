#include "bits/stdc++.h"
using namespace std;
 
#define br cout<<"\n"
/*DEBUG*/
template <class T>
void what(T t) 
{
    cout<< " "<<t <<endl ;
}
template<class T,class... Args>
void what(T t,Args... args)
{
    cout<<" "<<t<<"; ";
    what(args...);
} 
 
/*STL definations*/
#define pb push_back
 
typedef long long ll; // comments that are mixed in with code
typedef pair<int, int> ii; // are aligned to the right like this
typedef vector<ii> vii;
typedef vector<int> vi;
#define INF 1000000000 // 1 billion, safer than 2B for Floyd Warshall’s
 
#define FOR(i,n) for(int i=0;i<n;i++)
#define FROM(a,i,n) for(int i=a;i<n;i++)
#define vin(macroVec) for(auto &macroA:macroVec) cin>>macroA;
 
/*Output macros*/
#define YES cout<<"YES\n";
#define NO cout<<"NO\n";
#define printCase(ck) cout<<"Case "<<ck<<": ";
 
void solve(){
	int n,m;
	cout<<"Number of resource and number of process\n";
	cin>>n>>m;
	vector <vector<int>> alloc(m,vector <int>(n)),maxNeed(m,vector<int>(n));
	cout<<"Input allocation matrix:\n";
	for(auto &a:alloc){
		cout<<"Input "<<a.size()<<" numbers\n";
		for(auto &b:a) cin>>b;
	}
	cout<<"Input max needs:\n";
	FOR(i,maxNeed.size()){
		cout<<"Input "<<maxNeed.front().size()<<" numbers\n";
		FOR(j,maxNeed.front().size()){
			int x;
			cin>>x;
			maxNeed[i][j]=x-alloc[i][j];
		}
	}
	cout<<"Input max instances of resources\n";
	vector <int> mxi(n),available(n,0);
	for(auto &a:mxi) cin>>a;
// 		
	// for(auto a:alloc){
		// for(auto b:a)cout<<b<<" ";br;
	// }	
	
	FOR(i,n){
		int sum=0;
			FOR(j,m){
				sum+=alloc[j][i];
			}
		available[i]=mxi[i]-sum;
	}
	// for(auto a:available) cout<<a<<" ";br;
	
	
	bool mark[maxNeed.size()]={0};
	bool brk=0;
	vector <int> seq;
	while(true){
		//calculate available
		

		brk=0;
		FOR(j,maxNeed.size()){
			if(mark[j]) continue;
			bool ok=true;
			FOR(i,maxNeed[j].size()){
				if(available[i]<maxNeed[j][i]){
					ok=false;
					break;
				}
			}
			if(ok){
				// cout<<"Doing "<<j<<" th job\n";
				seq.pb(j);
				brk=1;
				mark[j]=true;
				FOR(i,maxNeed[j].size()){
					available[i]+=alloc[j][i];
				}
				// for(auto a:alloc[j]) cout<<a<<" ";br;
				// for(auto a:available){
					// cout<<a<<" ";
				// }br;
			}
		}
		if(!brk) break;
	}
	
	if(seq.size()!=m){
			cout<<"Not safe\n";
			return;
		}
	for(auto a:seq) cout<<a<<" ";br;
	
 }
int main(){
	solve();
}