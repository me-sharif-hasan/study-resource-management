#include <bits/stdc++.h>
using namespace std;

int main(){
	vector <pair<int,int>> vp;
	int n;
	cout<<"Number of process\n";
	cin>>n;
	for(int i=0;i<n;i++){
		int at,bt;
		cout<<"Arival time and brust time: ";
		cin>>at>>bt;
		vp.push_back({at,bt});
	}
	cout<<endl;
	sort(vp.begin(),vp.end());
	int p=1;
	int crnt_time=0;
	double wait=0;
	for(auto a:vp){
		crnt_time=max(a.first,crnt_time);
		cout<<"P"<<p++<<" Begins execution at: "<<crnt_time<<" ";
		crnt_time+=a.second;
		cout<<"Completation time: "<<crnt_time<<" ";
		int tat=crnt_time-a.first;
		cout<<"Turn around time: "<<tat<<" ";
		int waiting_time=tat-a.second;
		cout<<"Waiting time :"<<waiting_time<<"\n";
		wait+=waiting_time;
	}
	cout<<"Average waiting time: "<<wait/(p-1)<<endl;
}