#include<bits/stdc++.h>
using namespace std;

int main()
{
    queue<string>buffer;
    int index=0,n,op;
    string var;
    cout<<"There are options: "<<endl<<"1.Produce"<<endl<<"2.Consume"<<endl<<"3.Exit"<<endl;
    while(true){
            cout<<"Enter your choice:"<<endl;
    cin>>op;
    if(op == 1){
            cout<<"Enter shared variable:"<<endl;
            cin>>var;
            buffer.push(var);
            index++;
            cout<<"Producer produces saved"<<var<<" into buffer"<<endl;
    }
    else if(op == 2){
        if(index>0){
            var = buffer.front();
            buffer.pop();
            cout<<"Consumer consumed "<<var<<" from buffer"<<endl;
            index--;
        }
        else{
            cout<<"Buffer is empty!!!"<<endl;
        }
    }else if(op == 3){
         break;
    }
    else{
        cout<<"Enter described option!"<<endl;
    }
    }

    return 0;


}
