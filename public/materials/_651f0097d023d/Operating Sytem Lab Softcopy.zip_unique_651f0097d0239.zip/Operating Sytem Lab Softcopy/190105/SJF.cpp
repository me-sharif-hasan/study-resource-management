//SJF scheduling algorithm

#include<bits/stdc++.h>
using namespace std;

struct process{
    int id;
    int at;
    int bt;
};

bool compareTwoat(process a, process b){
    if(a.at!=b.at)
        return a.at<b.at;
}

bool compareTwobt(process a, process b){
    if(a.bt!=b.bt)
        return a.bt<b.bt;
}

bool compareTwoid(process a, process b){
    if(a.id!=b.id)
        return a.id<b.id;
}

int main(){
    cout<<"Enter the number of process: "<<endl;
    int n,ct[n],j=1; cin>>n;
    process p[n];

    cout<<"Enter process id, at, bt together: "<<endl;
    for(int i=0;i<n;i++){
        cin>>p[i].id>>p[i].at>>p[i].bt;
    }
    sort(p, p+n, compareTwoat );

    ct[0]=p[0].at+p[0].bt;
    int c=ct[0];
    int f=p[0].id;
    sort(p, p+n, compareTwobt );

    vector<pair<int,int>>v;

    //cout<<"ct: "<<ct[0]<<" ";

    v.push_back(make_pair(f,c));

    //cout<<"v0: "<<v[0].second<<endl;

    for(int i=0;i<n;i++){
        if(p[i].id==f) continue;

        ct[j]=ct[j-1]+p[i].bt;
        c=ct[j];
        //cout<<ct[j]<<" ";
        v.push_back(make_pair(p[i].id, c)); j++;
    }

     sort(p, p+n, compareTwoid );
     sort(v.begin(),v.end());
     int tat[n], wt[n];

     for(int i=0;i<n;i++){
        tat[i]=v[i].second-p[i].at; //cout<<"tat: "<<tat[i]<<" ";
     }
     float sum=0.0;

    for(int i=0;i<n;i++){
        wt[i]=tat[i]-p[i].bt; sum+=wt[i];

     }
     cout<<endl;
    float avg=float(sum/float(n));
    cout<<"Average waiting time is: "<<setprecision(2) <<avg<<endl;
   // cout<<p[0].id<<endl;
    return 0;
}
