#include "bits/stdc++.h"
using namespace std;

#define br cout<<"\n"



#define pb push_back

typedef long long ll; // comments that are mixed in with code
typedef pair<int, int> ii; // are aligned to the right like this
typedef vector<ii> vii;
typedef vector<int> vi;


#define FOR(i,n) for(int i=0;i<n;i++)
#define FROM(a,i,n) for(int i=a;i<n;i++)
#define vin(macroVec) for(auto &macroA:macroVec) cin>>macroA;

/*Output macros*/
#define YES cout<<"YES\n";
#define NO cout<<"NO\n";
#define printCase(ck) cout<<"Case "<<ck<<": ";

 struct job{
 	int arival_time;
 	int burst_time;
 	int priority;
 	int id;
 	int rbt=0;
 	int ending_time;
 };

 class CMP {
public:
    bool operator()(job& t1, job& t2)
    {
       if (t1.priority < t2.priority) return true;
       return false;
    }
};
bool cmp(job a,job b){
	return a.arival_time<b.arival_time;
}
void solve(){

	priority_queue <job,vector <job>,CMP> jobs;
	int n;
	cout<<"Enter the number of jobs: \n";
	cin>>n;
	vector <job> joblist;
	FOR(i,n){
		cout<<"Enter id, arival time, burst time, priority: \n";
		int id,at,bt,p;
		cin>>id>>at>>bt>>p;
		job j;
		j.arival_time=at;
		j.burst_time=bt;
		j.id=id;
		j.priority=p*-1;
		j.rbt=bt;
		//jobs.push(j);
		joblist.pb(j);
	}
	sort(joblist.begin(),joblist.end(),cmp);

	vector <job> finished;
	int p=0;
	for(int t=0;t<1000;t++){
		if(jobs.size()>0){
			job j=jobs.top();
			jobs.pop();
			j.rbt--;
			if(j.rbt==0){
				j.ending_time=t;
				finished.pb(j);
			}else{
				jobs.push(j);
			}
		}
		if(p<joblist.size()&&joblist[p].arival_time<=t){
			jobs.push(joblist[p]);
			p++;
		}
	}
	double total_wait=0;
	for(auto a:finished){
		cout<<"Process "<<a.id<<" finished at "<<a.ending_time<<endl;
		int tat=a.ending_time-a.arival_time;
		int wait=tat-a.burst_time;
		total_wait+=wait;
		cout<<"Wait: "<<wait<<endl;
		//what(tat);
	}

	cout<<"Average waiting time: "<<total_wait/finished.size();br;

 }


 struct process{
    int id;
    int pr;
    int at;
    int bt;
};

bool compareTwoid(process a, process b){
    if(a.id!=b.id)
        return a.id<b.id;
}

bool compareTwoat(process a, process b){
    if(a.at!=b.at)
        return a.at<b.at;
}

bool compareTwobt(process a, process b){
    if(a.bt!=b.bt)
        return a.bt<b.bt;
}

bool compareTwopr(process a, process b){
    if(a.pr!=b.pr)
        return a.pr<b.pr;
}






int main(){

	int p1;
    cout<<"Press 1 if you want Non pre emptive otherwise press 2 "<<endl; cin>>p1;
    if(p1==1){
    cout<<"Enter the number of process: "<<endl;
    int n,j=1; cin>>n; int ct[n];
    process p[n];
    cout<<"Enter id, priority, arrival time, burst time together: "<<endl;
    for(int i=0;i<n;i++){
        cin>>p[i].id>>p[i].pr>>p[i].at>>p[i].bt;
    }
    sort(p, p+n, compareTwoat );

    ct[0]=p[0].at+p[0].bt;
    int c=ct[0];
    int f=p[0].id;

    //lower the number higher the priority
    sort(p, p+n, compareTwopr );

    vector<pair<int,int>>v;

    cout<<"gantt: "<<ct[0]<<" ";

    v.push_back(make_pair(f,c));

    for(int i=0;i<n;i++){
        if(p[i].id==f) continue;

        ct[j]=ct[j-1]+p[i].bt;
        c=ct[j];
        cout<<ct[j]<<" ";
        v.push_back(make_pair(p[i].id, c)); j++;
    }

    cout<<endl;
    sort(p, p+n, compareTwoid );
    sort(v.begin(),v.end());
    int tat[n], wt[n];

    for(int i=0;i<n;i++){
        tat[i]=v[i].second-p[i].at; //cout<<"tat: "<<tat[i]<<" ";
    }
    float sum=0.0;

    for(int i=0;i<n;i++){
        wt[i]=tat[i]-p[i].bt; sum+=wt[i];
       // cout<<"wt: "<<wt[i]<<" ";
    }
    cout<<endl;
    float avg=float(sum/float(n));
    cout<<"Average waiting time is: "<<setprecision(2) <<avg<<endl;

    return 0;
    }


	solve();
}
