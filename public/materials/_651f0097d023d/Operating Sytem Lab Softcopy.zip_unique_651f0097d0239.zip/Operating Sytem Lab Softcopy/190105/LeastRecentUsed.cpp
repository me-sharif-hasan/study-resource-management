#include <iostream>
#include<bits/stdc++.h>
using namespace std;

int main()
{
int capacity;
cout<<"Enter the number of frame: "<<endl;
cin>>capacity;


int n;

cout<<"Enter the number of references: "<<endl;
cin>>n;

int arr[n];


cout<<"Enter the reference string: "<<endl;
for(int i=0;i<n;i++){
    cin>>arr[i];
}


deque<int> q(capacity);
int count=0;
int page_faults=0;
deque<int>::iterator itr;
q.clear();
for(int i:arr)
{

	// page fault
	itr = find(q.begin(),q.end(),i);
	if(!(itr != q.end()))
	{

	++page_faults;

	//equal pages
	if(q.size() == capacity)
	{
		q.erase(q.begin());
		q.push_back(i);
	}
	else{
		q.push_back(i);

	}
	}
	else
	{

	q.erase(itr);

	// insert current page
	q.push_back(i);
	}

}
cout<<"Number of miss: "<<page_faults<<endl;


cout<<"Number of miss: "<<page_faults*100/n<<"%"<<endl;

cout<<"Number of hits: "<<n-page_faults<<endl;
cout<<"Number of miss: "<<(n-page_faults)*100/n<<"%"<<endl;

}

