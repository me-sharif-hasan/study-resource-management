#include <bits/stdc++.h>
using namespace std;

void optimalPage(int pg[], int pn, int fn)
{
	int fr[fn];
	memset(fr, -1, sizeof(fr));

	int hit = 0;
	for (int i = 0; i < pn; i++) {

		bool found = false;
		for (int j = 0; j < fn; j++) {
			if (fr[j] == pg[i]) {
				hit++;
				found = true;
				break;
			}
		}

		if (found)
			continue;


		bool emptyFrame = false;
		for (int j = 0; j < fn; j++) {
			if (fr[j] == -1) {
				fr[j] = pg[i];
				emptyFrame = true;
				break;
			}
		}

		if (emptyFrame)
			continue;

		// Find the page to be replaced.
		int farthest = -1, replaceIndex = -1;
		for (int j = 0; j < fn; j++) {
			int k;
			for (k = i + 1; k < pn; k++) {
				if (fr[j] == pg[k]) {
					if (k > farthest) {
						farthest = k;
						replaceIndex = j;
					}
					break;
				}
			}
			if (k == pn) {
				replaceIndex = j;
				break;
			}
		}
		fr[replaceIndex] = pg[i];
	}
	cout << "No. of hits = " << hit << endl;

cout<<"hit ratio: "<<hit*100/pn<<"%"<<endl;
cout << "No. of misses = " << pn - hit << endl;

cout<<"Miss ration: "<<(pn-hit)*100/pn<<"%"<<endl;

}

int main() {


    int fn; //frame number
    cout<<"Enter the number of frame: "<<endl;
    cin>>fn;


    int pn; //page number

    cout<<"Enter the number of references: "<<endl;
    cin>>pn;

    int arr[pn];


    cout<<"Enter the reference string: "<<endl;
    for(int i=0;i<pn;i++){
        cin>>arr[i];
    }



	optimalPage(arr, pn, fn);
	return 0;
}

