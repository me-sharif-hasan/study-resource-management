#include<bits/stdc++.h>
using namespace std;
int cs=0;

queue<string>pcb,critical_section;


int wait(int n,int s)
{
 string process;

 s--;

 if(s <0 || cs>n)
 {
     cout<<"Critical Section is full with processes!"<<endl;
     cout<<"Enter process to entry suspend section "<<endl;
     cin>>process;

    pcb.push(process);
 }
 else{
    if(cs <= n){
 cout<<"Enter process to entry critical section "<<endl;
 cin>>process;
         cs++;
        critical_section.push(process);
        cout<<"Entering the process into Critical section."<<endl;
    }

 }
 return s;
}

void signal(int n,int s)
{
 s++;
 if(s <= 0)
 {
     if(!pcb.empty() && !critical_section.empty())
     {
     string temp = pcb.front();
     pcb.pop();
     critical_section.push(temp);
     cout<<"Entering "<<temp<<" to Critical section"<<endl;
     string temp2= critical_section.front();
     critical_section.pop();
     cout<<temp2<<" Exit from critical section"<<endl;
     }else{
     cout<<"Critical Section is empty!"<<endl;
     }

 }
 else{
    string t = critical_section.front();
    critical_section.pop();
    cout<<t<<" Exit from critical section"<<endl;
 }
}

int main()
{

    int s,n,n_p,option;
    cout<<"Enter Semaphore value "<<endl;
    cin>>n;
     s = n;
    n--;



    while(true){
          cout<<"Choose option"<<endl<<"1.wait() function call to entry to critical section"<<endl<<"2.signal() function to exit from critical section"<<endl<<"3. exit"<<endl;
    cin>>option;
    if(option== 1){
        wait(n,s);
    }
    else if(option == 2)
    {
        signal(n,s);
    }
    else if(option == 3)
    {
        break;
    }
    else{
        cout<<"Enter valid option !!!"<<endl;
    }
    }

    return 0;


}
