//FCFS scheduling algorithm

#include<bits/stdc++.h>
using namespace std;

struct process{

    int at;
    int bt;
};

bool compareTwoat(process a, process b){
    if(a.at!=b.at)
        return a.at<b.at;
}



bool compareTwobt(process a, process b){
    if(a.bt!=b.bt)
        return a.bt<b.bt;
}

int main(){
    cout<<"Enter the number of process: "<<endl;
    int n,ct[n],j=1; cin>>n;
    process p[n];

    cout<<"Enter process at, bt together: "<<endl;
    for(int i=0;i<n;i++){
        cin>>p[i].at>>p[i].bt;
    }
    sort(p, p+n, compareTwoat );

    ct[0]=p[0].at+p[0].bt;

    for(int i=1;i<n; i++){


        if(ct[i-1]>=p[i].at){
        ct[i]=ct[i-1]+p[i].bt;
        }
        else{ct[i]=p[i].at+p[i].bt;}

    }
    int tat[n],wt[n];

    for(int i=0;i<n;i++){
        tat[i]=ct[i]-p[i].at;

     }


     float sum=0.0;

    for(int i=0;i<n;i++){
        wt[i]=tat[i]-p[i].bt; sum+=wt[i];
     }
     cout<<endl;
    float avg=float(sum/float(n));
    cout<<"Average waiting time is: "<<setprecision(2) <<avg<<endl;
   // cout<<p[0].id<<endl;
    return 0;
}

