 #include<bits/stdc++.h>
template <typename T>
class BoundedBuffer {
public:
    BoundedBuffer(int size) : buffer_(size), size_(size), writePos_(0), readPos_(0), count_(0) {}

    void Produce(const T& item) {
        std::unique_lock<std::mutex> lock(mutex_);
        while (count_ >= size_) {
            notFull_.wait(lock);
        }

        buffer_[writePos_] = item;
        writePos_ = (writePos_ + 1) % size_;
        ++count_;

        notEmpty_.notify_all();
    }

    T Consume() {
        std::unique_lock<std::mutex> lock(mutex_);
        while (count_ <= 0) {
            notEmpty_.wait(lock);
        }

        T item = buffer_[readPos_];
        readPos_ = (readPos_ + 1) % size_;
        --count_;

        notFull_.notify_all();
        return item;
    }

private:
    std::vector<T> buffer_;
    int size_;
    int writePos_;
    int readPos_;
    int count_;
    std::mutex mutex_;
    std::condition_variable notEmpty_;
    std::condition_variable notFull_;
};

int main() {
    BoundedBuffer<int> buffer(10);

    
    std::thread producer([&]() {
        for (int i = 0; i < 100; ++i) {
            buffer.Produce(i);
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    });
 
    std::thread consumer([&]() {
        for (int i = 0; i < 100; ++i) {
            int item = buffer.Consume();
            std::cout << "Consumed: " << item << std::endl;
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
        }
    });

    producer.join();
    consumer.join();

    return 0;
}
