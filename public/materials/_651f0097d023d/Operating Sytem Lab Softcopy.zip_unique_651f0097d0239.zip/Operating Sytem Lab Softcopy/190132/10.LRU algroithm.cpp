#include <bits/stdc++.h>


class LRUCache {
private:
    int capacity;
    int *keys;
    int *values;
    int *usage;
    int counter = 0;

public:
    LRUCache(int capacity) {
        this->capacity = capacity;
        keys = new int[capacity];
        values = new int[capacity];
        usage = new int[capacity];
        std::fill_n(usage, capacity, -1);
    }

    ~LRUCache() {
        delete[] keys;
        delete[] values;
        delete[] usage;
    }

    int get(int key) {
        for (int i = 0; i < capacity; ++i) {
            if (keys[i] == key) {
             
                usage[i] = counter++;
                return values[i];
            }
        }
     
        return -1;
    }

    void put(int key, int value) {
        for (int i = 0; i < capacity; ++i) {
            if (keys[i] == key) {
              
                values[i] = value;
                usage[i] = counter++;
                return;
            }
        }

      
        int minUsage = *std::min_element(usage, usage + capacity);
        int idx = std::find(usage, usage + capacity, minUsage) - usage;
        keys[idx] = key;
        values[idx] = value;
        usage[idx] = counter++;
    }
};

int main() {
   
    LRUCache cache(2);

    cache.put(1, 1);
    cache.put(2, 2);
    std::cout << cache.get(1) << std::endl; 
    cache.put(3, 3); 
    std::cout << cache.get(2) << std::endl; 
    cache.put(4, 4); 
    std::cout << cache.get(1) << std::endl;
    std::cout << cache.get(3) << std::endl; 
    std::cout << cache.get(4) << std::endl;
    return 0;
}
