#include<bits/stdc++.h>


using namespace std;

int main() {
    int et[20], at[10], n, i, j, temp, p[10], st[10], ft[10], wt[10], ta[10];
    int totwt = 0, totta = 0;
    float awt, ata;
    string pn[10], t;

    cout << "Enter the number of process:";
    cin >> n;

    for(i = 0; i < n; i++) {
        cout << "Enter process name, arrival time, execution time, and priority:";
        cin >> pn[i] >> at[i] >> et[i] >> p[i];
    }

    for(i = 0; i < n; i++) {
        for(j = 0; j < n; j++) {
            if(p[i] < p[j]) {
                temp = p[i];
                p[i] = p[j];
                p[j] = temp;
                temp = at[i];
                at[i] = at[j];
                at[j] = temp;
                temp = et[i];
                et[i] = et[j];
                et[j] = temp;
                t = pn[i];
                pn[i] = pn[j];
                pn[j] = t;
            }
        }
    }

    for(i = 0; i < n; i++) {
        if(i == 0) {
            st[i] = at[i];
            wt[i] = st[i] - at[i];
            ft[i] = st[i] + et[i];
            ta[i] = ft[i] - at[i];
        } else {
            st[i] = ft[i - 1];
            wt[i] = st[i] - at[i];
            ft[i] = st[i] + et[i];
            ta[i] = ft[i] - at[i];
        }
        totwt += wt[i];
        totta += ta[i];
    }

    awt = (float)totwt / n;
    ata = (float)totta / n;

    cout << "\nPname\tarrivaltime\texecutiontime\tpriority\twaitingtime\ttatime" << endl;
    for(i = 0; i < n; i++) {
        cout << pn[i] << "\t" << at[i] << "\t\t" << et[i] << "\t\t" << p[i] << "\t\t" << wt[i] << "\t\t" << ta[i] << endl;
    }

    cout << "Average waiting time is: " << awt << endl;
    cout << "Average turnaround time is: " << ata << endl;

    return 0;
}
