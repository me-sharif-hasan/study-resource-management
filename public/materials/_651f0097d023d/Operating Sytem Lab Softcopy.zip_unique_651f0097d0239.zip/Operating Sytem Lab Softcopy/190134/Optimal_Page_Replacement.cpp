#include<bits/stdc++.h>
using namespace std;
int main(){
    int nf,np;
    cout<<"Enter the number of pages:"<<endl;
    cin>>np;
    int pages[np];
    cout<<"Enter the number of frames:"<<endl;
    cin>>nf;
    cout<<"Enter all pages: "<<endl;
    for(int i=0;i<np;i++)
    {
        cin>>pages[i];
    }
    int frame[nf]={-1};
    int hit=0;
    for(int i=0;i<np;i++)
    {
        bool found = false;
        for(int j=0;j<nf;j++)
        {
            if(pages[i] == frame[j])
            {
               hit++;
               found =true;
               break;
            }
        }
        if(found)
            continue;
        bool emptyFrame = false;
        for(int j=0;j<nf;j++)
        {
            if(frame[j] == -1)
            {
                frame[j] = pages[i];
                emptyFrame = true;
				break;
            }
        }
        if(emptyFrame)
            continue;
       int farthest = -1, replaceIndex=-1;
       for(int i=0;i<nf;i++)
       {
           int k;
           for(k = i+1; k<np;k++)
           {
               if(pages[k] == frame[i])
               {
                   if(k>farthest){
                    farthest = k;
                    replaceIndex = i;
                   }
                   break;
               }
           }
           if(k == np)
           {
               replaceIndex = i;
               break;
           }
       }
       frame[replaceIndex] = pages[i];

    }

    cout << "No. of hits = " << hit << endl;
	cout << "No. of misses = " << np - hit << endl;
}
