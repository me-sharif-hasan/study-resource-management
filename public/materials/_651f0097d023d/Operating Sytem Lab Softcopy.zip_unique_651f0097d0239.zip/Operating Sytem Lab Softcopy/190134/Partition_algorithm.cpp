#include<bits/stdc++.h>
using namespace std;

void first_fit(int nb,int np, int b[],int p[])
{
int bf[100]={0},frag[100],temp,ff[100];

for(int i=1;i<=np;i++)
{
for(int j=1;j<=nb;j++)
{
if(bf[j]!=1)
{
temp=b[j]-p[i];
if(temp>=0)
{
ff[i]=j;
break;
}
}
}
frag[i]=temp;
bf[ff[i]]=1;
}
cout<<"File_no:File_size :Block_no:Block_size:Frage:"<<endl;
for(int i=1;i<=np;i++)
 cout<<i<<" "<<p[i]<<"  "<<ff[i]<<" "<<b[ff[i]]<<" "<<frag[i]<<endl;
}

void worst_fit(int nb,int np, int b[],int p[])
{
int bf[100]={0},frag[100],temp,ff[100],highest=0;

for(int i=1;i<=np;i++)
{
for(int j=1;j<=nb;j++)
{
if(bf[j]!=1)
{
temp=b[j]-p[i];
if(temp>=0)
if(highest<temp)
{
ff[i]=j;
highest=temp;
}
}
}
frag[i]=highest;
bf[ff[i]]=1;
highest=0;
}
cout<<"File_no:File_size :Block_no:Block_size:Frage:"<<endl;
for(int i=1;i<=np;i++)
 cout<<i<<" "<<p[i]<<"  "<<ff[i]<<" "<<b[ff[i]]<<" "<<frag[i]<<endl;
}


void best_fit(int nb,int np, int b[],int p[])
{
int bf[100]={0},frag[100],temp,ff[100],lowest=10000;

for(int i=1;i<=np;i++)
{
for(int j=1;j<=nb;j++)
{
if(bf[j]!=1)
{
temp=b[j]-p[i];
if(temp>=0)
if(lowest>temp)
{
ff[i]=j;
lowest=temp;
}

}
}

frag[i]=lowest;
bf[ff[i]]=1;
lowest=10000;
}
cout<<"File_no:File_size :Block_no:Block_size:Frage:"<<endl;
for(int i=1;i<=np;i++)
 cout<<i<<" "<<p[i]<<"  "<<ff[i]<<" "<<b[ff[i]]<<" "<<frag[i]<<endl;
}


int main()
{
    int np,nb,p[1000],b[1000];

    int choice;
    cout<<"1. First Fit"<<endl<<"2. Worst Fit"<<endl<<"3.Best Fit"<<"4.exit"<<endl;
    while(true){
    cout<<"Enter your choice for partitioning algorithm"<<endl;
    cin>>choice;
     cout<<"Enter the number of block"<<endl;
        cin>>nb;
        cout<<"Enter the number of process"<<endl;
        cin>>np;
        cout<<"Enter the size of blocks"<<endl;
        for(int i=1;i<=nb;i++)
        {
            cin>>b[i];
        }

         cout<<"Enter the size of process"<<endl;
        for(int i=1;i<=np;i++)
        {
            cin>>p[i];
        }
    if(choice == 1)
    {
       first_fit(nb,np,b,p);
    }
    else if(choice == 2)
    {
        worst_fit(nb,np,b,p);
    }
    else if(choice == 3)
    {
        best_fit(nb,np,b,p);
    }
    else{
        break;
    }
    }

}
