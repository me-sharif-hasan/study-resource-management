#include<bits/stdc++.h>
using namespace std;
int main()
{
    int frame, page;
  cin>>frame>>page;
  int p[page] = {0};
  for(int i=0;i<page;i++)
  {
      cin>>p[i];
  }
  deque<int>q(page);
  deque<int>::iterator itr;
  q.clear();
  int page_fault=0;
  for(int i:p)
{
    itr = find(q.begin(),q.end(),i);
    if(!(itr != q.end())){
        page_fault++;
        if(q.size() == frame)
        {
            q.erase(q.begin());
            q.push_back(i);
        }
        else{
            q.push_back(i);
        }
    }
    else{
        q.erase(itr);
        q.push_back(i);
    }
}
cout<<page_fault<<endl;

}
