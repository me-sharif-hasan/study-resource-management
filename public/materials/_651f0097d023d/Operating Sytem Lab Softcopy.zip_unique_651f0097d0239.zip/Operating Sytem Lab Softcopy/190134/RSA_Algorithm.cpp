#include<bits/stdc++.h>
using namespace std;
int gcd(int a, int b){
  while(1)
  {
      int temp = a%b;
      if(temp == 0)
      {
          return b;
      }
      a = b;
      b = temp;
  }
}

int main()
{
    double p = 3;
    double q = 7;
    double n = p*q;
    double phi = (p-1)*(q-1);
    double e = 2;

    while(e<phi)
    {
        if(gcd(e,phi) == 1)
        {
            break;
        }
        e++;
    }

    int k =2;
    double d = (1+(k*phi))/e;

    double msg = 12;
    cout<<msg<<endl;
    double c = pow(msg,e);
    c = fmod(c,n);
    cout<<c<<endl;
    double m = pow(c,d);
    m = fmod(m,n);
    cout<<m<<endl;
}
