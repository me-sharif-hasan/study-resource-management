#include<bits/stdc++.h>
using namespace std;
class process{
    public:
 int id,at,bt;
};

bool compareAT(process a, process b)
{
    if(a.at != b.at){
        return a.at<b.at;
    }
}
bool compareID(process a, process b)
{
    if(a.id != b.id){
        return a.id<b.id;
    }
}
int main()
{
    int n;
    process p[100];
    cout<<"Enter the number of process: "<<endl;
    cin>>n;
    int ct[n] = {0};
    for(int i=0;i<n;i++)
    {
        cin>>p[i].id>>p[i].at>>p[i].bt;
    }
    sort(p,p+n,compareAT);
   int sum = 0;
   for(int i=0;i<n;i++)
   {
       if(sum == p[i].at || sum>p[i].at){
        sum+=p[i].bt;
        ct[i] += sum;
       }
       else{
        sum++;
        i--;
       }
   }
    for(int i=0;i<n;i++)
    {
        cout<<ct[i]<<endl;
    }
}

