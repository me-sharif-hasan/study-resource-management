#include<bits/stdc++.h>
using namespace std;

class process{
public:
    int AT,ID,BT,WT,TAT,CT,start;
};

int main()
{

    int n,complete=0,completed[100] = {false},current_time =0;
    process p[100];
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>p[i].ID>>p[i].AT>>p[i].BT;
    }

    while(complete != n)
    {
        int min_value = INT_MAX;
        int min_index = -1;
        for(int i=0;i<n;i++)
        {
            if(p[i].AT <= current_time && completed[i] == false)
            {
                if(p[i].BT < min_value)
                {
                    min_index = i;
                    min_value = p[i].BT;
                }
                if(p[i].BT == min_value)
                {
                    if(p[i].AT < p[min_index].AT)
                    {
                        min_index = i;
                        min_value = p[i].BT;
                    }
                }
            }
        }
            if(min_index == -1)
            {
                current_time++;
            }
            else{
                p[min_index].start = current_time;
                p[min_index].CT = p[min_index].BT + p[min_index].start;
                p[min_index].TAT = p[min_index].CT - p[min_index].AT;
                p[min_index].WT = p[min_index].TAT - p[min_index].BT;

                complete++;
                completed[min_index] = true;
                current_time += p[min_index].CT;
            }

    }

    for(int i=0;i<n;i++)
    {
        cout<<p[i].ID<<"    "<<p[i].AT<<"    "<<p[i].BT<<"    "<<p[i].CT<<"     "<<p[i].TAT<<"     "<<p[i].WT<<"     "<<endl;
    }
}





