#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,i,y,cmpltT=0,At[20],bt[20],tempbt[20],wt=0,tat=0,quant;
    float avgwt=0,avgtat=0;
    bool isProcessing = true;
    cout<<"Enter Number of Process:";
    cin>>n;
    y=n;

    cout<<"\nEnter Arival Time and Brust Time for per process:\n";
    for(int i=0;i<n;i++)
    {
        cout<<"\nEnter Arival Time for Process["<<i+1<<"] :";
        cin>>At[i];
        cout<<"\nEnter Brust Time for Process["<<i+1<<"] :";
        cin>>bt[i];

        tempbt[i]=bt[i];
    }

    cout<<"\nEnter Time Quantum of Per process:";
    cin>>quant;

    cout<<endl<<"Process\tAT\tBT\tTAT\tWT\n";

    i=0;
    while(y!=0)
    {
        if(tempbt[i] <=quant && tempbt[i]>0)
        {
            cmpltT +=tempbt[i];
            tempbt[i]=0;
            isProcessing = false;
        }
        else if(tempbt[i]>0)
        {
            tempbt[i] -=quant;
            cmpltT+=quant;
            isProcessing = true;
        }
        if(tempbt[i]==0 && !isProcessing)
        {
            y--;
            tat=cmpltT-At[i];
            wt=tat-bt[i];
            cout<<"p["<<i+1<<"]"<<"\t"<<At[i]<<"\t"<<bt[i]<<"\t"<<tat<<"\t"<<wt<<endl;
            isProcessing =true;
            avgtat +=tat;
            avgwt +=wt;
        }
        if(i==n-1)
        {
            i=0;
        }
        else if(At[i]<=cmpltT)
        {
            i++;
        }
        else{
            i=0;
        }
    }


    return 0;
}
