#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,i,j,BT[20],WT[20]={0},TAT[20],AvgWT=0,AvgTAT=0;
    cout<<"Enter Number of Process:";
    cin>>n;

    cout<<"\nEnter Processes's Brust Time:\n";
    for(int i=0;i<n;i++)
    {

        cout<<"Process["<<i+1<<"] :-";
        cin>>BT[i];
    }


    for(i=1;i<n;i++)
    {

        for(j=0;j<i;j++)
        {
            WT[i] += BT[j];
        }
    }


    cout<<"\nProcess"<<"\t\tBT"<<"\tWT"<<"\tTAT";

    for(int i=0;i<n;i++)
    {

        TAT[i]=WT[i]+BT[j];
        AvgWT +=WT[i];
        AvgTAT +=TAT[i];

        cout<<"\nProcess["<<i+1<<"] :"<<"\t"<<BT[i]<<"\t"<<WT[i]<<"\t"<<TAT[i];

    }

    cout<<"\n\nAverage Waiting TIme: "<<AvgWT<<endl;
    cout<<"Average Turn Around TIme: "<<AvgTAT<<endl;



    return 0;
}
