#include <bits/stdc++.h>
using namespace std;
int main()
{
	int n, m, i, j, k;
	n = 5;
	m = 3;
	int Allocation[5][3] = { { 0, 1, 0 },
						{ 2, 0, 0 },
						{ 3, 0, 2 },
						{ 2, 1, 1 },
						{ 0, 0, 2 } };

	int Max[5][3] = { { 7, 5, 3 },
					{ 3, 2, 2 },
					{ 9, 0, 2 },
					{ 2, 2, 2 },
					{ 4, 3, 3 } };

	int Available[3] = { 3, 3, 2 };

	int f[n], ans[n], ind = 0;
	for (k = 0; k < n; k++) {
		f[k] = 0;
	}
	int need[n][m];
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++)
			need[i][j] = Max[i][j] - Allocation[i][j];
	}
	int y = 0;
	for (k = 0; k < 5; k++) {
		for (i = 0; i < n; i++) {
			if (f[i] == 0) {
				int flag = 0;
				for (j = 0; j < m; j++) {
					if (need[i][j] > Available[j]){
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					ans[ind++] = i;
					for (y = 0; y < m; y++)
						Available[y] += Allocation[i][y];
					f[i] = 1;
				}
			}
		}
	}

	int flag = 1;

	for(int i=0;i<n;i++)
	{
        if(f[i]==0)
        {
            flag=0;
           cout<<"The following system is not safe";
            break;
        }
	}
	if(flag==1)
	{
        cout<<"Following is the SAFE Sequence\n";
        for (i = 0; i < n - 1; i++)
            cout<<" P%d ->", ans[i];
        cout<<" P%d", ans[n - 1];
	}
	return (0);

}

