#include<bits/stdc++.h>
using namespace std;

int main()
{
   int n,p[20]={0},bt[20]={0},wt[20]={0},tat[20]={0},temp=0;
   float avgtat=0,avgwt=0;

   cout<<"Enter number of Process:";
   cin>>n;

   cout<<"\nEnter Processes's Brust Time:\n";
   for(int i=0;i<n;i++)
   {
       cout<<"Process["<<1+i<<"] :";
       cin>>bt[i];
       p[i]=i+1;
   }

   for(int i=0;i<n;i++)
   {
       int pos=i;

       for(int j=i+1;j<n;j++)
       {
           if(bt[j]<bt[pos])
            pos=j;
       }
       temp=bt[i];
       bt[i]=bt[pos];
       bt[pos]=temp;

       temp=p[i];
       p[i]=p[pos];
       p[pos]=temp;
   }

   wt[0]=0;

   for(int i=1;i<n;i++)
   {
       wt[i]=0;
       for(int j=0;j<i;j++)
       {
           wt[i] +=bt[j];
       }
   }


   cout<<"\n\nProcess"<<"\tBT"<<"\tWT"<<"\tTAT";

   for(int i=0;i<n;i++)
   {
       tat[i]=wt[i]+bt[i];
       avgtat +=tat[i];
       avgwt +=wt[i];
       cout<<"\nP["<<i<<"] :"<<"\t"<<bt[i]<<"\t"<<wt[i]<<"\t"<<tat[i];
   }

   cout<<"\n\nAverage waiting time: "<<avgwt/n<<endl;
   cout<<"Average Turn Around Time"<<avgtat/n<<endl;
    return 0;
}
