#include <iostream>
#include <list>
#include <unordered_map>

using namespace std;

int main()
{
    int n, m;

    cout << "Enter number of frames: ";
    cin >> n;

    list<int> frames;
    unordered_map<int, list<int>::iterator> table;

    cout << "Enter number of requests: ";
    cin >> m;

    cout << "Enter requests:" << endl;
    int faults = 0;

    for (int i = 0; i < m; i++)
    {
        int req;
        cin >> req;

        if (table.find(req) != table.end())
        {
            frames.erase(table[req]);
            frames.push_front(req);
            table[req] = frames.begin();
        }
        else
        {
            faults++;

            if (frames.size() == n)
            {
                int lru = frames.back();
                frames.pop_back();
                table.erase(lru);
            }

            frames.push_front(req);
            table[req] = frames.begin();
        }
    }

    cout << "Total faults: " << faults << endl;

    return 0;
}
