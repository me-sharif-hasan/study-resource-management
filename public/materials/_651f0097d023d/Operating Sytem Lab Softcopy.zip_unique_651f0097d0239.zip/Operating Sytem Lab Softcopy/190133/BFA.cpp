#include <bits/stdc++.h>

using namespace std;

struct Block
{
    int size;
    bool used;
    int pid;
};

int main()
{
    int n, m;

    cout << "Enter the number of memory blocks: ";
    cin >> n;
    vector<Block> blocks(n);

    cout << "Enter block sizes:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << "Block " << i << ": ";
        cin >> blocks[i].size;
        blocks[i].used = false;
        blocks[i].pid = -1;
    }

    cout << "Enter the number of processes: ";
    cin >> m;
    vector<int> psz(m);

    cout << "Enter process sizes:" << endl;
    for (int i = 0; i < m; i++)
    {
        cout << "Process " << i << ": ";
        cin >> psz[i];
    }

    for (int i = 0; i < m; i++)
    {
        int size = psz[i];
        int bfb = -1;

        for (int j = 0; j < n; j++)
        {
            if (!blocks[j].used && blocks[j].size >= size)
            {
                if (bfb == -1 || blocks[j].size < blocks[bfb].size)
                {
                    bfb = j;
                }
            }
        }

        if (bfb != -1)
        {
            blocks[bfb].used = true;
            blocks[bfb].pid = i;
            cout << "Allocated P" << i << " to B" << bfb << endl;
        }
        else
        {
            cout << "Unable to allocate P" << i << " to any block." << endl;
        }
    }

    cout << "\nMemory Block Allocation Table:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << "Block " << i << ": ";
        if (blocks[i].used)
        {
            cout << "P" << blocks[i].pid << " (" << psz[blocks[i].pid] << "KB)";
        }
        else
        {
            cout << "Unallocated";
        }
        cout << endl;
    }

    return 0;
}
