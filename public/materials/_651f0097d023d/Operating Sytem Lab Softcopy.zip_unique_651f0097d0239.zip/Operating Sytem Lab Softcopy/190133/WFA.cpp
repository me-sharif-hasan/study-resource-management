#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct memBlc
{
    int id;
    int sz;
    bool alc;
};

bool cmp(const memBlc &a, const memBlc &b)
{
    return a.sz > b.sz;
}

void worstFit(vector<memBlc> &mem, int p_sz)
{
    int n = mem.size();

    sort(mem.begin(), mem.end(), cmp);

    for (int i = 0; i < n; i++)
    {
        if (!mem[i].alc && mem[i].sz >= p_sz)
        {
            mem[i].alc = true;
            cout << "Allocated Process " << p_sz << " to Block " << mem[i].id << endl;
            return;
        }
    }

    cout << "Allocation failed for Process " << p_sz << endl;
}

int main()
{
    int b;
    cout << "Enter the number of memory blocks: ";
    cin >> b;

    vector<memBlc> mem(b);

    for (int i = 0; i < b; i++)
    {
        mem[i].id = i + 1;
        cout << "Enter the size of Block " << i + 1 << ": ";
        cin >> mem[i].sz;
        mem[i].alc = false;
    }

    int p;
    cout << "Enter the number of processes: ";
    cin >> p;

    for (int i = 0; i < p; i++)
    {
        int p_sz;
        cout << "Enter the size of Process " << i + 1 << ": ";
        cin >> p_sz;
        worstFit(mem, p_sz);
    }

    return 0;
}
