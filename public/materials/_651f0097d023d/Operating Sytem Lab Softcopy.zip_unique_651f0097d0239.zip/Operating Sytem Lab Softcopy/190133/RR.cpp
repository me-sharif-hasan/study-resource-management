#include <bits/stdc++.h>
using namespace std;

const int N = 100;

int n, qt;
struct process
{
    int id;
    int bt;
    int at;
    int wt;
    int ft;
    int tat;
    int remt;
};
process P[N];

void RoundRobin()
{
    int complete, current_time, change;
    double total_wt = 0.0;
    double total_tat = 0.0;

    for (int i = 0; i < n; i++)
        P[i].remt = P[i].bt;

    complete = 0;
    current_time = 0;

    while (complete < n)
    {
        change = 0;
        for (int i = 0; i < n; i++)
        {
            if (P[i].at <= current_time && P[i].remt > 0)
            {
                if (P[i].remt <= qt)
                {
                    complete++;
                    current_time += P[i].remt;

                    P[i].ft = current_time;
                    P[i].tat = P[i].ft - P[i].at;
                    P[i].wt = P[i].tat - P[i].bt;

                    total_wt += P[i].wt;
                    total_tat += P[i].tat;

                    P[i].remt = 0;
                }
                else
                {
                    current_time += qt;
                    P[i].remt -= qt;
                }
                change++;
            }
        }
        if (change == 0)
        {
            current_time++;
        }
    }
    cout << "\nProcess\tAT\tBT\tTAT\tWT\n";
    for (int i = 0; i < n; i++)
    {
        cout << P[i].id + 1 << "\t" << P[i].at << "\t" << P[i].bt << "\t" << P[i].tat << "\t" << P[i].wt << "\n";
    }
    cout << fixed << setprecision(2);
    cout << "Average Waiting Time: " << (total_wt / n) << "\n";
    cout << "Average Turn Around Time: " << (total_tat / n) << "\n";
    return;
}

int main()
{
    cout << "Number of Processes: ";
    cin >> n;

    cout << "Quantum time: ";
    cin >> qt;

    for (int i = 0; i < n; i++)
        P[i].id = i;

    cout << "Process Arrival Times:\n";
    for (int i = 0; i < n; i++)
        cin >> P[i].at;

    cout << "Process Burst Times:\n";
    for (int i = 0; i < n; i++)
        cin >> P[i].bt;

    RoundRobin();

    return 0;
}