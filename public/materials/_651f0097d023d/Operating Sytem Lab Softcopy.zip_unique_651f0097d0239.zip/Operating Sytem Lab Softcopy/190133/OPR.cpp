#include <bits/stdc++.h>

using namespace std;

int far_page(vector<int> &p, vector<int> &rs, int cur)
{
    int furthest = -1;
    int maxDist = INT_MIN;

    for (int i = 0; i < p.size(); i++)
    {
        int page = p[i];
        int dist = INT_MAX;

        for (int j = cur + 1; j < rs.size(); j++)
        {
            if (rs[j] == page)
            {
                dist = j - cur;
                break;
            }
        }

        if (dist > maxDist)
        {
            maxDist = dist;
            furthest = i;
        }
    }

    return furthest;
}

int OPR(vector<int> &rs, int numFrames)
{
    vector<int> frames;
    int faults = 0;

    for (int i = 0; i < rs.size(); i++)
    {
        int page = rs[i];

        if (frames.size() < numFrames)
        {
            frames.push_back(page);
            faults++;
        }
        else
        {
            if (find(frames.begin(), frames.end(), page) == frames.end())
            {
                int furthestIdx = far_page(frames, rs, i);
                frames[furthestIdx] = page;
                faults++;
            }
        }
    }

    return faults;
}

int main()
{
    int n;
    cout << "Enter the number of frames: ";
    cin >> n;

    int m;
    cout << "Enter the number of references: ";
    cin >> m;

    vector<int> rs(m);
    cout << "Enter the reference string:" << endl;
    for (int i = 0; i < m; i++)
    {
        cin >> rs[i];
    }

    int faults = OPR(rs, n);

    cout << "Total faults: " << faults << endl;

    return 0;
}
