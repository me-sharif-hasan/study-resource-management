#include<bits/stdc++.h>
using namespace std;
struct Process
{
    int id,at,bt,tat,wt;
    bool flag;
};
bool shortestBT(Process a,Process b){
    return a.bt<b.bt;
}
bool shortestAT(Process a, Process b)
{
    return a.at < b.at;
}
bool shortestId(Process a,Process b){
    return a.id<b.id;
}
void SJF(vector<Process> p, int n)
{
    int prev_wt=0,prev_tat=0;
    p[0].wt=0;
    p[0].tat = p[0].wt+p[0].bt;
    int time = p[0].tat + p[0].wt;
    p[0].flag=false;
    sort(p.begin(), p.end(), shortestBT);

    for(int i=1;i<n;i++){
        for(int j=0;j<n;j++){
            if(p[j].at<=time && p[j].flag == true){
                p[j].wt = time - p[j].at;
                p[j].tat = p[j].wt + p[j].bt;
                time += p[j].bt;
                p[j].flag =  false;
                break;
            }
            cout << time << endl;
        }
    }
    sort(p.begin(),p.end(),shortestId);
    cout << "\nProcess\tAT\tBT\tTAT\tWT\n";
    for(int i=0;i<n;i++){
        cout<<p[i].id+1<<"\t"<<p[i].at<<"\t"<<p[i].bt<<"\t"<<p[i].tat<<"\t"<<p[i].wt<<"\n";
    }
}

int main()
{
    int n;
    cout<<"Enter number  of process : ";
    cin>>n;
    vector<Process> p(n);
    for(int i=0;i<n;i++){
        p[i].id=i;
        cout<<"Enter AT of P"<<i+1<<": ";
        cin>>p[i].at;
        cout << "Enter BT of P" << i + 1 << ": ";
        cin >> p[i].bt;
        p[i].flag=true;
        p[i].wt=0;
        p[i].tat=0;
    }
    sort(p.begin(),p.end(),shortestAT);
    // for(int i=0;i<n;i++){
    //     cout<<p[i].id<<endl;
    // }
    SJF(p,n);

    return 0;
}