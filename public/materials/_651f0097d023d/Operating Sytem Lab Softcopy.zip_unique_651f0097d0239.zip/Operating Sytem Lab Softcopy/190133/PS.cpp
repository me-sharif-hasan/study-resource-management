#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Process
{
    int id;
    int bt;
    int pt;
    int at;
    int wt;
    int tat;
};

bool compareProcesses(const Process &a, const Process &b)
{
    if (a.pt != b.pt)
    {
        return a.pt < b.pt;
    }
    else
    {
        return a.at < b.at;
    }
}

void priorityScheduling(vector<Process> &p)
{
    int n = p.size();

    sort(p.begin(), p.end(), compareProcesses);

    vector<int> wt(n, 0);
    vector<int> tat(n, 0);
    int currentTime = 0;

    for (int i = 0; i < n; i++)
    {
        if (p[i].at > currentTime)
        {
            currentTime = p[i].at;
        }

        wt[i] = currentTime - p[i].at;
        currentTime += p[i].bt;
        tat[i] = currentTime - p[i].at;
    }

    float totalWaitingTime = 0;
    float totalTurnaroundTime = 0;

    cout << "Process\tAT\tBT\tPT\tWT\tTAT\n";

    for (int i = 0; i < n; i++)
    {
        p[i].wt = wt[i];
        p[i].tat = tat[i];

        totalWaitingTime += p[i].wt;
        totalTurnaroundTime += p[i].tat;

        cout << p[i].id +1<< "\t" << p[i].at << "\t" << p[i].bt << "\t"
             << p[i].pt << "\t" << p[i].wt << "\t" << p[i].tat << "\n";
    }

    cout << "\nAverage Waiting Time: " << totalWaitingTime / n << endl;
    cout << "Average Turnaround Time: " << totalTurnaroundTime / n << endl;
}

int main()
{
    int n;
    cout << "Enter the number of processes: ";
    cin >> n;

    vector<Process> p(n);

    for (int i = 0; i < n; i++)
    {
        p[i].id = i;
        cout << "Enter arrival time for Process " << i + 1 << ": ";
        cin >> p[i].at;
        cout << "Enter burst time for Process " << i+1 << ": ";
        cin >> p[i].bt;
        cout << "Enter priority for Process " << i+1 << ": ";
        cin >> p[i].pt;
    }

    priorityScheduling(p);

    return 0;
}
