#include <bits/stdc++.h>

using namespace std;

const int mx = 100;

int numProcesses, numResources;
int available[mx];
int maximum[mx][mx];
int allocation[mx][mx];
int need[mx][mx];

bool isSafe()
{
    int finish[mx] = {0};
    int work[mx];
    for (int i = 0; i < numResources; i++)
    {
        work[i] = available[i];
    }

    int processCount = 0;
    int safeSequence[mx];

    while (processCount < numProcesses)
    {
        bool found = false;

        for (int i = 0; i < numProcesses; i++)
        {
            if (!finish[i])
            {
                bool canAllocate = true;
                for (int j = 0; j < numResources; j++)
                {
                    if (need[i][j] > work[j])
                    {
                        canAllocate = false;
                        break;
                    }
                }

                if (canAllocate)
                {
                    for (int j = 0; j < numResources; j++)
                    {
                        work[j] += allocation[i][j];
                    }
                    finish[i] = 1;
                    safeSequence[processCount] = i;
                    processCount++;
                    found = true;
                }
            }
        }

        if (!found)
        {
            return false;
        }
    }

    return true;
}

int main()
{
    cout << "Enter the number of processes: ";
    cin >> numProcesses;

    cout << "Enter the number of resources: ";
    cin >> numResources;

    cout << "Enter the available resources for each type: ";
    for (int i = 0; i < numResources; i++){
        cin >> available[i];
    }

    cout << "Enter the maximum demand of each process for each resource type:" << endl;
    for (int i = 0; i < numProcesses; i++){
        for (int j = 0; j < numResources; j++){
            cin >> maximum[i][j];
        }
    }

    cout << "Enter the current allocation of each resource type to each process:" << endl;
    for (int i = 0; i < numProcesses; i++){
        for (int j = 0; j < numResources; j++)
        {
            cin >> allocation[i][j];
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }

    if (isSafe()){
        cout << "System is in a safe state." << endl;
    }
    else{
        cout << "System is in an unsafe state." << endl;
    }

    return 0;
}
