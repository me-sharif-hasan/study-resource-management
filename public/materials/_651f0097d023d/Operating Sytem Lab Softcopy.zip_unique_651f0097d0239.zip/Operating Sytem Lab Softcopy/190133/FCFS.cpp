#include<bits/stdc++.h>
#define fastIO ios_base::sync_with_stdio(false)
using namespace std;
struct Process
{
    int id, at, bt, ct, tat, wt;
};
void fcfs(vector<Process> p){
    int n = p.size();
    int total_tat=0;
    int total_wt = 0;

    p[0].wt = 0;
    for(int i=1;i<n;i++){
        p[i].wt = p[i-1].wt + p[i-1].bt;
        total_wt+= p[i].wt;
    }
    for(int i=0;i<n;i++){
        p[i].tat = p[i].bt + p[i].wt;
        total_tat += p[i].tat;
    }
    for(int i=0;i<n;i++){
        p[i].ct  = p[i].tat - p[i].at;
    }
    double avarage_wt = total_wt/(n*1.0);
    double avarage_tat = total_tat/(n*1.0);

    cout << "Schedule Table\n";
    cout<<"Process\tAT\tBT\tCT\tTAT\tWT\n";
    for(int i=0;i<n;i++){
        cout<<"p"<<i+1<<"\t"<<p[i].at<<"\t"<<p[i].bt<<"\t"<<p[i].ct<<"\t"<<p[i].tat<<"\t"<<p[i].wt<<"\n";
    }
    cout<<"\nAvarage TAT: "<<setprecision(2)<<avarage_tat;
    cout<<"\nAvarage WT: "<<setprecision(2)<<avarage_wt;
}


int main()
{
    cout<<"Enter number of Processes :";int n;cin>>n;
    vector<Process> p(n);
    for(int i=0;i<n;i++){
        cout<<"Enter AT of P"<<i+1<<": ";
        cin>>p[i].at;
        cout << "Enter BT of P" << i + 1 << ": ";
        cin>>p[i].bt;
    }
    fcfs(p);

    return 0;
}