#include<bits/stdc++.h>
using namespace std;

class processor
{
public:
    string name;
    int AT;
    int BT;
    int BRT;
    int CT;
    int TAT;
    int WT;
    bool isComplete, inQueue;
};

void Calculate_TAT_And_WT(vector<processor>& processorList)
{
    for (auto& processor : processorList)
    {
        processor.TAT = processor.CT- processor.AT;
        processor.WT = processor.TAT - processor.BT;
    }
}

void checkNewArrivalProcess(vector<processor>& processorList, queue<int>& readyQueue, int& currentTime, int& executedPrograms)
{
    for (int i = 0; i < processorList.size(); i++)
    {
        processor process = processorList[i];
        if (process.AT <= currentTime && !process.isComplete && !process.inQueue)
        {
            processorList[i].inQueue = true;
            readyQueue.push(i);
            executedPrograms += 1;
        }
    }
}

void updateQueue(vector<processor>& processorList,queue<int>& readyQueue, int& timeQuantum, int& currentTime, int& executedPrograms)
{
    int i = readyQueue.front();
    readyQueue.pop();
    if (processorList[i].BRT <= timeQuantum)
    {
        processorList[i].isComplete = true;
        currentTime += processorList[i].BRT;
        processorList[i].CT = currentTime;
        processorList[i].BRT = 0;
        if (executedPrograms != processorList.size())
        {
            checkNewArrivalProcess(processorList, readyQueue, currentTime, executedPrograms);
        }
    }
    else
    {
        processorList[i].BRT -= timeQuantum;
        currentTime += timeQuantum;
        if (executedPrograms != processorList.size())
        {
            checkNewArrivalProcess(processorList, readyQueue, currentTime, executedPrograms);
        }
        readyQueue.push(i);
    }
}

void roundRobin_Algorithm(vector<processor>& processorList, int& timeQuantum)
{
    sort(processorList.begin(), processorList.end(), [](processor& a, processor& b)
        {
        return a.AT < b.AT;
        });

    queue<int> readyQueue;
    readyQueue.push(0);
    processorList[0].inQueue = true;
    int currentTime = 0, executedPrograms = 0;
    while (!readyQueue.empty())
    {
        updateQueue(processorList, readyQueue, timeQuantum, currentTime, executedPrograms);
    }
}

int main()
{
    int processorSize, timeQuantum;
    cout << "Enter the number of Processor : ";
    cin >> processorSize;
    cout << "Enter Time Quantum : ";
    cin >> timeQuantum;
    vector<processor> processorList(processorSize);

    cout << "Enter the Processor Name, Arival Time & Burst Time:";
    for (int i = 0; i < processorSize; i++)
    {
        cin >> processorList[i].name >> processorList[i].AT >> processorList[i].BT;
        processorList[i].BRT = processorList[i].BT;
    }

    roundRobin_Algorithm(processorList, timeQuantum);
    Calculate_TAT_And_WT(processorList);

    cout<<"\nName\t AT\t BT\t CT\t TAT\t WT\n";

    for (auto& processor : processorList)
    {
        cout<<processor.name<<'\t'<<processor.AT<<'\t'<<processor.BT<<'\t'<<processor.CT<<'\t'<<processor.TAT<<'\t'<<processor.WT<<'\n';
    }
}
