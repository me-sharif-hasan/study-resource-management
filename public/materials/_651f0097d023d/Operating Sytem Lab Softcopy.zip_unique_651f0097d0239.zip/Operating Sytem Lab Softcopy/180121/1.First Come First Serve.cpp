#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cout<<"Number of Process: ";
    cin>>n;
    int processId[n], At[n], bt[n], ct[n], tat[n], wt[n];
    for(int i=0;i<n;i++){
        cout<<"insert "<<i+1<<" no. process arrival time and brust time: ";
        cin>>At[i]>>bt[i];
    }

    //Calculating CT
    //--------------------------

    ct[0] = At[0] + bt[0];
    for(int i = 1;i<n;i++){
        if(ct[i-1]>At[i]){
            ct[i] = ct[i-1] + bt[i];
        }else{
            ct[i] = At[i] + bt[i];
        }
    }

    //--------------------------

    for(int i=0;i<n;i++){
        tat[i] = ct[i] - At[i];
        wt[i] = tat[i] - bt[i];
    }

    double totalwt = 0;
    for(int i=0;i<n;i++){
        cout<<"process No: "<<i+1<<"\t AT-"<<At[i]<<" BT-"<<bt[i]<<" CT-"<<ct[i]<<" TAT-"<<tat[i]<<" WT-"<<wt[i]<<endl;
        totalwt += wt[i];
    }

    cout<<"\nAverage waiting time: "<<totalwt/n<<endl;
}
