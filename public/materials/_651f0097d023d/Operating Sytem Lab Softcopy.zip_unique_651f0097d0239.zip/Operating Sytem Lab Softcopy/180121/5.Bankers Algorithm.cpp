#include <bits/stdc++.h>
using namespace std;

int main()
{
    int pSize = 5, rSize = 3 ,flag,pointer = 0;
    int sequence[pSize],finish[pSize]={0},need[pSize][rSize];

    int allocResource[pSize][rSize] = {
                                         { 0, 1, 0 },
                                         { 2, 0, 0 },
                                         { 3, 0, 2 },
                                         { 2, 1, 1 },
                                         { 0, 0, 2 }
                                      };

    int max[pSize][rSize] = {
                              { 7, 5, 3 },
                              { 3, 2, 2 },
                              { 9, 0, 2 },
                              { 2, 2, 2 },
                              { 4, 3, 3 }
                            };

    int available[rSize] = { 3, 3, 2 };

    for(int i = 0; i<pSize; i++)
    {
    	for(int j = 0; j < rSize; j++)
    	{
    		need[i][j] = max[i][j]-allocResource[i][j];
    	}
    }


    for(int i = 0; i < pSize; i++)
    {
    	flag = 0;
    	if(finish[i] == 0)
    	{
    		for(int j = 0; j < rSize; j++)
    		{
    			if(need[i][j] > available[j])
    			{
    				flag = 1;
    				break;
    			}
    		}

            if(flag == 0)
            {
                finish[i] = 1;
                sequence[pointer++] = i;
                for(int j = 0; j<rSize;j++)
                {
                    available[j] += allocResource[i][j];
                }
                if(i == pSize-1)
                {
                   i = -1;
                }
            }
    	}
    }

    bool check = true;
    for(int i = 0; i<pSize;i++)
    {
        if(finish[i] == 0)
        {
           check = false;
           cout << "The given sequence is not safe";
		   break;
        }
    }

    if(check)
    {
       for(int i = 0; i<pSize;i++)
       {
          cout<<"P"<<sequence[i]<<" ";
       }
      cout<<'\n';
    }
}
