#include <bits/stdc++.h>

using namespace std;

int pn,partitionNumber;

void FirstFit(vector<int>&processes,vector<int>&partitions,vector<int>&memoryFilled,vector<int>&frag){
	for(int i=0;i<pn;i++){
		for(int j=0;j<partitionNumber;j++){
			if(frag[j] == -1 && partitions[j]>=processes[i]){
                memoryFilled[j] = i;
                frag[j] = partitions[j]-processes[i];
                break;
			}
		}
	}
}

void BestFit(vector<int>&processes,vector<int>&partitions,vector<int>&memoryFilled,vector<int>&frag){
	for(int i = 0; i<pn;i++){
		int bestIndex = -1;
		for(int j = 0; j<partitionNumber;j++){
			if(frag[j] == -1 && partitions[j]>= processes[i]){
				if(bestIndex == -1){
					bestIndex = j;
				}
				else{
					if((partitions[bestIndex] - processes[i]) > (partitions[j] - processes[i])){
						bestIndex = j;
					}
				}
			}
		}
		if(bestIndex != -1){
           memoryFilled[bestIndex] = i;
           frag[bestIndex] = partitions[bestIndex] - processes[i];
		}
	}
}

void WorstFit(vector<int>&processes,vector<int>&partitions,vector<int>&memoryFilled,vector<int>&frag){
	for(int i = 0; i<pn;i++){
		int worstIndex = -1;
		for(int j = 0; j<partitionNumber;j++){
			if(frag[j] == -1 && partitions[j]>= processes[i]){
				if(worstIndex == -1){
					worstIndex = j;
				}
				else{
					if((partitions[worstIndex] - processes[i]) < (partitions[j] - processes[i])){
						worstIndex = j;
					}
				}
			}
		}
		if(worstIndex != -1){
           memoryFilled[worstIndex] = i;
           frag[worstIndex] = partitions[worstIndex] - processes[i];
		}
	}
}

void print(vector<int>&partitions,vector<int>&memoryFilled,vector<int>&frag){
	int totalInternerFrag = 0;

	for(int i=0;i<partitions.size();i++){
		if(frag[i] != -1){
			cout<<"Partitions "<<memoryFilled[i]<<" has frag "<<frag[i]<<"\n";
			totalInternerFrag +=frag[i];
		}
	}
	cout<<"Total Internal frag:"<<totalInternerFrag<<'\n';
}

int main()
{
    cin>>pn>>partitionNumber;

    vector<int>processes(pn),partitions(partitionNumber),memoryFilled(partitionNumber),frag(partitionNumber);

    for(int i = 0; i<pn;i++ ){
    	cin>>processes[i];
    	frag[i] = -1;
    }

    for(int i = 0; i<partitionNumber;i++ ){
    	cin>>partitions[i];
    }

    while(true){
    	int n;
    	cin>>n;
    	switch(n){
    		case 1:
    		FirstFit(processes, partitions, memoryFilled, frag);
    		break;
    		case 2:
    		BestFit(processes, partitions, memoryFilled, frag);
    		break;
    		case 3:
    		WorstFit(processes, partitions, memoryFilled, frag);
    		break;
    		case 4:
    		exit(1);
    		default:
    		cout<<"Wrong Choice\n";
    	}
        print(partitions,memoryFilled,frag);
        break;
    }
}
