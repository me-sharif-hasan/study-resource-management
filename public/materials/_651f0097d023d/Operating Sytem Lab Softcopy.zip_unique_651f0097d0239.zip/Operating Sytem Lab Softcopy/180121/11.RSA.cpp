#include <bits/stdc++.h>
#include <numeric>

using namespace std;

int gcd(int a,int b){
    int _gcd;
    if(b>a){
        swap(a,b);
    }
    for(int i=1;i<a;i++){
        if(a%i==0 && b%i==0){
            _gcd = i;
        }
    }
    return _gcd;
}

int main(){
    int p,q,n,phi,e,d;
    p = 11;
    q = 269;
    int messege;
    cout<<"messege: ";
    cin>>messege;
    n = p*q;
    phi = (p-1)*(q-1);
    e = 2;
    while(e<phi){
        if(gcd(e,phi)==1){
            break;
        }
        e++;
    }

    d = 1;
    int j;
    while(true){
        j = (d*e)%phi;
        if(j==1 || d>phi){
            break;
        }
        d++;
    }

    int encrypted = fmod(pow(messege,e), n);
    int decrypted = fmod(pow(encrypted, d), n);
    cout<<"public: "<<e<<" private: "<<d<<" encrypted: "<<encrypted<<" decrypted: "<<decrypted<<endl;;
}
