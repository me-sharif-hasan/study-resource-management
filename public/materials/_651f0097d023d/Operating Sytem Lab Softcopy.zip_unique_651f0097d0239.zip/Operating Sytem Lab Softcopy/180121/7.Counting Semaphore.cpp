#include <bits/stdc++.h>
using namespace std;

class CountSemaphore
{
public:
    explicit CountSemaphore(int count) : count_(count) {}

    void wait()
    {
        unique_lock<mutex> lock(mutex_);
        while (count_ == 0)
        {
            condition_.wait(lock);
        }
        count_--;
    }

    void signal()
    {
        unique_lock<mutex> lock(mutex_);
        count_++;
        condition_.notify_one();
    }

private:
    int count_;
    mutex mutex_;
    condition_variable condition_;
};

int main()
{
    CountSemaphore semaphore(5);

    for (int i = 0; i < 10; ++i)
    {
        thread([&semaphore, i]()
        {
            semaphore.wait();
            cout << "Thread " << i << " enters the critical section." << '\n';
            this_thread::sleep_for(chrono::seconds(1));
            semaphore.signal();
            cout << "Thread " << i << " exits the critical section." << '\n';
        }).detach();
    }

    this_thread::sleep_for(chrono::seconds(10));
}
