#include<bits/stdc++.h>

using namespace std;

const int maxSize = 1e5;
int priority[maxSize],AT[maxSize],BT[maxSize],RemainingBT[maxSize],CT[maxSize],TAT[maxSize],WT[maxSize],processSize;

void nonPreemptive()
{

    priority_queue<pair<int,int>> readyQueue;

    int lastArrive=0;
    while(AT[lastArrive] <= AT[0])
    {
        readyQueue.push({priority[lastArrive],lastArrive});
        lastArrive++;
    }

    int prevCompleted = readyQueue.top().second;

    CT[prevCompleted] = AT[readyQueue.top().second] + BT[readyQueue.top().second];
    readyQueue.pop();

    for(int i=1;i<processSize;i++)
    {
        while(lastArrive<processSize && AT[lastArrive] <= CT[prevCompleted])
        {
            readyQueue.push({priority[lastArrive],lastArrive});
            lastArrive++;
        }
        if(readyQueue.empty())
        {
            if(lastArrive<processSize)
            {
                readyQueue.push({priority[lastArrive],lastArrive});
                lastArrive++;
            }
            else
            {
                break;
            }
        }

        int current_execution = readyQueue.top().second;
        CT[current_execution] = max(CT[prevCompleted], AT[current_execution])+ BT[current_execution];
        prevCompleted = current_execution;
        readyQueue.pop();
    }
}

void preemptive()
{
    int timeQuantam = 2,time = 0;
    int numberOfCompleteProcess = 0;

    priority_queue<pair<int,int>> readyQueue;

    int lastArrive=0;

    while(AT[lastArrive] <= AT[0])
    {
        readyQueue.push({priority[lastArrive],lastArrive});
        lastArrive++;
    }

    while(numberOfCompleteProcess < processSize)
    {
        while(lastArrive<processSize && AT[lastArrive] <= time)
        {
            readyQueue.push({priority[lastArrive],lastArrive});
            lastArrive++;
        }
        if(readyQueue.empty())
        {
            if(lastArrive < processSize)
            {
                readyQueue.push({priority[lastArrive],lastArrive});
                time = AT[lastArrive];
                lastArrive++;
            }
            else
            {
                break;
            }
        }

        int current_execution = readyQueue.top().second;

        if(RemainingBT[current_execution] <= timeQuantam)
        {
            CT[current_execution] = time + RemainingBT[current_execution];
            time = CT[current_execution];
            numberOfCompleteProcess++;
            readyQueue.pop();
        }
        else
        {
            RemainingBT[current_execution] -= timeQuantam;
            time += timeQuantam;
        }
    }
}

int main()
{

    int choice;
    cout << "Enter the number of Processor : ";
    cin>>processSize;

    cout << "Enter Process Priority, Arival Time, Burst Time:";
    for(int i=0;i<processSize;i++)
    {
        cin>>priority[i]>>AT[i]>>BT[i];
        RemainingBT[i] = BT[i];
    }

    takeChoice:
    cout<<"Enter your choice: ";
    cin>>choice;

    switch(choice)
    {
        case 1:
            preemptive();
            break;
        case 2:
            nonPreemptive();
            break;
        default:
            cout<<"Wrong choice."<<'\n';;
            goto takeChoice;
    }

    for(int i=0; i<processSize; i++)
    {
        TAT[i] = CT[i] - AT[i];
        WT[i] = TAT[i] - BT[i];
    }

    cout<<"\nAT\t BT\t CT\t TAT\t WT\n";
    for(int i=0;i<processSize;i++)
    {
      cout<<AT[i]<<'\t'<<BT[i]<<'\t'<<CT[i]<<'\t'<<TAT[i]<<'\t'<<WT[i]<<'\n';;
    }
}
