#include <bits/stdc++.h>
int Lock = 1, capacity = 100, Fill = 0, product = 0;
using namespace std;

void producer()
{
	--Lock;
	--capacity;
	++Fill;
	++product;
	cout<<"Producer produces product "<<product<<'\n';
	++Lock;
}

void consumer()
{
	--Lock;
	++capacity;
	--Fill;
	cout<<"Consumer consumes product "<<product<<'\n';
	--product;
	++Lock;
}

int main()
{
    while(true)
    {
        int choice;
        cin>>choice;
        switch(choice)
        {
        	case 1:
	        	if (Lock == 1 && capacity != 0)
	        	{
	        		producer();
	        	}
	        	else
	        	{
                    cout<<"Buffer is full!\n";
	        	}
	        	break;
	        case 2:
	        	if (Lock == 1 && Fill != 0)
	        	{
	        		consumer();
	        	}
	        	else
	        	{
                    cout<<"Buffer is empty\n";
	        	}
	        	break;
	        case 3:
	            exit(0);

	        default:
	            cout<<"Wrong Choice. Try again !!\n";
	            break;
        }
    }
}
