#include <bits/stdc++.h>
using namespace std;

int frameSize,pageSize,hit=0,miss=0;

void opr(vector<int>&pages)
{
    set<int> frames;
    vector<int>::iterator it;

    for(int i = 0;i<pages.size();i++)
    {
        if(frames.find(pages[i]) != frames.end())
        {
            hit++;
        }
        else
        {
            if(frames.size()< frameSize)
            {
                frames.insert(pages[i]);
                miss++;
            }
            else
            {
                int current_page = pages[i], next_index = i+1, frameFound = 0, page_found = 0, page_not_found = 0, least_demand_page = INT_MIN, pageIndex;
                for(auto frame : frames)
                {
                    it = find(pages.begin()+next_index,pages.end(),frame);
                    if(it != pages.end())
                    {
                        frameFound++;
                        pageIndex = it - pages.begin()+next_index;
                        if(pageIndex > least_demand_page )
                        {
                            least_demand_page = pageIndex;
                            page_found = *it;
                        }
                    }
                    else
                    {
                        page_not_found = frame;
                        break;
                    }
                }
                if(frameSize == frameFound)
                {
                    frames.erase(page_found);
                }
                else
                {
                    frames.erase(page_not_found);
                }
                frames.insert(current_page);
                miss++;
            }
        }
    }
}

int main()
{
    cin>>frameSize>>pageSize;
    vector<int>pages(pageSize);

    for(int i=0;i<pageSize;i++)
    {
        cin>>pages[i];
    }

    opr(pages);

    cout<<"Hit: "<<hit<<" Miss: "<<miss<<'\n';
}
