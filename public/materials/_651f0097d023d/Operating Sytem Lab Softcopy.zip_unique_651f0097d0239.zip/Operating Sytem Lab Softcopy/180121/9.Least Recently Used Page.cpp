#include <bits/stdc++.h>
using namespace std;

int hit=0,miss=0;

void lru(vector<int>&pages, int frameSize)
{
	unordered_set<int> frame;
	unordered_map<int,int>pageIndex;

	for(int i = 0; i<pages.size(); i++ )
	{
		if(frame.find(pages[i]) != frame.end())
		{
            hit++;
		}
		else
		{
           if(frame.size()<frameSize)
           {
           	   frame.insert(pages[i]);
           	   miss++;
           }
           else
           {
               int last_demand_page = INT_MAX, value = 0;
               for(auto it : frame)
               {
               	   if(last_demand_page > pageIndex[it])
               	   {
               	   	   last_demand_page = pageIndex[it];
               	   	   value = it;
               	   }
               }
               frame.erase(value);
               frame.insert(pages[i]);
               miss++;
           }
		}
		pageIndex[pages[i]] = i;
	}
}

int main()
{
    int pageSize,frameSize;
    cin>>frameSize>>pageSize;
    vector<int>pages(pageSize);

    for(int i = 0; i<pages.size();i++)
    {
    	cin>>pages[i];
    }

    lru(pages, frameSize);

    cout<<"Hit: "<<hit<<" Miss: "<<miss<<'\n';
}
