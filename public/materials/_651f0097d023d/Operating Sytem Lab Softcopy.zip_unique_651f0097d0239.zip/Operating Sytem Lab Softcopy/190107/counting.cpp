#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

using namespace std;

class CountingSemaphore {
public:
    CountingSemaphore(int count) : count_(count) {}

    void acquire() {
        unique_lock<mutex> lock(mutex_);
        while (count_ == 0) {
            condition_.wait(lock);
        }
        count_--;
    }

    void release() {
        unique_lock<mutex> lock(mutex_);
        count_++;
        condition_.notify_one();
    }

private:
    int count_;
    mutex mutex_;
    condition_variable condition_;
};

void producer(CountingSemaphore& sem) {
    for (int i = 0; i < 5; i++) {
        sem.release(); // Increase the count
        cout << "Produced item " << i << endl;
        this_thread::sleep_for(chrono::milliseconds(200));
    }
}

void consumer(CountingSemaphore& sem) {
    for (int i = 0; i < 5; i++) {
        sem.acquire(); // Decrease the count
        cout << "Consumed item " << i << endl;
        this_thread::sleep_for(chrono::milliseconds(300));
    }
}

int main() {
    CountingSemaphore sem(3); // Initialize the semaphore with a count of 3

    thread producerThread(producer, ref(sem));
    thread consumerThread(consumer, ref(sem));

    producerThread.join();
    consumerThread.join();

    return 0;
}
