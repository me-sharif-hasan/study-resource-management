#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

// Structure to represent a process
struct Process {
    int id;
    int arrivalTime;
    int burstTime;
    int priority;
};

// Function to compare processes based on priority and arrival time
struct ComparePriority {
    bool operator()(const Process& p1, const Process& p2) {
        return p1.priority > p2.priority; // Higher priority processes come first
    }
};

int main() {
    int n; // Number of processes
    cout << "Enter the number of processes: ";
    cin >> n;

    vector<Process> processes(n);

    // Input process information
    for (int i = 0; i < n; i++) {
        processes[i].id = i + 1;
        cout << "Enter arrival time for process P" << processes[i].id << ": ";
        cin >> processes[i].arrivalTime;
        cout << "Enter priority for process P" << processes[i].id << ": ";
        cin >> processes[i].priority;
        cout << "Enter burst time for process P" << processes[i].id << ": ";
        cin >> processes[i].burstTime;
    }

    // Sort processes by arrival time
    sort(processes.begin(), processes.end(), [](const Process& p1, const Process& p2) {
        return p1.arrivalTime < p2.arrivalTime;
    });

    priority_queue<Process, vector<Process>, ComparePriority> pq;
    int currentTime = 0;
    int totalWaitingTime = 0;
    int totalTurnaroundTime = 0;

    vector<int> remainingTime(n, 0);

    for (int i = 0; i < n; i++) {
        remainingTime[i] = processes[i].burstTime;
    }

    int completed = 0;
    while (completed < n) {
        // Check for newly arrived processes and add them to the queue
        for (int i = 0; i < n; i++) {
            if (processes[i].arrivalTime <= currentTime && remainingTime[i] > 0) {
                pq.push(processes[i]);
            }
        }

        if (pq.empty()) {
            currentTime++;
            continue;
        }

        // Get the highest priority process from the queue
        Process currentProcess = pq.top();
        pq.pop();

        // Run the process for 1 time unit (preemptive)
        currentTime++;
        remainingTime[currentProcess.id - 1]--;

        // Check if the process has finished executing
        if (remainingTime[currentProcess.id - 1] == 0) {
            completed++;
            int turnaroundTime = currentTime - currentProcess.arrivalTime;
            int waitingTime = turnaroundTime - currentProcess.burstTime;

            totalWaitingTime += waitingTime;
            totalTurnaroundTime += turnaroundTime;
        }
    }

    // Calculate average waiting time and average turnaround time
    double averageWaitingTime = static_cast<double>(totalWaitingTime) / n;
    double averageTurnaroundTime = static_cast<double>(totalTurnaroundTime) / n;

    // Display the results
    cout << "\nProcess\tArrival Time\tPriority\tBurst Time\tWaiting Time\tTurnaround Time\n";
    for (int i = 0; i < n; i++) {
        cout << "P" << processes[i].id << "\t" << processes[i].arrivalTime << "\t\t"
             << processes[i].priority << "\t\t" << processes[i].burstTime << "\t\t"
             << (totalWaitingTime / n) << "\t\t" << (totalTurnaroundTime / n) << endl;
    }

    cout << "\nAverage Waiting Time: " << averageWaitingTime << endl;
    cout << "Average Turnaround Time: " << averageTurnaroundTime << endl;

    return 0;
}
