#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <condition_variable>

using namespace std;

const int BUFFER_SIZE = 5;
vector<int> buffer(BUFFER_SIZE);
int itemCount = 0;
int in = 0; // Index for inserting into the buffer
int out = 0; // Index for taking from the buffer

mutex mtx;
condition_variable notFull, notEmpty;

void producer(int id) {
    for (int i = 0; i < 10; i++) {
        unique_lock<mutex> lock(mtx);

        // Wait if the buffer is full
        notFull.wait(lock, [] { return itemCount < BUFFER_SIZE; });

        int item = rand() % 100; // Generate a random item
        buffer[in] = item;
        in = (in + 1) % BUFFER_SIZE;
        itemCount++;

        cout << "Producer " << id << " produced item " << item << endl;

        // Notify consumers that the buffer is not empty
        notEmpty.notify_all();
    }
}

void consumer(int id) {
    for (int i = 0; i < 10; i++) {
        unique_lock<mutex> lock(mtx);

        // Wait if the buffer is empty
        notEmpty.wait(lock, [] { return itemCount > 0; });

        int item = buffer[out];
        out = (out + 1) % BUFFER_SIZE;
        itemCount--;

        cout << "Consumer " << id << " consumed item " << item << endl;

        // Notify producers that the buffer is not full
        notFull.notify_all();
    }
}

int main() {
    const int numProducers = 2;
    const int numConsumers = 2;

    vector<thread> producerThreads;
    vector<thread> consumerThreads;

    for (int i = 0; i < numProducers; i++) {
        producerThreads.emplace_back(producer, i);
    }

    for (int i = 0; i < numConsumers; i++) {
        consumerThreads.emplace_back(consumer, i);
    }

    for (auto& thread : producerThreads) {
        thread.join();
    }

    for (auto& thread : consumerThreads) {
        thread.join();
    }

    return 0;
}
