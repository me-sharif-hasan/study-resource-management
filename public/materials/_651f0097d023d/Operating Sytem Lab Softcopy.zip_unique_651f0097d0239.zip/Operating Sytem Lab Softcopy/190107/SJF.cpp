#include<bits/stdc++.h>
#include<math.h>
using namespace std;

int main()
{
    int i,j,n,p[100]={0},tt,d,min,at[100]={0},bt[100]={0},ct[100]={0},wt[100]={0},tat[100]={0},ttat=0,twt=0;
    double avgtat,avgwt;

    cout<<"enter process no:";
    cin>>n;
    cout<<"enter process:";
    for(i=0;i<n;i++)
    cin>>p[i];
    cout<<"enter arrival time:";
    for(i=0;i<n;i++)
    cin>>at[i];
    cout<<"enter burst time:";
    for(i=0;i<n;i++)
    cin>>bt[i];

    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(bt[i]>bt[j])
            {
                swap(p[i],p[j]);
                swap(bt[i],bt[j]);
                swap(at[i],at[j]);
            }
        }
    }

    min=at[0];
    for(i=0;i<n;i++)
    {
        if(min>at[i])
        {
            min=at[i];
            d=i;
        }
    }
    tt=min;
    ct[d]=tt+bt[d];
    tt=ct[d];

    for(i=0;i<n;i++)
    {
        if(at[i]!=min)
        {
            ct[i]=bt[i]+tt;
            tt=ct[i];
        }
    }
     for( i=0;i<n;i++)
    {
        tat[i]=ct[i]-at[i];
        ttat+=tat[i];
        wt[i]=tat[i]-bt[i];
        twt+=wt[i];
    }

     cout<<"Process  Arrival-time(s)  Burst-time(s)  Waiting-time(s)  Turnaround-time(s)\n";
     for(i=0;i<n;i++)
     {
         cout<<"p"<<p[i]<<"     "<<at[i]<<"       "<<bt[i]<<"    "<<wt[i]<<"    "<<tat[i] <<endl;
     }
}


