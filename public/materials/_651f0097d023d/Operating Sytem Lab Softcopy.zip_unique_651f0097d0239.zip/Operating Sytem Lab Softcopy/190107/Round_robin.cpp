#include<iostream>

using namespace std;
int main()
{
      int i,j,n,qt,count=0,temp,ct=0,p[100],at[100],bt[100],rem_bt[100],tat[100],wt[100];
      float atat=0,awt=0;

      cout<<"enter no of process";
      cin>>n;
cout<<"enter process ";
      for(i=0;i<n;i++)
      {
                   //input
            cin>>p[i];
      }
cout<<"enter arival time ";
      for(i=0;i<n;i++)
      {
                   //input
            cin>>at[i];
      }
       cout<<"enter brust time ";
      for(i=0;i<n;i++)
      {
                //input
            cin>>bt[i];
            rem_bt[i]=bt[i];

      }
      cout<<"enter quantam time ";
      cin>>qt;
      for(i=0;i<n;i++)
      {
         for(j=i+1;j<n;j++)
          {
                if(at[i]>at[j])
                {


                      temp=bt[i];
                      bt[i]=bt[j];
                      bt[j]=temp;

                      temp=rem_bt[i];
                      rem_bt[i]=rem_bt[j];
                      rem_bt[j]=temp;

                      temp=p[i];
                      p[i]=p[j];
                      p[j]=temp;

                      temp=at[i];
                      at[i]=at[j];
                      at[j]=temp;

                }
          }
      }

      while(true)
      {
          for(i=0, count=0;i<n;i++){
          temp=qt;
          if(rem_bt[i]==0)
            {
            count++;
          continue;
          }
          if(rem_bt[i]>qt)
          {
              rem_bt[i]=rem_bt[i]-qt;
          }
          else

              if(rem_bt[i]>=0)
              {
                  temp=rem_bt[i];
                  rem_bt[i]=0;
              }
              ct+=temp;
          tat[i]=ct-at[i];
      }
      if(n==count)

              break;
      }
      for(i=0;i<n;i++)
      {

            atat+=tat[i];

            wt[i]=tat[i]-bt[i];
            awt+=wt[i];
      }

      cout<<"Process  Arrival-time(s)  Burst-time(s)  Waiting-time(s)  Turnaround-time(s)\n";

    for(i=0;i<n;i++)
    {
    cout<<"P"<<i+1<<"              "<<at[i]<<"                "<<bt[i]<<"                  "<<wt[i]<<"               "<<tat[i]<<endl;
    }
atat=atat/n;
      awt=awt/n;
    cout<<"awt="<<awt<<" atat="<<atat;  //average waiting time and turn around time
}
