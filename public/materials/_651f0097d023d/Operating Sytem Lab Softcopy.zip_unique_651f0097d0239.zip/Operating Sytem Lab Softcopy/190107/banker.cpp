#include <iostream>
#include <vector>

using namespace std;

const int MAX_PROCESSES = 100;
const int MAX_RESOURCES = 100;

int numProcesses, numResources;
int available[MAX_RESOURCES];
int maximum[MAX_PROCESSES][MAX_RESOURCES];
int allocation[MAX_PROCESSES][MAX_RESOURCES];
int need[MAX_PROCESSES][MAX_RESOURCES];

// Function to check if a process can request resources and still be in a safe state
bool isSafe(int process, int request[]) {
    // Check if the request is within the process's maximum claim
    for (int i = 0; i < numResources; i++) {
        if (request[i] > need[process][i]) {
            return false; // Request exceeds the maximum claim
        }
    }

    // Try allocating the resources to the process temporarily
    for (int i = 0; i < numResources; i++) {
        available[i] -= request[i];
        allocation[process][i] += request[i];
        need[process][i] -= request[i];
    }

    // Check if the system is still in a safe state
    vector<bool> finish(numProcesses, false);
    int work[MAX_RESOURCES];
    for (int i = 0; i < numResources; i++) {
        work[i] = available[i];
    }

    bool canFinish = true;

    while (canFinish) {
        canFinish = false;

        for (int i = 0; i < numProcesses; i++) {
            if (!finish[i]) {
                bool canAllocate = true;

                for (int j = 0; j < numResources; j++) {
                    if (need[i][j] > work[j]) {
                        canAllocate = false;
                        break;
                    }
                }

                if (canAllocate) {
                    for (int j = 0; j < numResources; j++) {
                        work[j] += allocation[i][j];
                    }

                    finish[i] = true;
                    canFinish = true;
                }
            }
        }
    }

    // Restore the state
    for (int i = 0; i < numResources; i++) {
        available[i] += request[i];
        allocation[process][i] -= request[i];
        need[process][i] += request[i];
    }

    // If all processes finish, the request is granted
    for (int i = 0; i < numProcesses; i++) {
        if (!finish[i]) {
            return false;
        }
    }

    return true;
}

int main() {
    cout << "Enter the number of processes: ";
    cin >> numProcesses;
    cout << "Enter the number of resources: ";
    cin >> numResources;

    cout << "Enter the available resources:" << endl;
    for (int i = 0; i < numResources; i++) {
        cin >> available[i];
    }

    cout << "Enter the maximum claim matrix:" << endl;
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            cin >> maximum[i][j];
        }
    }

    cout << "Enter the allocation matrix:" << endl;
    for (int i = 0; i < numProcesses; i++) {
        for (int j = 0; j < numResources; j++) {
            cin >> allocation[i][j];
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }

    int process;
    cout << "Enter the process number making a request: ";
    cin >> process;

    int request[MAX_RESOURCES];
    cout << "Enter the request for resources:" << endl;
    for (int i = 0; i < numResources; i++) {
        cin >> request[i];
    }

    if (isSafe(process, request)) {
        cout << "Request granted. The system is in a safe state." << endl;
    } else {
        cout << "Request denied. The system will not be in a safe state." << endl;
    }

    return 0;
}
