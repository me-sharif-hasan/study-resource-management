#include<iostream>
using namespace std;

int main()
{
    int p=3,b=5;
    int pp[3]={5,2,5},bb[5]={2,3,1,5,1};
    int flag[5]={0},al[5]={0},a[3]={0};


    for(int i=0;i<p;i++)
    {
        for(int j=0;j<b;j++)
        {
            if(flag[j]==0 && bb[j]>=pp[i])
            {
                a[i]=j;
                flag[j]=1;
                al[i]=pp[i];
                break;
            }
        }
    }

    for(int i=0;i<p;i++)
    {
        if(al[i]!=0)
        {
            cout<<al[i]<<" is allocated location : "<<a[i]<<endl;
        }
    }
}
