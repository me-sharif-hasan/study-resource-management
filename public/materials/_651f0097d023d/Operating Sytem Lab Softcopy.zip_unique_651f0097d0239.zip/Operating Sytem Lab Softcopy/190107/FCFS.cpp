#include<bits/stdc++.h>
using namespace std;

int main()
{
    int i,j,n,p[100]={0},wt[100]={0},tat[100]={0},temp,ct[100]={0},sum=0,at[100]={0},bt[100]={0},ttat=0,twt=0;
    float attat=0,atwt=0;

    cout<<"enter process no";
    cin>>n;
    cout<<"process id: ";
    for(i=0;i<n;i++)
        cin>>p[i];
    cout<<"arrival time:";
    for(i=0;i<n;i++)
        cin>>at[i];
    cout<<"burst time: ";
    for(i=0;i<n;i++)
    cin>>bt[i];

    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(at[i]>at[j])
            {
                temp=at[i];
                at[i]=at[j];
                at[j]=temp;

                temp=bt[i];
                bt[i]=bt[j];
                bt[j]=temp;

                temp=p[i];
                p[i]=p[j];
                p[j]=temp;

            }
        }
    }

    for(i=0;i<n;i++)
    {
        sum=sum+bt[i];
        ct[i]=sum;
    }

    for( i=0;i<n;i++)
    {
        tat[i]=ct[i]-at[i];
        ttat+=tat[i];
        wt[i]=tat[i]-bt[i];
        twt+=wt[i];
    }

     cout<<"Process  Arrival-time(s)  Burst-time(s)  Waiting-time(s)  Turnaround-time(s)\n";
     for(i=0;i<n;i++)
     {
         cout<<"p"<<i+1<<"     "<<at[i]<<"       "<<bt[i]<<"    "<<wt[i]<<"    "<<tat[i] <<endl;
     }
}
