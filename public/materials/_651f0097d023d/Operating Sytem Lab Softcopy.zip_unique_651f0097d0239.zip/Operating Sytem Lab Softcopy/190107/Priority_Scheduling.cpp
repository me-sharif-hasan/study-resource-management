#include<bits/stdc++.h>
using namespace std;

int main()
{
    int i,j,n,p[100]={0},min,pr[100]={0},wt[100]={0},ct[100]={0},tat[100]={0},temp,sum=0,at[100]={0},bt[100]={0},ttat=0,twt=0;
    float attat=0,atwt=0;
int d;
    cout<<"enter process no";
    cin>>n;
    cout<<"process id: ";
    for(i=0;i<n;i++)
        cin>>p[i];
    cout<<"arrival time:";
    for(i=0;i<n;i++)
        cin>>at[i];
    cout<<"burst time: ";
    for(i=0;i<n;i++)
    cin>>bt[i];

    cout<<"priority time: ";
    for(i=0;i<n;i++)
    cin>>pr[i];


    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(pr[i]>pr[j])
            {
                swap(p[i],p[j]);
                swap(pr[i],pr[j]);
                swap(bt[i],bt[j]);
                swap(at[i],at[j]);
            }
        }
    }

    min=at[0];
    for(i=0;i<n;i++)
    {
        if(min>at[i])
        {
            min=at[i];
         d=i;
        }
    }
    int tt=min;
    ct[d]=tt+bt[d];
    tt=ct[d];

    for(i=0;i<n;i++)
    {
        if(at[i]!=min)
        {
            ct[i]=bt[i]+tt;
            tt=ct[i];
        }
    }
     for( i=0;i<n;i++)
    {
        tat[i]=ct[i]-at[i];
        ttat+=tat[i];
        wt[i]=tat[i]-bt[i];
        twt+=wt[i];
    }

     cout<<"Process  Arrival-time(s)  Burst-time(s)  Waiting-time(s)  Turnaround-time(s)\n";
     for(i=0;i<n;i++)
     {
         cout<<"p"<<p[i]<<"     "<< pr[i]<<"      " <<at[i]<<"       "<<bt[i]<<"    "<<wt[i]<<"    "<<tat[i] <<endl;
     }
}
