#include <bits/stdc++.h>
using namespace std;

const int N=100005;

struct process
{
    int priority,id,BT,AT,WT,FT,TAT;

};

int n;
process P[N];

bool operator<(process A, process B)
{
    if(A.priority < B.priority)
    {
        return true;
    }
    if(A.priority == B.priority)
    {
        return A.AT < B.AT;
    }
    return false;
}


void Priority(void)
{
    sort(P, P+n);
    double total_WT = 0.0;
    double total_TAT = 0.0;

    for(int i=0; i<n; i++)
    {
        P[i].FT = P[i-1].FT + P[i].BT;
        P[i].TAT = P[i].FT - P[i].AT;
        P[i].WT = P[i].TAT - P[i].BT;

        total_WT += P[i].WT;
        total_TAT += P[i].TAT;
    }
    cout<<fixed<<setprecision(2);
    cout<<"Average Waiting Time: "<<(total_WT/n)<<"\n";
    cout<<"Average Turn Around Time: "<<(total_TAT/n)<<"\n";
    return;
}

int main()
{
    cout<<"Number of P: ";
    cin>>n;

    cout<<"Process Ids:\n";
    for(int i=0; i<n; i++) cin>>P[i].id;

    cout<<"Process Burst Times:\n";
    for(int i=0; i<n; i++) cin>>P[i].BT;

    cout<<"Process Arrival Times:\n";
    for(int i=0; i<n; i++) cin>>P[i].AT;

    cout<<"Process Priorities:\n";
    for(int i=0; i<n; i++) cin>>P[i].priority;

    Priority();

    return 0;
}
