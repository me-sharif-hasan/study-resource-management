#include <bits/stdc++.h>
using namespace std;

const int N=100005;

int n,QT;
struct process
{
    int id;
    int BT;
    int AT;
    int WT;
    int FT;
    int TAT;
    int RT;
};
process P[N];

void RoundRobin()
{
    int complete,current_time,change;
    double total_WT = 0.0;
    double total_TAT = 0.0;

    for(int i=0; i<n; i++)
        P[i].RT = P[i].BT;

    complete = 0;
    current_time = 0;

    while(complete < n)
    {
        change = 0;
        for(int i=0; i<n; i++)
        {
            if(P[i].AT <= current_time && P[i].RT > 0)
            {
                if(P[i].RT <= QT)
                {
                    complete++;
                    current_time += P[i].RT;

                    P[i].FT = current_time;
                    P[i].TAT = P[i].FT - P[i].AT;
                    P[i].WT = P[i].TAT - P[i].BT;

                    total_WT += P[i].WT;
                    total_TAT += P[i].TAT;

                    P[i].RT = 0;
                }
                else
                {
                    current_time += QT;
                    P[i].RT -= QT;
                }
                change++;
            }
        }
        if(change == 0)
        {
            current_time++;
        }
    }
    cout<<fixed<<setprecision(2);
    cout<<"Average Waiting Time: "<<(total_WT/n)<<"\n";
    cout<<"Average Turn Around Time: "<<(total_TAT/n)<<"\n";
    return;
}

int main()
{
    cout<<"Number of Processes: ";
    cin>>n;

    cout<<"Quantum time: ";
    cin>>QT;

    cout<<"Process Ids:\n";
    for(int i=0; i<n; i++) cin>>P[i].id;

    cout<<"Process Burst Times:\n";
    for(int i=0; i<n; i++) cin>>P[i].BT;

    cout<<"Process Arrival Times:\n";
    for(int i=0; i<n; i++) cin>>P[i].AT;

    RoundRobin();

    return 0;
}
