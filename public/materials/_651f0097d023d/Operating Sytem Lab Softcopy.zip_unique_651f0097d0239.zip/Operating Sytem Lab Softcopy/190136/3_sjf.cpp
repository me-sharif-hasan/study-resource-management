#include <bits/stdc++.h>
using namespace std;

const int N=100005;

int n;
struct process
{
    int id;
    int BT;
    int AT;
    int WT;
    int FT;
    int TAT;
};
process P[N];

void SJF()
{
    int complete,current_time,index,minimum;
    double total_WT = 0.0;
    double TAT = 0.0;

    index = -1;
    complete = 0;
    current_time = 0;
    minimum = INT_MAX;

    while(complete < n)
    {
        for(int i=0; i<n; i++)
        {
            if(P[i].AT <= current_time)
            {
                if(P[i].BT < minimum && P[i].FT == 0)
                {
                    index = i;
                    minimum = P[i].BT;
                }
            }
        }

        if(index >= 0)
        {
            complete++;
            minimum = INT_MAX;
            current_time += P[index].BT;
            P[index].FT = current_time;
            P[index].TAT = P[index].FT - P[index].AT;
            P[index].WT =  P[index].TAT- P[index].BT;

            total_WT += P[index].WT;
            TAT += P[index].TAT;

            index = -1;
        }
        else
        {
            current_time++;
        }
    }

    cout<<fixed<<setprecision(2);
    cout<<"Average Waiting Time: "<<(total_WT/n)<<"\n";
    cout<<"Average Turn Around Time: "<<(TAT/n)<<"\n";
}

int main()
{
    cout<<"Number of Processes: ";
    cin>>n;

    cout<<"Process Ids:\n";
    for(int i=0; i<n; i++) cin>>P[i].id;

    cout<<"Process Burst Times:\n";
    for(int i=0; i<n; i++) cin>>P[i].BT;

    cout<<"Process Arrival Times:\n";
    for(int i=0; i<n; i++) cin>>P[i].AT;

    SJF();

    return 0;
}
