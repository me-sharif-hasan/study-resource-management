#include <bits/stdc++.h>
using namespace std;


const int P = 5;


const int R = 3;


void calculateNeed(int need[P][R], int maximum[P][R],int allocated[P][R])
{

    for (int i = 0 ; i < P ; i++)
        for (int j = 0 ; j < R ; j++)


            need[i][j] = maximum[i][j] - allocated[i][j];
}


bool isSafe(int pr[], int available[], int maximum[][R],int allocated[][R])
{
    int need[P][R];

    calculateNeed(need, maximum, allocated);

    bool finished[P] = {0};

    int safeSeqenceence[P];

    int work[R];
    for (int i = 0; i < R ; i++)
        work[i] = available[i];
    int count = 0;
    while (count < P)
    {
        bool found = false;
        for (int p = 0; p < P; p++)
        {
            if (finished[p] == 0)
            {
                int j;
                for (j = 0; j < R; j++)
                    if (need[p][j] > work[j])
                        break;

                if (j == R)
                {
                    for (int k = 0 ; k < R ; k++)
                        work[k] += allocated[p][k];

                    safeSeqenceence[count++] = p;

                    finished[p] = 1;

                    found = true;
                }
            }
        }

        if (found == false)
        {
            cout << "System is not in safe state";
            return false;
        }
    }

    cout << "System is in safe state.\nSafe"
         " sequence is: ";
    for (int i = 0; i < P ; i++)
        cout << safeSeqenceence[i] << " ";

    return true;
}

int main()
{
    int pr[] = {0, 1, 2, 3, 4};

    int available[] = {3, 3, 2};

    int maximum[][R] = {{7, 5, 3},
                     {3, 2, 2},
                     {9, 0, 2},
                     {2, 2, 2},
                     {4, 3, 3}};

    int allocated[][R] = {{0, 1, 0},
                      {2, 0, 0},
                      {3, 0, 2},
                      {2, 1, 1},
                      {0, 0, 2}};

    isSafe(pr, available, maximum, allocated);

    return 0;
}
