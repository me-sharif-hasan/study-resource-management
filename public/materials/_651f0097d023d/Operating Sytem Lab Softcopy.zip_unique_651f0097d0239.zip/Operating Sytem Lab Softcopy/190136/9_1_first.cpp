#include<bits/stdc++.h>
using namespace std;


void firstFit(int BLS[], int m,int PS[], int n)
{

    int AL[n];


    memset(AL, -1, sizeof(AL));


    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (BLS[j] >= PS[i])
            {

                AL[i] = j;


                BLS[j] -= PS[i];

                break;
            }
        }
    }

    cout << "\nProcess No.\tProcess Size\tBlock no.\n";
    for (int i = 0; i < n; i++)
    {
        cout << " " << i+1 << "\t\t"
             << PS[i] << "\t\t";
        if (AL[i] != -1)
            cout << AL[i] + 1;
        else
            cout << "Not Allocated";
        cout << endl;
    }
}


int main()
{
    int BLS[] = {100, 500, 200, 300, 600};
    int PS[] = {212, 417, 112, 426};
    int m = sizeof(BLS) / sizeof(BLS[0]);
    int n = sizeof(PS) / sizeof(PS[0]);

    firstFit(BLS, m, PS, n);

    return 0 ;
}
