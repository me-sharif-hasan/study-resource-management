
#include<bits/stdc++.h>
using namespace std;
int main(){



    int n;
     cout<<"Enter No. of process : ";
    cin>>n;
    int pid[n],at[n],bt[n],rbt[n],ct[n],tat[n],wt[n];
    int timeQuantam = 5;

cout<<"Input all process arrival time and burst time:\n ";

    for(int i=0;i<n;i++){
    	 cout<<"Enter "<<i+1<<"th process AT and BT :\n ";

    	cin>>at[i]>>bt[i];
    	rbt[i]=bt[i];
    }
    ct[0]=at[0]+bt[0];
    // completion time calculation
    for(int i=1;i<n;i++){
    	ct[i]=max(at[i],ct[i-1])+bt[i];
    }
    int ttat=0,twt=0,complete = 0;
    // Turn Around time and Waiting time Calculation
    queue<int> que;
    que.push(0);
    int time=at[0],last_arrive=1;
    while(complete < n){
    	int exe_end = que.front();
    	que.pop();
    	bool push_again = false;

        cout<<"P"<<exe_end+1<<endl;

    	if(rbt[exe_end]<=timeQuantam){
    		ct[exe_end] = time+rbt[exe_end];
    		time = ct[exe_end];
    		complete++;
    	}else{
    		rbt[exe_end]-=timeQuantam;
    		time+=timeQuantam;
    		push_again = true;
    	}
    	while(last_arrive<n&&at[last_arrive]<=time){
    		que.push(last_arrive);
    		last_arrive++;
    	}

    	if(push_again){
    		que.push(exe_end);
    	}
    }
    for(int i=0;i<n;i++){
    	tat[i]=ct[i]-at[i];
    	ttat+=tat[i];
    	wt[i]=tat[i]-bt[i];
    	twt+=wt[i];
    }

    // Printing in tabular form
    cout<<"AT"<<'\t'<<"BT"<<'\t'<<"CT"<<'\t'<<"TAT"<<'\t'<<"WT"<<endl;
    cout<<"-----------------------"<<endl;
    for(int i=0;i<n;i++){
    	cout<<at[i]<<'\t'<<bt[i]<<'\t'<<ct[i]<<'\t'<<tat[i]<<'\t'<<wt[i]<<endl;
    }cout<<endl;
    cout<<"Total : "<<"\t"<<ttat<<'\t'<<twt<<endl;

    // Result showing
    cout<<"Average Tarn Around Time : "<<ttat/(n+0.0)<<endl;
    cout<<"Average Waiting Time : "<<twt/(n+0.0)<<endl;

    return 0;
}
