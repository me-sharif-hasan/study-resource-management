

#include<bits/stdc++.h>
using namespace std;

int Mutex = 1;
int full = 0;

int empty = 10, x = 0;

void producer()
{

    --Mutex;

    ++full;

    --empty;

    x++;
    cout<<"\nProducer produces"<<" "<<"item "<<x;

    ++Mutex;
}


void consumer()
{

    --Mutex;

    --full;

    ++empty;
    cout<<"\nConsumer consumes"<<" "<<"item "<<x;

    x--;

    ++Mutex;
}


int main()
{
    int n, i;
    cout<<"\n1. Press 1 for Producer"<<
           "\n2. Press 2 for Consumer"<<
           "\n3. Press 3 for Exit"<<endl;


    for (i = 1; i > 0; i++)
    {

        cout<<"\nEnter your choice:";
        cin>>n;

        switch (n)
        {
        case 1:

            if ((Mutex == 1)
                    && (empty != 0))
            {
                producer();
            }
            else
            {
                printf("Buffer is full!");
            }
            break;

        case 2:

            if ((Mutex == 1)
                    && (full != 0))
            {
                consumer();
            }


            else
            {
                printf("Buffer is empty!");
            }
            break;


        case 3:
            exit(0);
            break;
        }
    }
}

