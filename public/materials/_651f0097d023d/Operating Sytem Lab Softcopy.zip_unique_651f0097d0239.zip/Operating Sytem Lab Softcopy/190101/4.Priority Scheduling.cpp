/*
 *  Problem : Priority Scheduling.cpp
 *  Created by Samim Arefin
*/

#include<bits/stdc++.h>

const int maxSize = 1e5;
int priority[maxSize],AT[maxSize],BT[maxSize],RBT[maxSize],CT[maxSize],TAT[maxSize],WT[maxSize],processSize;

void nonpreemptive()
{

    std::priority_queue<std::pair<int,int>> readyQueue;

    int last_arrive=0;
    while(AT[last_arrive] <= AT[0])
    {
        readyQueue.push({priority[last_arrive],last_arrive});
        last_arrive++;
    }

    int previously_completed = readyQueue.top().second;

    CT[previously_completed] = AT[readyQueue.top().second] + BT[readyQueue.top().second];
    readyQueue.pop();

    for(int i=1;i<processSize;i++)
    {
        while(last_arrive<processSize && AT[last_arrive] <= CT[previously_completed])
        {
            readyQueue.push({priority[last_arrive],last_arrive});
            last_arrive++;
        }
        if(readyQueue.empty())
        {
            if(last_arrive<processSize)
            {
                readyQueue.push({priority[last_arrive],last_arrive});
                last_arrive++;
            }
            else
            {
                break;
            }
        }

        int current_execution = readyQueue.top().second;
        CT[current_execution] = std::max(CT[previously_completed], AT[current_execution])+ BT[current_execution];
        previously_completed = current_execution;
        readyQueue.pop();
    }
}

void preemptive()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int timeQuantam = 2,time = 0;
    int numberOfCompleteProcess = 0;

    std::priority_queue<std::pair<int,int>> readyQueue;

    int last_arrive=0;

    while(AT[last_arrive] <= AT[0])
    {
        readyQueue.push({priority[last_arrive],last_arrive});
        last_arrive++;
    }

    while(numberOfCompleteProcess < processSize)
    {
        while(last_arrive<processSize && AT[last_arrive] <= time)
        {
            readyQueue.push({priority[last_arrive],last_arrive});
            last_arrive++;
        }
        if(readyQueue.empty())
        {
            if(last_arrive < processSize)
            {
                readyQueue.push({priority[last_arrive],last_arrive});
                time = AT[last_arrive];
                last_arrive++;
            }
            else
            {
                break;
            }
        }

        int current_execution = readyQueue.top().second;

        if(RBT[current_execution] <= timeQuantam)
        {
            CT[current_execution] = time + RBT[current_execution];
            time = CT[current_execution];
            numberOfCompleteProcess++;
            readyQueue.pop();
        }
        else
        {
            RBT[current_execution] -= timeQuantam;
            time += timeQuantam;
        }
    }
}

int main()
{

    int choice;
    std::cout << "Enter the number of Processor : ";
    std::cin>>processSize;

    std::cout << "Enter the Process Priority, Arival Time & Burst Time:";
    for(int i=0;i<processSize;i++)
    {
        std::cin>>priority[i]>>AT[i]>>BT[i];
        RBT[i] = BT[i];
    }

    takeChoice:
    std::cout<<"Enter your choice: ";
    std::cin>>choice;

    switch(choice)
    {
        case 1:
            preemptive();
            break;
        case 2:
            nonpreemptive();
            break;
        default:
            std::cout<<"Wrong choice."<<'\n';;
            goto takeChoice;
    }

    for(int i=0; i<processSize; i++)
    {
        TAT[i] = CT[i] - AT[i];
        WT[i] = TAT[i] - BT[i];
    }

    std::cout<<"\nAT\t BT\t CT\t TAT\t WT\n";
    for(int i=0;i<processSize;i++)
    {
      std::cout<<AT[i]<<'\t'<<BT[i]<<'\t'<<CT[i]<<'\t'<<TAT[i]<<'\t'<<WT[i]<<'\n';;
    }
}
