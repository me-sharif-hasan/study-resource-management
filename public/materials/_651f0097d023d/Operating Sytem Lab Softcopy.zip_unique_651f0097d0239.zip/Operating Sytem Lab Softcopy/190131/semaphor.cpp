#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cout <<"Enter the buffer size : "<<endl;
    cin >> n;
   cout<<"choice 1 for produce item\t 2 for consume item and \t 3 for exit: "<<endl;
   int item = 0;
   while(1)
   {
       int choice;
       cin >> choice;
       if(choice == 1)
       {
          item ++;
          if(item > n)
          {
              cout <<"Buffer overflow"<<endl;
          }
          else
          {
          cout << "producer produce and item " << endl;
          }

       }
       else if(choice == 2)
       {
           if(item > 0)
           {

               cout <<"consumer consume and item : "<<endl;
               item --;

           }
           else
           {
               cout <<"buffer underflow"<<endl;
           }
       }
       else
       {
           exit(0);
       }
   }








}
