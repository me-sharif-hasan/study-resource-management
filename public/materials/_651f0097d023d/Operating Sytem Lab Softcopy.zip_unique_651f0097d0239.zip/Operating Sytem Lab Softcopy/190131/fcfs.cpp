#include<bits/stdc++.h>
using namespace std;
struct node
{
    int id;
    int atime;
    int btime;
}a[100];
bool cmp(node a , node b)
{
    return a.atime < b.atime;
}
int main()
{
  int n;
  cin >>n;
  for(int i = 0; i < n ;i ++)
  {
      cin >> a[i].id >> a[i].atime >> a[i].btime;
  }
    int sum = 0;
    sort(a, a + n, cmp);
    cout <<"p\t\At\t\BT\t\CT\t\TAT\t\WT"<<endl;
    int tat=0;
    int wt=0;
    for(int i = 0; i < n ; i++)
    {
       sum += a[i].btime;
       tat = (sum - a[i].atime);
       wt =(tat - a[i].btime);
       cout <<a[i].id<<"\t"<<a[i].atime<<"\t"<<a[i].btime<<"\t"<<sum<<"\t"<<tat<<"\t"<<wt<<endl;
    }







return 0;
}
