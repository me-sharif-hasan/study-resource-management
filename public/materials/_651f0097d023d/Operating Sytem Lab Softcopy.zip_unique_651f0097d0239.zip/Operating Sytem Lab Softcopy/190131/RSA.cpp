
#include <bits/stdc++.h>
using namespace std;

int modInverse(int a, int m) {
    for (int x = 1; x < m; x++) {
        if ((a * x) % m == 1)
            return x;
    }
    return -1;
}

int main() {
    int p = 61;
    int q = 53;
    int e = 17;

    int n = p * q;
    int phi = (p - 1) * (q - 1);
    int d = modInverse(e, phi);


    int plaintext;
    cout << "Enter a number to encrypt: ";
    cin >> plaintext;


    int ciphertext = 1;
    for (int i = 0; i < e; ++i) {
        ciphertext = (ciphertext * plaintext) % n;
    }

    int decryptedText = 1;
    for (int i = 0; i < d; ++i) {
        decryptedText = (decryptedText * ciphertext) % n;
    }

    cout << "Original message: " << plaintext << endl;
    cout << "Encrypted message: " << ciphertext << endl;
    cout << "Decrypted message: " << decryptedText << endl;

    return 0;
}
