#include<bits/stdc++.h>
using namespace std;
int main()
{
    int f;
    cout << "enter the number of frame size: " <<endl;
    cin >> f;
    int n;
    cout <<"enter the size of reference string: "<<endl;
    cin >> n;
    int arr[n];
    for(int i = 0; i < n; i++)
    {

        cin >> arr[i];
    }
    deque<int>dq(f);
    deque<int>::iterator it;
    int pagefault = 0;
    dq.clear();

    for(int i = 0; i < n; i++)
    {
        it = find(dq.begin(), dq.end(), arr[i]);

        if(!(it!=dq.end()))
        {
            pagefault ++;
            if(dq.size() == f)
            {
                dq.erase(dq.begin());
                dq.push_back(arr[i]);
            }
            else
            {
                dq.push_back(arr[i]);
            }

        }
        else
        {
           dq.erase(it);
           dq.push_back(arr[i]);
        }
    }
  cout << pagefault << endl;








return 0;
}
