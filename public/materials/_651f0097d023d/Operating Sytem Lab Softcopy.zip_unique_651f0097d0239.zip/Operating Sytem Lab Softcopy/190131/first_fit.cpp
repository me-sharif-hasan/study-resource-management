#include<bits/stdc++.h>
using namespace std;
int main()
{
    int b, f;
    cout << "enter the number of block: " <<endl;
    cin >> b;
    cout<< " enter the number of file" << endl;
    cin >> f;

    int nf[f], nb[b];
    int temp;
    int bf[b],ff[f],frag[f];

    for(int i = 0 ; i < b; i++)
    {
        cin >> nb[i];
    }
    for(int i = 0 ; i < f; i++)
    {
        cin >> nf[i];
    }
    for(int i = 0 ; i < b; i++)
    {
        bf[i] = 0;
    }
    for(int i = 0 ; i < f; i++)
    {
        ff[i] = -1;
    }
    for(int i = 0; i < f; i++)
    {
        for(int j = 0; j < b; j++)
        {
            temp = nb[j] - nf[i];

            if(bf[j] != 1)
            {
                if(temp >= 0)
                {

                 ff[i] = j;
                 break;

                }
            }

        }
        bf[ff[i]] = 1;
        frag[i] = temp;
    }

    for(int i = 0; i < f; i++)
    {
        if(ff[i] != -1)
        {
        cout << i + 1 << nf[i] <<" " << ff[i] << " " << nb[ff[i]] <<" " << frag[i] << endl;
        }
        else
        {

            cout <<i + 1 << " not allocated" << endl;
        }
    }





return 0;
}
