

#include <stdio.h>
#include <stdlib.h>

int mutex = 1;


int full = 0;


int empty = 5, x = 0;


void producer()
{

	--mutex;


	++full;


	--empty;


	x++;
	printf("\nProducer produces" " item %d",x);

	++mutex;
}


void consumer()
{
	// Decrease mutex value by 1
	--mutex;


	--full;

	// Increase the number of empty
	// slots by 1
	++empty;
	printf("\nConsumer consumes " "item %d",x);
	x--;

	// Increase mutex value by 1
	++mutex;
}

// Driver Code
int main()
{
	int n, i;
	printf("\n1. Enter 1 for Producer"
		"\n2.  Enter 2 for Consumer"
		"\n3.  Enter 3 for Exit");



	for (i = 1; i > 0; i++) {

		printf("\nEnter your choice:");
		scanf("%d", &n);

		// Switch Cases
		switch (n) {
		case 1:


			if ((mutex == 1)
				&& (empty != 0)) {
				producer();
			}

			// Otherwise, print buffer
			// is full
			else {
				printf("Buffer is full!");
			}
			break;

		case 2:


			if ((mutex == 1)
				&& (full != 0)) {
				consumer();
			}


			else {
				printf("Buffer is empty!");
			}
			break;

		// Exit Condition
		case 3:
			exit(0);
			break;
		}
	}
}

