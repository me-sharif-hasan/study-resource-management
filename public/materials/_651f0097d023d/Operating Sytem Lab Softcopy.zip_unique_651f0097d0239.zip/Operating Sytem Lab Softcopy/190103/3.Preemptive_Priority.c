#include<stdio.h>
int main()
{
    int arr[10],bu[10],p[10],temp[10],i,j,small,n,time,ed,count=0,tat=0,wt=0;
    float a_tat,a_wt;
    printf("Number of process : ");
    scanf("%d",&n);
    printf("Process details : \n");
    for(i=0;i<n;i++)
    {
        printf("Arrival time : ");
        scanf("%d",&arr[i]);
        printf("Burst Time: ");
        scanf("%d",&bu[i]);
        temp[i] = bu[i];
        printf("Priority of Process : ");
        scanf("%d",&p[i]);
    }
    bu[9] = 9999;
    for(time=0;count!=n;time++)
    {
        small=9;
     for(i=0;i<n;i++)
        {
        if(arr[i]<=time&&p[i]<p[small]&&bu[i]>0)
        {
            small = i;
        }
       }
      bu[small]--;
      if(bu[small]==0)
      {
          count++;
          ed=time + 1;
          tat = tat + ed - arr[small];
          wt = wt + ed - arr[small] - temp[small];
      }
    }
    a_tat = (tat*1.0)/n;
    a_wt = (wt*1.0)/n;
    printf("%f  %f",a_tat,a_wt);
    return 0;
}
















