 #include <bits/stdc++.h>
using namespace std;

void optimalPage(int pg[], int pn, int fn)
{ 
	int fr[fn];
	memset(fr, -1, sizeof(fr));
	 
	int hit = 0;
	for (int i = 0; i < pn; i++) {
	
		bool found = false;
		for (int j = 0; j < fn; j++) {
			if (fr[j] == pg[i]) {
				hit++;
				found = true;
				break;
			}
		}
		if (found)
			continue;
		bool emptyFrame = false;
		for (int j = 0; j < fn; j++) {
			if (fr[j] == -1) {
				fr[j] = pg[i];
				emptyFrame = true;
				break;
			}
		}

		if (emptyFrame)
			continue;
		int farthest = -1, replaceIndex = -1;
		for (int j = 0; j < fn; j++) {
			int k;
			for (k = i + 1; k < pn; k++) {
				if (fr[j] == pg[k]) {
					if (k > farthest) {
						farthest = k;
						replaceIndex = j;
					}
					break;
				}
			}
			if (k == pn) {
				replaceIndex = j;
				break;
			}
		}
		fr[replaceIndex] = pg[i];
	}
	cout << "No. of hits = " << hit << endl;
	cout << "No. of misses = " << pn - hit << endl;
}
int main() {
    int pn,fn;
    cout<<"Enter the page number and frame number: "<<endl;
    cin>>pn>>fn;
    int pg[pn] = {0};
    cout<<"page size:";
    for(int i=0;i<pn;i++)
    {
        cin>>pg[i];
    }

	optimalPage(pg, pn, fn);
	return 0;
}