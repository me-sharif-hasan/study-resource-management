 #include <iostream>
#include <vector>

using namespace std;

const int MAX_PROCESSES = 100;
const int MAX_RESOURCES = 100;

int available[MAX_RESOURCES];
int max_demand[MAX_PROCESSES][MAX_RESOURCES];
int allocation[MAX_PROCESSES][MAX_RESOURCES];
int need[MAX_PROCESSES][MAX_RESOURCES];
int num_processes, num_resources;

bool request_resources(int process, int request[]) {
    // Check if the request is within the process's maximum claim.
    for (int i = 0; i < num_resources; ++i) {
        if (request[i] > need[process][i]) {
            return false;  // Request exceeds maximum claim.
        }
    }

    // Check if the request can be satisfied with available resources.
    for (int i = 0; i < num_resources; ++i) {
        if (request[i] > available[i]) {
            return false;  // Resources are not available.
        }
    }

    // Try to allocate the resources.
    for (int i = 0; i < num_resources; ++i) {
        available[i] -= request[i];
        allocation[process][i] += request[i];
        need[process][i] -= request[i];
    }

    
    if (is_safe()) {
        return true; 
    } else {
       
            available[i] += request[i];
            allocation[process][i] -= request[i];
            need[process][i] += request[i];
        }
        return false; 
 }


bool is_safe() {
    int work[MAX_RESOURCES];
    bool finish[MAX_PROCESSES];

    for (int i = 0; i < num_resources; ++i) {
        work[i] = available[i];
    }
    for (int i = 0; i < num_processes; ++i) {
        finish[i] = false;
    }

    int count = 0;
    while (count < num_processes) {
        bool found = false;
        for (int i = 0; i < num_processes; ++i) {
            if (!finish[i]) {
                bool can_allocate = true;
                for (int j = 0; j < num_resources; ++j) {
                    if (need[i][j] > work[j]) {
                        can_allocate = false;
                        break;
                    }
                }
                if (can_allocate) {
                    
                    for (int j = 0; j < num_resources; ++j) {
                        work[j] += allocation[i][j];
                    }
                    finish[i] = true;
                    count++;
                    found = true;
                }
            }
        }
        if (!found) {
            return false; 
        }
    }

    return true;  
}

int main() {
.
    cout << "Enter the number of processes: ";
    cin >> num_processes;
    cout << "Enter the number of resources: ";
    cin >> num_resources;


    cout << "Enter the maximum claim for each process:" << endl;
    for (int i = 0; i < num_processes; ++i) {
        cout << "Process " << i << ": ";
        for (int j = 0; j < num_resources; ++j) {
            cin >> max_demand[i][j];
        }
    }

    cout << "Enter the initial allocation of resources to each process:" << endl;
    for (int i = 0; i < num_processes; ++i) {
        cout << "Process " << i << ": ";
        for (int j = 0; j < num_resources; ++j) {
            cin >> allocation[i][j];
            need[i][j] = max_demand[i][j] - allocation[i][j];
            available[j] -= allocation[i][j];
        }
    }

    int process;
    cout << "Enter the process making a request: ";
    cin >> process;
    int request[MAX_RESOURCES];
    cout << "Enter the resource request for process " << process << ": ";
    for (int i = 0; i < num_resources; ++i) {
        cin >> request[i];
    }

    if (request_resources(process, request)) {
        cout << "System is in a safe state." << endl;
    } else {
        cout <<" System would be in an unsafe state." << endl;
    }

    return 0;
}