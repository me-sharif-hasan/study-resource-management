#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

class CountingSemaphore {
public:
    CountingSemaphore(int initialCount) : count(initialCount) {}

    void acquire() {
        std::unique_lock<std::mutex> lock(mutex);
        while (count == 0) {
            condition.wait(lock);
        }
        count--;
    }

    void release() {
        std::lock_guard<std::mutex> lock(mutex);
        count++;
        condition.notify_one();
    }

private:
    int count;
    std::mutex mutex;
    std::condition_variable condition;
};

CountingSemaphore semaphore(3); // Initialize with 3 resources

void worker(int id) {
    semaphore.acquire();
    std::cout << "Thread " << id << " acquired resource." << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(1));
    semaphore.release();
    std::cout << "Thread " << id << " released resource." << std::endl;
}

int main() {
    std::thread t1(worker, 1);
    std::thread t2(worker, 2);
    std::thread t3(worker, 3);

    t1.join();
    t2.join();
    t3.join();

    return 0;
}
