#include<bits/stdc++.h>
#define For(i,n) for(int i=0;i<n;i++)
using namespace std;
void fcfs(){

    cout<<"Enter the number of process: "<<endl;
    int n; cin>>n;
    cout<<"Enter process id, at, bt assumed that sorted by at order : "<<endl;

    int pid[n],a_t[n],bt[n];
    map<int,int>m;
    for(int i=0;i<n;i++){
        cin>>pid[i]>>a_t[i]>>bt[i];
        m[pid[i]]=a_t[i];
    }

    int ct[n];

    ct[0]=bt[0]; //first ct is the first bt.

    for(int i=1;i<n;i++){
        if(a_t[i]<ct[i-1])
            ct[i]=ct[i-1]+bt[i];
        else
            ct[i]=a_t[i]+bt[i];
      //cout<<" ct: "<<ct[i]<<" ";
    }
    //cout<<endl<<"tat: ";

    int tat[n], wt[n];
    For(i,n){
        tat[i]=ct[i]-a_t[i];
        //cout<<tat[i]<<" ";
    }
    int s=0;
    //cout<<endl<<" wt: ";
    For(i,n){
        wt[i]=tat[i]-bt[i];
        s+=wt[i];
        //cout<<wt[i]<<" ";
    }
    //cout<<endl;
    float ans= float(s/(n*1.0));
    cout<<setprecision(4)<<"Average waiting time is : "<< ans<<endl;

}
int main(){
    fcfs();
    return 0;
}
