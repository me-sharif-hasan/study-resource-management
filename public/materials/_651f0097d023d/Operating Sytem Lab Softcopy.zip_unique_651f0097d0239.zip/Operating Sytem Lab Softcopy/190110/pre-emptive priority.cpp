#include "bits/stdc++.h"
using namespace std;

#define br cout<<"\n"
/*DEBUG*/
template <class T>
void what(T t)
{
    cout<< " "<<t <<endl ;
}
template<class T,class... Args>
void what(T t,Args... args)
{
    cout<<" "<<t<<"; ";
    what(args...);
}

/*STL definations*/
#define pb push_back

typedef long long ll; // comments that are mixed in with code
typedef pair<int, int> ii; // are aligned to the right like this
typedef vector<ii> vii;
typedef vector<int> vi;
#define INF 1000000000 // 1 billion, safer than 2B for Floyd Warshall’s

#define FOR(i,n) for(int i=0;i<n;i++)
#define FROM(a,i,n) for(int i=a;i<n;i++)
#define vin(macroVec) for(auto &macroA:macroVec) cin>>macroA;

/*Output macros*/
#define YES cout<<"YES\n";
#define NO cout<<"NO\n";
#define printCase(ck) cout<<"Case "<<ck<<": ";

 struct job{
 	int arival_time;
 	int burst_time;
 	int priority;
 	int id;
 	int rbt=0;
 	int ending_time;
 };

 class CMP {
public:
    bool operator()(job& t1, job& t2)
    {
       if (t1.priority < t2.priority) return true;
       return false;
    }
};
bool cmp(job a,job b){
	return a.arival_time<b.arival_time;
}
void solve(){

	priority_queue <job,vector <job>,CMP> jobs;
	int n;
	cout<<"Enter the number of jobs: \n";
	cin>>n;
	vector <job> joblist;
	FOR(i,n){
		cout<<"Enter id, arival time, burst time, priority: \n";
		int id,at,bt,p;
		cin>>id>>at>>bt>>p;
		job j;
		j.arival_time=at;
		j.burst_time=bt;
		j.id=id;
		j.priority=p;
		j.rbt=bt;
		//jobs.push(j);
		joblist.pb(j);
	}
	sort(joblist.begin(),joblist.end(),cmp);
//
	// what(joblist.front().id);
	vector <job> finished;
	int p=0;
	for(int t=0;t<1000;t++){
		if(jobs.size()>0){
			job j=jobs.top();
			jobs.pop();
			j.rbt--;
			if(j.rbt==0){
				j.ending_time=t;
				finished.pb(j);
			}else{
				jobs.push(j);
			}
		}
		if(p<joblist.size()&&joblist[p].arival_time<=t){
			jobs.push(joblist[p]);
			p++;
		}
	}
	double total_wait=0;
	for(auto a:finished){
		cout<<"Process "<<a.id<<" finished at "<<a.ending_time<<endl;
		int tat=a.ending_time-a.arival_time;
		int wait=tat-a.burst_time;
		total_wait+=wait;
		//what(tat);
	}

	cout<<"Average waiting time: "<<total_wait/finished.size();br;

 }

int main(){
	solve();
}
