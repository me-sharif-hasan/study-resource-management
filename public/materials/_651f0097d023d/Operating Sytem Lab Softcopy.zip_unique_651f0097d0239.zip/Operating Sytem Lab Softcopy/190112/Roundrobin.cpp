#include<iostream>
using namespace std;

int main() {
    int i, NOP, sum = 0, count = 0, y, quant, wt = 0, tat = 0, at[10], bt[10], temp[10];
    float avg_wt, avg_tat;

    cout << "Total number of processes in the system: ";
    cin >> NOP;
    y = NOP;

    for (i = 0; i < NOP; i++) {
        cout << "Arrival time for process " << i + 1 << ": ";
        cin >> at[i];
        cout << "Burst time for process " << i + 1 << ": ";
        cin >> bt[i];
        temp[i] = bt[i];
    }

    cout << "Enter the Time Quantum for the processes: ";
    cin >> quant;

    cout << "\nProcess No \t Burst Time \t TAT \t Waiting Time \n";

    for (sum = 0, i = 0; y != 0;) {
        if (temp[i] <= quant && temp[i] > 0) {
            sum = sum + temp[i];
            temp[i] = 0;
            count = 1;
        } else if (temp[i] > 0) {
            temp[i] = temp[i] - quant;
            sum = sum + quant;
        }

        if (temp[i] == 0 && count == 1) {
            y--;
            cout << "P" << i + 1 << "\t\t " << bt[i] << "\t\t " << sum - at[i] << "\t\t " << sum - at[i] - bt[i] << endl;
            wt = wt + sum - at[i] - bt[i];
            tat = tat + sum - at[i];
            count = 0;
        }

        if (i == NOP - 1) {
            i = 0;
        } else if (at[i + 1] <= sum) {
            i++;
        } else {
            i = 0;
        }
    }

    avg_wt = static_cast<float>(wt) / NOP;
    avg_tat = static_cast<float>(tat) / NOP;

    cout << "\nAverage Turnaround Time: " << avg_tat;
    cout << "\nAverage Waiting Time: " << avg_wt;

    return 0;
}
