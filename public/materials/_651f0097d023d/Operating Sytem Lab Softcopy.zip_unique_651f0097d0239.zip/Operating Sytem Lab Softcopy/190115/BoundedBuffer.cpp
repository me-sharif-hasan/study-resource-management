#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <condition_variable>

class BoundedBuffer {
private:
    std::vector<int> buffer;
    int size;
    int writeIndex;
    int readIndex;
    std::mutex mtx;
    std::condition_variable notEmpty;
    std::condition_variable notFull;

public:
    BoundedBuffer(int bufferSize) : size(bufferSize), buffer(bufferSize), writeIndex(0), readIndex(0) {}

    void add(int item) {
        std::unique_lock<std::mutex> lock(mtx);
        notFull.wait(lock, [this] { return ((writeIndex + 1) % size) != readIndex; });

        buffer[writeIndex] = item;
        writeIndex = (writeIndex + 1) % size;

        notEmpty.notify_all();
    }

    int remove() {
        std::unique_lock<std::mutex> lock(mtx);
        notEmpty.wait(lock, [this] { return readIndex != writeIndex; });

        int item = buffer[readIndex];
        readIndex = (readIndex + 1) % size;

        notFull.notify_all();
        return item;
    }
};

const int BUFFER_SIZE = 5;
BoundedBuffer buffer(BUFFER_SIZE);

void producer() {
    for (int i = 1; i <= 10; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(200)); // Simulate production time
        buffer.add(i);
        std::cout << "Produced: " << i << "\n";
    }
}

void consumer() {
    for (int i = 0; i < 10; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(300)); // Simulate consumption time
        int item = buffer.remove();
        std::cout << "Consumed: " << item << "\n";
    }
}

int main() {
    std::thread producerThread(producer);
    std::thread consumerThread(consumer);

    producerThread.join();
    consumerThread.join();

    return 0;
}
