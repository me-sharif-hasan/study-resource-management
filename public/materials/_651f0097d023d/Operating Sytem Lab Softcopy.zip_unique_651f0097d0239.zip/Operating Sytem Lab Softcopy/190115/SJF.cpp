#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

struct Process {
    int process_id;
    int arrival_time;
    int burst_time;
};

struct CompareArrivalTime {
    bool operator()(const Process& a, const Process& b) const {
        return a.arrival_time > b.arrival_time;
    }
};

void shortestJobFirst(std::vector<Process>& processes) {
    std::sort(processes.begin(), processes.end(), [](const Process& a, const Process& b) {
        return a.arrival_time < b.arrival_time || (a.arrival_time == b.arrival_time && a.burst_time < b.burst_time);
    });

    std::priority_queue<Process, std::vector<Process>, CompareArrivalTime> pq;
    int currentTime = 0;
    int index = 0;
    float totalWaitingTime = 0;

    std::cout << "Order of execution: ";

    while (index < processes.size() || !pq.empty()) {
        while (index < processes.size() && processes[index].arrival_time <= currentTime) {
            pq.push(processes[index]);
            index++;
        }

        if (pq.empty()) {
            currentTime = processes[index].arrival_time;
            continue;
        }

        Process currentProcess = pq.top();
        pq.pop();

        std::cout << "P" << currentProcess.process_id << " ";
        totalWaitingTime += currentTime - currentProcess.arrival_time;
        currentTime += currentProcess.burst_time;
    }

    std::cout << "\n";

    float averageWaitingTime = totalWaitingTime / processes.size();
    std::cout << "Average Waiting Time: " << averageWaitingTime << "\n";
}

int main() {
    std::vector<Process> processes = {
            {1, 0, 6},
            {2, 1, 8},
            {3, 2, 7},
            {4, 3, 3}
    };

    std::cout << "Shortest Job First (SJF) Scheduling Algorithm\n";
    shortestJobFirst(processes);

    return 0;
}
