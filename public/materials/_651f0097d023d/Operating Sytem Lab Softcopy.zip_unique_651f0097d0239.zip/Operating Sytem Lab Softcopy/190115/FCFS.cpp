//----------------------Created by Anik Saha---------------------------//
#include <bits/stdc++.h>
using namespace std;

#define FastIO ios_base::sync_with_stdio(false);    cin.tie(NULL)
#define Ignore cin.ignore()
typedef unsigned char Byte;
typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int, int> pairs;
typedef std::vector<int> VI;
typedef std::vector<pairs> VII;
//---------------------------Good luck---------------------------------//
class process
{
public:
    int arrivalTime, burstTime, pid;
    int waitingTime,completionTime, turnAroundTime;
};

bool compare(process &a, process &b) {
    return a.arrivalTime < b.arrivalTime;
}

int main() {
    FastIO;

    int n{0};
    // cout << "Number of process : ";
    cin >> n;
     process arr[n];
    for (int i = 0; i < n; i++) {
        int at,bt;
        // cout << "Info of process - " << i+1 << " :" << endl;
        // cout << "Arival Time : ";
        cin >> at;
        // cout << "\nBurst Time : ";
        cin >> bt;
        arr[i].pid = i+1;
        arr[i].arrivalTime = at;
        arr[i].burstTime  = bt;
    }
    cout << endl;
    std::sort(arr, arr+n, compare);
    int timeLine{0};
    double avWT{0.00};
    double avTAT{0.00};
    for (int i = 0; i < n; i++) {
        cout << "Process - " << arr[i].pid << endl;
        if(timeLine < arr[i].arrivalTime) {
            timeLine = arr[i].arrivalTime;
        }
        arr[i].completionTime = timeLine + arr[i].burstTime;
        arr[i].turnAroundTime = arr[i].completionTime - arr[i].arrivalTime;
        arr[i].waitingTime = arr[i].turnAroundTime - arr[i].burstTime;
        avWT += arr[i].waitingTime;
        avTAT += arr[i].turnAroundTime;
        cout << "WT - " << arr[i].waitingTime << endl;
        cout << "TAT - " << arr[i].turnAroundTime << endl;
        cout << "CT - " << arr[i].completionTime << endl;
    }
    cout << "Average waiting time : " << (double)avWT/n << endl;
    cout << "Average turn around time : " << (double)avTAT/n << endl;
    return 0;
}