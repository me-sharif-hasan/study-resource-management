#include <iostream>
#include <vector>
#include <algorithm>

struct Process {
    int process_id;
    int burst_time;
    int priority;
};

bool compareByPriority(const Process& a, const Process& b) {
    return a.priority > b.priority;
}

void priorityScheduling(std::vector<Process>& processes) {
    std::sort(processes.begin(), processes.end(), compareByPriority);

    int currentTime = 0;
    float totalWaitingTime = 0;

    std::cout << "Order of execution: ";

    for (const auto& process : processes) {
        std::cout << "P" << process.process_id << " ";
        totalWaitingTime += currentTime;
        currentTime += process.burst_time;
    }

    std::cout << "\n";

    float averageWaitingTime = totalWaitingTime / processes.size();
    std::cout << "Average Waiting Time: " << averageWaitingTime << "\n";
}

int main() {
    std::vector<Process> processes = {
        {1, 10, 3},
        {2, 5, 1},
        {3, 8, 2},
        {4, 2, 4}
    };

    std::cout << "Priority Scheduling Algorithm\n";
    priorityScheduling(processes);

    return 0;
}
