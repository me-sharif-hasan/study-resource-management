#include <iostream>
#include <cmath>

// Function to calculate gcd of two numbers
int gcd(int a, int b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

// Function to calculate modulo inverse using Extended Euclidean Algorithm
int modInverse(int a, int m) {
    for (int x = 1; x < m; x++)
        if (((a % m) * (x % m)) % m == 1)
            return x;
    return -1;
}

// Function to perform RSA key generation
void generateKeys(int p, int q, int &n, int &e, int &d) {
    n = p * q;
    int phi = (p - 1) * (q - 1);

    e = 2; // Usually e is chosen as 65537 (a common choice)
    while (e < phi) {
        if (gcd(e, phi) == 1)
            break;
        e++;
    }

    d = modInverse(e, phi);
}

// Function to encrypt a message using RSA
int encrypt(int message, int e, int n) {
    return (int) pow(message, e) % n;
}

// Function to decrypt a message using RSA
int decrypt(int encryptedMessage, int d, int n) {
    return (int) pow(encryptedMessage, d) % n;
}

int main() {
    int p = 61; // First prime number
    int q = 53; // Second prime number

    int n, e, d;
    generateKeys(p, q, n, e, d);

    int plaintext = 42; // Message to be encrypted

    // Encrypt the message
    int encryptedMessage = encrypt(plaintext, e, n);
    std::cout << "Encrypted message: " << encryptedMessage << "\n";

    // Decrypt the message
    int decryptedMessage = decrypt(encryptedMessage, d, n);
    std::cout << "Decrypted message: " << decryptedMessage << "\n";

    return 0;
}
