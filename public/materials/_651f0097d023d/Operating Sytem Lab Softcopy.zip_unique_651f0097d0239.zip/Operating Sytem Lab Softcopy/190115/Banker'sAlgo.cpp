#include <iostream>
#include <vector>
#include <limits.h>

const int MAX_PROCESSES = 10;
const int MAX_RESOURCES = 10;

int available[MAX_RESOURCES];
int maximum[MAX_PROCESSES][MAX_RESOURCES];
int allocation[MAX_PROCESSES][MAX_RESOURCES];
int need[MAX_PROCESSES][MAX_RESOURCES];
bool finished[MAX_PROCESSES];

int num_processes, num_resources;

void initialize() {
    // Initialize need matrix
    for (int i = 0; i < num_processes; ++i) {
        for (int j = 0; j < num_resources; ++j) {
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
        finished[i] = false;
    }
}

bool requestIsSafe(int process, int request[]) {
    // Check if request is less than need
    for (int i = 0; i < num_resources; ++i) {
        if (request[i] > need[process][i])
            return false;
    }

    // Check if request is less than available
    for (int i = 0; i < num_resources; ++i) {
        if (request[i] > available[i])
            return false;
    }

    // Simulate the allocation to check safety
    int temp_allocation[MAX_PROCESSES][MAX_RESOURCES];
    int temp_need[MAX_PROCESSES][MAX_RESOURCES];
    int temp_available[MAX_RESOURCES];

    for (int i = 0; i < num_processes; ++i) {
        for (int j = 0; j < num_resources; ++j) {
            temp_allocation[i][j] = allocation[i][j];
            temp_need[i][j] = need[i][j];
        }
    }

    for (int i = 0; i < num_resources; ++i) {
        temp_allocation[process][i] += request[i];
        temp_need[process][i] -= request[i];
        temp_available[i] = available[i] - request[i];
    }

    bool finish[MAX_PROCESSES] = {false};
    for (int i = 0; i < num_processes; ++i) {
        for (int j = 0; j < num_processes; ++j) {
            if (!finish[j]) {
                bool canExecute = true;
                for (int k = 0; k < num_resources; ++k) {
                    if (temp_need[j][k] > temp_available[k]) {
                        canExecute = false;
                        break;
                    }
                }
                if (canExecute) {
                    finish[j] = true;
                    for (int k = 0; k < num_resources; ++k) {
                        temp_available[k] += temp_allocation[j][k];
                    }
                }
            }
        }
    }

    for (int i = 0; i < num_processes; ++i) {
        if (!finish[i])
            return false;
    }

    return true;
}

bool requestResources(int process, int request[]) {
    if (requestIsSafe(process, request)) {
        for (int i = 0; i < num_resources; ++i) {
            available[i] -= request[i];
            allocation[process][i] += request[i];
            need[process][i] -= request[i];
        }
        return true;
    } else {
        return false;
    }
}

void releaseResources(int process) {
    for (int i = 0; i < num_resources; ++i) {
        available[i] += allocation[process][i];
        allocation[process][i] = 0;
        need[process][i] = 0;
    }
}

int main() {
    std::cout << "Enter the number of processes: ";
    std::cin >> num_processes;

    std::cout << "Enter the number of resources: ";
    std::cin >> num_resources;

    std::cout << "Enter the maximum demand of each process:\n";
    for (int i = 0; i < num_processes; ++i) {
        std::cout << "For Process " << i << ":\n";
        for (int j = 0; j < num_resources; ++j) {
            std::cout << "Resource " << j << ": ";
            std::cin >> maximum[i][j];
        }
    }

    std::cout << "Enter the allocation of each process:\n";
    for (int i = 0; i < num_processes; ++i) {
        std::cout << "For Process " << i << ":\n";
        for (int j = 0; j < num_resources; ++j) {
            std::cout << "Resource " << j << ": ";
            std::cin >> allocation[i][j];
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }

    std::cout << "Enter the available resources:\n";
    for (int i = 0; i < num_resources; ++i) {
        std::cout << "Resource " << i << ": ";
        std::cin >> available[i];
    }

    initialize();

    // Process requests
    int request[MAX_RESOURCES];
    int process;
    std::cout << "Enter process number for request (-1 to exit): ";
    std::cin >> process;

    while (process != -1) {
        std::cout << "Enter request for Process " << process << ":\n";
        for (int i = 0; i < num_resources; ++i) {
            std::cout << "Resource " << i << ": ";
            std::cin >> request[i];
        }

        if (requestResources(process, request)) {
            std::cout << "Request granted.\n";
            std::cout << "Order of execution: ";
            for (int i = 0; i < num_processes; ++i) {
                std::cout << "P" << i << " ";
            }
            std::cout << "\n";
        } else {
            std::cout << "Request denied. The system is unsafe.\n";
        }

        std::cout << "Enter process number for request (-1 to exit): ";
        std::cin >> process;
    }

    return 0;
}
