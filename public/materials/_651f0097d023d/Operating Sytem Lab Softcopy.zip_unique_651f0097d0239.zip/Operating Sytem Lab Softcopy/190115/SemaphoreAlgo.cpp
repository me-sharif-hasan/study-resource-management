#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

class Semaphore {
private:
    int count;
    std::mutex mtx;
    std::condition_variable cv;

public:
    Semaphore(int initial_count) : count(initial_count) {}

    void wait() {
        std::unique_lock<std::mutex> lock(mtx);
        while (count == 0) {
            cv.wait(lock);
        }
        count--;
    }

    void signal() {
        std::unique_lock<std::mutex> lock(mtx);
        count++;
        cv.notify_one();
    }
};

Semaphore sem(2); // Initialize a semaphore with count 2

void worker(int id) {
    std::cout << "Thread " << id << " is waiting.\n";
    sem.wait();
    std::cout << "Thread " << id << " acquired the semaphore.\n";
    // Simulating some work
    std::this_thread::sleep_for(std::chrono::seconds(2));
    sem.signal();
    std::cout << "Thread " << id << " released the semaphore.\n";
}

int main() {
    std::thread t1(worker, 1);
    std::thread t2(worker, 2);
    std::thread t3(worker, 3);

    t1.join();
    t2.join();
    t3.join();

    return 0;
}
