#include <iostream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <limits.h>

int pageFaults(const std::vector<int>& pages, int capacity) {
    std::unordered_map<int, int> indexes;
    int pageFaults = 0;

    std::vector<int> pageInFuture(pages.size(), INT_MAX);

    for (int i = pages.size() - 1; i >= 0; --i) {
        if (indexes.find(pages[i]) == indexes.end()) {
            indexes[pages[i]] = i;
            pageFaults++;

            // Update the page's distance to its next occurrence
            for (int j = i - 1; j >= 0; --j) {
                if (pages[j] == pages[i]) {
                    pageInFuture[j] = i;
                    break;
                }
            }
        }
    }

    return pageFaults;
}

int main() {
    std::vector<int> pages = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 1, 2};
    int capacity = 3;

    int faults = pageFaults(pages, capacity);

    std::cout << "Page Faults using Optimal Page Replacement: " << faults << "\n";

    return 0;
}
