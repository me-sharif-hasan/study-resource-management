#include <iostream>
#include <queue>

struct Process {
    int process_id;
    int burst_time;
    int remaining_burst_time;
};

void roundRobin(std::queue<Process>& processes, int time_slice) {
    int currentTime = 0;

    while (!processes.empty()) {
        Process currentProcess = processes.front();
        processes.pop();

        int executionTime = std::min(time_slice, currentProcess.remaining_burst_time);
        currentProcess.remaining_burst_time -= executionTime;
        currentTime += executionTime;

        std::cout << "Executing P" << currentProcess.process_id << " for " << executionTime << " units. ";

        if (currentProcess.remaining_burst_time > 0) {
            std::cout << "Process goes to the end of the queue.\n";
            processes.push(currentProcess);
        } else {
            std::cout << "Process completed.\n";
        }
    }
}

int main() {
    std::queue<Process> processes;
    processes.push({1, 10, 10});
    processes.push({2, 5, 5});
    processes.push({3, 8, 8});
    processes.push({4, 2, 2});

    int time_slice = 2; // Time slice for each process

    std::cout << "Round Robin Scheduling Algorithm\n";
    roundRobin(processes, time_slice);

    return 0;
}
