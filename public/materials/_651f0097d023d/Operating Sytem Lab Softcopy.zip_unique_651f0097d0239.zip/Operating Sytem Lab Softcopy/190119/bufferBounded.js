class BoundedBuffer {
    constructor(size) {
      this.size = size;
      this.buffer = new Array(size);
      this.inIndex = 0;
      this.outIndex = 0;
      this.count = 0;
    }
  
    async enqueue(item) {
      while (this.count === this.size) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
  
      this.buffer[this.inIndex] = item;
      this.inIndex = (this.inIndex + 1) % this.size;
      this.count++;
  
      return item;
    }
  
    async dequeue() {
      while (this.count === 0) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      const item = this.buffer[this.outIndex];
      this.outIndex = (this.outIndex + 1) % this.size;
      this.count--;
      return item;
    }
  }
  
  const buffer = new BoundedBuffer(5);
  async function producer() {
    for (let i = 1; i <= 10; i++) {
      const item = await buffer.enqueue(`Item ${i}`);
      console.log(`Produced: ${item}`);
      await new Promise((resolve) => setTimeout(resolve, Math.random() * 1000));
    }
  }
  async function consumer() {
    for (let i = 1; i <= 10; i++) {
      const item = await buffer.dequeue();
      console.log(`Consumed: ${item}`);
      await new Promise((resolve) => setTimeout(resolve, Math.random() * 1000));
    }
  }
  producer();
  consumer();
  