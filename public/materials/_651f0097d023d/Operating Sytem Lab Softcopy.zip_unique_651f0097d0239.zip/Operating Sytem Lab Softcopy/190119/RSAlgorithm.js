const NodeRSA = require('node-rsa');
const key = new NodeRSA({ b: 512 });
const publicKey = key.exportKey('public');
const privateKey = key.exportKey('private');

console.log('Public Key:\n', publicKey);
console.log('Private Key:\n', privateKey);
const plaintextMessage = 8;
const encryptedMessage = key.encrypt(plaintextMessage, 'base64');

console.log('Encrypted Message:\n', encryptedMessage);

const decryptedMessage = key.decrypt(encryptedMessage, 'utf8');

console.log('Decrypted Message:\n', decryptedMessage);
