const prompt = require('prompt-sync')({ sigint: true });
let A = [];
let total = 0;
let index, temp;
let avg_wt, avg_tat;
let n = parseInt(prompt("Enter the number of process: "));

for (let i = 0; i < n; i++) {
	let input = prompt("P" + (i + 1) + ": ");
	A.push([i+1, parseInt(input)]);
}

for (let i = 0; i < n; i++) {
	index = i;
	for (let j = i + 1; j < n; j++) {
		if (A[j][1] < A[index][1]) {
			index = j;
		}
	}
	temp = A[i][1];
	A[i][1] = A[index][1];
	A[index][1] = temp;

	temp = A[i][0];
	A[i][0] = A[index][0];
	A[index][0] = temp;
}

A[0][2] = 0;
for (let i = 1; i < n; i++) {
	A[i][2] = 0;
	for (let j = 0; j < i; j++) {
		A[i][2] += A[j][1];
	}
	total += A[i][2];
}

avg_wt = total / n;
total = 0;
console.log("P	 BT	 WT	 TAT");
for (let i = 0; i < n; i++) {
	A[i][3] = A[i][1] + A[i][2];
	total += A[i][3];
	console.log("P" + A[i][0] + "	 " + A[i][1] + "	 " + A[i][2] + "	 " + A[i][3]);
}

avg_tat = total / n;
console.log("Average Waiting Time= " + avg_wt);
console.log("Average Turnaround Time= " + avg_tat);
