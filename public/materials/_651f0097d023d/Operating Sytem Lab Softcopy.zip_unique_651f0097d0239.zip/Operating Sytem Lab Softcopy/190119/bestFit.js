function bestFit(blockSize, m, processSize, n) {
    let allocation = new Array(n).fill(-1);
    for (let i = 0; i < n; i++) {
        let bestIdx = -1;
        for (let j = 0; j < m; j++) {
        if (blockSize[j] >= processSize[i]) {
            if (bestIdx === -1) {
            bestIdx = j;
            } else if (blockSize[bestIdx] > blockSize[j]) {
            bestIdx = j;
            }
        }
        }
        if (bestIdx !== -1) {
        allocation[i] = bestIdx;
        blockSize[bestIdx] -= processSize[i];
        }
    }
    
    console.log("Process No. Process Size	 Block no.");
    for (let i = 0; i < n; i++) {
        console.log(`${i + 1}		 ${processSize[i]}		 ${allocation[i] !== -1 ? allocation[i] + 1 : "Not Allocated"}`);
    }
    }
    
    let blockSize = [100, 500, 200, 300, 600];
    let processSize = [212, 417, 112, 426];
    let m = blockSize.length;
    let n = processSize.length;
    bestFit(blockSize, m, processSize, n);
    