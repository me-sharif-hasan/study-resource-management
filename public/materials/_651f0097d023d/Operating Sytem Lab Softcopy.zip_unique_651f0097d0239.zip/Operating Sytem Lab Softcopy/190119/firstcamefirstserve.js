const prompt = require('prompt-sync')({ sigint: true });
function calculateWaitingTime(at, bt, n) {
    let wt = new Array(n);
    wt[0] = 0;
    console.log("PN\t\tAT\t\tBT\t\tWT\n\n");
    console.log(`1\t\t${at[0]}\t\t${bt[0]}\t\t${wt[0]}\n`);
    for (let i = 1; i < n; i++) {
        wt[i] = (at[i - 1] + bt[i - 1] + wt[i - 1]) - at[i];
        console.log(`${i + 1}\t\t${at[i]}\t\t${bt[i]}\t\t${wt[i]}\n`);
    }
    let average;
    let sum = 0;
    for (let i = 0; i < n; i++) {
        sum = sum + wt[i];
    }
    average = sum / n;
    console.log(`\nAverage waiting time = ${average}`);
}

function main() {
    let n = prompt('Input process number : ');
    n = parseInt(n)
    let at = [];
    let bt = [];

    for (let i = 0; i < n; i++) {
        console.log('process no : ' + (i + 1))
        let a = prompt('Input process arialval time : ');
        let b = prompt('Input process burst time : ');
        at.push(parseInt(a))
        bt.push(parseInt(b))
        console.log('\n')
    }
    calculateWaitingTime(at, bt, n);
}
main();
