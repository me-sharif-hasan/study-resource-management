const prompt = require('prompt-sync')({ sigint: true });

const findWaitingTime = (processes, n, bt, wt, quantum) => {
    let rem_bt = new Array(n).fill(0);
    for (let i = 0; i < n; i++)
        rem_bt[i] = bt[i];
    let t = 0; 
    while (1) {
        let done = true;
        for (let i = 0; i < n; i++) {
            
            if (rem_bt[i] > 0) {
                done = false;

                if (rem_bt[i] > quantum) {
                    t += quantum;
                    rem_bt[i] -= quantum;
                }
                else {
                    t = t + rem_bt[i];
                    wt[i] = t - bt[i];
                    rem_bt[i] = 0;
                }
            }
        }
        if (done == true)
            break;
    }
}

const findTurnAroundTime = (processes, n, bt, wt, tat) => {
    for (let i = 0; i < n; i++)
        tat[i] = bt[i] + wt[i];
}

const findavgTime = (processes, n, bt, quantum) => {
    let wt = new Array(n).fill(0), tat = new Array(n).fill(0);
    let total_wt = 0, total_tat = 0;
    findWaitingTime(processes, n, bt, wt, quantum);
    findTurnAroundTime(processes, n, bt, wt, tat);
    console.log(`Processes\tBurst time\tWaiting time\tTurn around time`);
    for (let i = 0; i < n; i++) {
        total_wt = total_wt + wt[i];
        total_tat = total_tat + tat[i];

        console.log(`${i + 1}\t\t${bt[i]}\t\t${wt[i]}\t\t${tat[i]}`);
    }

    console.log(`Average waiting time = ${total_wt / n}`);
    console.log(`Average turn around time = ${total_tat / n}`);
}

let n = parseInt(prompt("Enter the number of process: "));

let processes = [];
let burst_time = [];

for (let i = 0; i < n; i++) {
    let a = prompt('Input process number : ');
    let b = prompt('Input process burst time : ');
    processes.push(parseInt(a))
    burst_time.push(parseInt(b))
    console.log('\n')
}

let tq = prompt('Input time quentam : ');
let quantum = parseInt(tq);

findavgTime(processes, n, burst_time, quantum);

