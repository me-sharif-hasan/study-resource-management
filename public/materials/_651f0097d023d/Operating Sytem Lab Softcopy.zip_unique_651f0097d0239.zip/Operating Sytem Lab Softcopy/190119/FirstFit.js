class MemoryPartition {
    constructor(id, size) {
      this.id = id;
      this.size = size;
      this.allocated = false;
    }
  }
  
  class OperatingSystem {
    constructor(memorySize) {
      this.memorySize = memorySize;
      this.memory = [];
    }
  
    initializeMemory(partitionSizes) {
      for (let i = 0; i < partitionSizes.length; i++) {
        const partition = new MemoryPartition(i, partitionSizes[i]);
        this.memory.push(partition);
      }
    }
  
    allocateMemory(processSize) {
      for (let i = 0; i < this.memory.length; i++) {
        const partition = this.memory[i];
        if (!partition.allocated && partition.size >= processSize) {
          partition.allocated = true;
          console.log(`Allocated Process with size ${processSize} to Partition ${partition.id}`);
          return;
        }
      }
      console.log(`Unable to allocate Process with size ${processSize}`);
    }
  }
  
  const os = new OperatingSystem(100);
  os.initializeMemory([20, 30, 10, 25, 15]); 
  
  os.allocateMemory(12); 
  os.allocateMemory(28); 
  os.allocateMemory(8);  
  os.allocateMemory(20); 
  os.allocateMemory(18); 
  
  function deallocateProcess(processId) {
    const partition = os.memory.find(partition => partition.id === processId);
    if (partition) {
      partition.allocated = false;
      console.log(`Deallocated Process in Partition ${processId}`);
    } else {
      console.log(`Process with ID ${processId} not found.`);
    }
  }
  
  deallocateProcess(1); 
  os.allocateMemory(18);