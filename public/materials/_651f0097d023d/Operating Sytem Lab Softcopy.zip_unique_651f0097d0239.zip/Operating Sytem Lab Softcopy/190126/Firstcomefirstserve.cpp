#include<bits/stdc++.h>
using namespace std;
int main ()
{
  int n,att[20],bt[20],wt[20],tat[20],avwt=0,avtat=0,i,j;
  cout<<"Number of Process"<<endl;
  cin>>n;
  cout<<" Enter Process Arrival time "<<endl;
  for(int i=0;i<n;i++)
  {
      cin>>att[i];
  }
   cout<<" Enter Process Burst time "<<endl;
  for(int i=0;i<n;i++)
  {
      cin>>bt[i];
  }

  wt[0]=0;

  for(i=0;i<n;i++)
  {
      wt[i]=0;

      for(j=0;j<n;j++)
        wt[i]+=bt[j];
  }
  cout<<"\nProcess\t\tArrival time\tBrust time\tWaiting time\t Turn around time";

  for(i=0;i<n;i++)
  {
      tat[i]=bt[i]+wt[i];
      avtat+=wt[i];
      avtat+=tat[i];

      cout<<"\nP["<<i+1<<"]"<<"\t\t"<<att[i]<<"\t\t"<<bt[i]<<"\t\t"<<wt[i]<<"\t\t"<<tat[i];
  }
  avwt/=i;
  avtat/=i;
  cout<<endl;
  cout<<"Avarage waiting time"<<avwt<<endl;
  cout<<"Avarage  Turn around time"<<avtat<<endl;

}
