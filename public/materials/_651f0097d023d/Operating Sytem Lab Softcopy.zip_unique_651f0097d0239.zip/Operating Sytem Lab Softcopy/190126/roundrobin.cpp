#include <iostream>
#include <queue>
#include <vector>

using namespace std;

struct Process {
    int id;
    int burstTime;
};

int main() {
    int quantum;
    cout << "Enter time quantum: ";
    cin >> quantum;

    int numProcesses;
    cout << "Enter the number of processes: ";
    cin >> numProcesses;

    queue<Process> processQueue;
    vector<Process> completedProcesses;

    for (int i = 0; i < numProcesses; ++i) {
        Process p;
        p.id = i + 1;
        cout << "Enter burst time for Process " << p.id << ": ";
        cin >> p.burstTime;
        processQueue.push(p);
    }

    while (!processQueue.empty()) {
        Process currentProcess = processQueue.front();
        processQueue.pop();

        if (currentProcess.burstTime <= quantum) {
            // The process completes within the time quantum
            currentProcess.burstTime = 0;
            completedProcesses.push_back(currentProcess);
        } else {
            // The process still needs more time
            currentProcess.burstTime -= quantum;
            processQueue.push(currentProcess);
        }
    }

    // Display the completion order
    cout << "Process completion order: ";
    for (const Process& p : completedProcesses) {
        cout << "P" << p.id << " ";
    }
    cout << endl;

    return 0;
}

