#include<iostream>
using namespace std;
int mutex=1;
int full=0;
int empty=10,x=0;
void producer()
{
    --mutex;
    ++full;
    --empty;
    x++;
    cout<<"\nProducer produces item "<<x<<endl;
    ++mutex;
}
void consumer()
{
    --mutex;
    --full;
    ++empty;
    cout<<"\ncomsumer consume item "<<x<<endl;
    x--;
    ++mutex;

}
int main()

{
    int n,i;
    cout<<"\n1. press 1 for producer \n2. press 2 for consumer\n3. press 3 foer exit ";

    for(i=1;i>0;i++){
    cout<<"\nEnter your choice ";
    cin>>n;
    switch(n)
    {
    case 1:
        if((mutex==1) && (empty!=0))
        {
             producer();
        }else{
        cout<<"buffer is full!";
        }
        break;

     case 2:
        if((mutex==1) && (full!=0))
        {
             consumer();
        }else{
        cout<<"buffer is empty!";
        }
        break;
     case 3:
        exit(0);
        break;

    }
    }


}

