//Shortest Job First
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,tt=0,min,d;
    float totalTAT=0,totalWT=0,sum=0;
    cout<<"Enter the Process size :";
    cin>>n;
    int at[n],bt[n],ct[n],tat[n],wt[n],temp;
    for(int i=0;i<n;i++)
    {
        cout<<"at[i] :";

        cin>>at[i];
        cout<<"bt[i] :";
        cin>>bt[i];
    }
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(bt[i]>bt[j])
            {
                temp=at[i];
                at[i]=at[j];
                at[j]=temp;

                 temp=bt[i];
                bt[i]=bt[j];
                bt[j]=temp;

            }
        }

    }
    min=at[0];
    for(int i=0;i<n;i++)
    {
        if(min>at[i])
        {
           min=at[i];
           d=i;

        }

    }
    tt=min;
    ct[d]=tt+bt[d];
    tt=ct[d];
     for(int i=0;i<n;i++)
     {
         if(at[i]!=min)
         {
            ct[i]=tt+bt[i];
            tt=ct[i];
         }
     }
     for(int i=0;i<n;i++)
     {
         tat[i]=ct[i]-at[i];
         totalTAT+=tat[i];
         wt[i]=tat[i]-bt[i];
         totalWT+=wt[i];

     }
     cout<<"process"<<'\t'<<" at"<<'\t'<<" bt"<<'\t'<<"tat"<<'\t'<<" wt"<<endl;
     for(int i=0;i<n;i++)
     {
         cout<<"p"<<i+1<<"\t"<<at[i]<<"\t"<<bt[i]<<"\t"<<tat[i]<<"\t"<<wt[i]<<endl;
     }
     cout<<"average tat :"<<totalTAT/n<<'\t'<<"average wt :"<<totalWT/n;

}

