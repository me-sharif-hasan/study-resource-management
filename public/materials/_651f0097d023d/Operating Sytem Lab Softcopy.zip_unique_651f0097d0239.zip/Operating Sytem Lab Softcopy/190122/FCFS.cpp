
#include<bits/stdc++.h>
using namespace std;


int main()
{

    int n,sum=0;
    float totatTAT=0,totalWT=0;
    int at[20]={0},bt[20]={0},ct[20]={0},tat[20]={0},wt[20]={0};
    cout<<"enter number of process :";
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cout<<"at : ";
        cin>>at[i];

    }
    for(int i=0;i<n;i++)
    {
        cout<<"bt : ";
        cin>>bt[i];

    }
    for(int j=0;j<n;j++)
    {
        sum+=bt[j];
        ct[j]+=sum;
    }
    for(int k=0;k<n;k++)
    {
        tat[k]=ct[k]-at[k];
        totatTAT+=tat[k];
        wt[k]=tat[k]-bt[k];
        totalWT+=wt[k];
    }

    cout<<"PN"<<'\t'<<"AT"<<'\t'<<"BT"<<'\t'<<"CT"<<'\t'<<"TAT"<<'\t'<<"WT"<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<i+1<<"\t"<<at[i]<<"\t"<<bt[i]<<"\t"<<ct[i]<<"\t"<<tat[i]<<"\t"<<wt[i]<<endl;
    }cout<<endl;
    cout<<"Average tat :"<<totatTAT/n<<endl;
    cout<<"Average wt :"<<totalWT/n<<endl;

}
