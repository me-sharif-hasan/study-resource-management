from threading import Thread

x = 0

def signal():
    global x
    for i in range(100):
        x += 1
        print(x)

def wait():
    global x
    for i in range(100):
        x -= 1
        print(x)

def main():
    thread1 = Thread(target=signal)
    thread2 = Thread(target=wait)

    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()

    print(x)


if __name__ == '__main__':
    main()