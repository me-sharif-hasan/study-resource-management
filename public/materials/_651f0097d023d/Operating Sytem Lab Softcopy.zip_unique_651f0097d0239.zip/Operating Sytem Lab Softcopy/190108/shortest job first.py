def main():
    number_of_process = int(input('Enter the number of process : '))
    print(f'Enter {number_of_process} processes arrival time and brust time.')
    process_info = []
    total_brust_time = 0
    for i in range(number_of_process):
        process_name=input(f'Enter {i+1}th process name : ')
        arrival_time=int(input(f'Enter {i+1}th arrival time : '))
        brust_time=int(input(f'Enter {i+1}th brust time : '))
        total_brust_time+=brust_time
        process_info.append((process_name,arrival_time,brust_time))
    
    process_info.sort(key= lambda x: x[2]+x[1])
    
    print(process_info)

    process_name = [x[0] for x in process_info]
    arrival_time = [x[1] for x in process_info]
    brust_time = [x[2] for x in process_info]


    total_waiting_time = 0
    total_turn_around_time = brust_time[0]
    program_start = arrival_time[0]
    program_finished = brust_time[0]
    print('Prog. Name \t Arrival Time \t Burst Time \t Start \t Waiting \t TAT \t Finish')
    for i in range(number_of_process):
        if i==0:
            print(f'{process_name[i]}\t {arrival_time[i]}\t {brust_time[i]}\t \
                  {program_start}\t {arrival_time[i]}\t {brust_time[i]}\t {brust_time[i]}')
        else:
            program_finished+= brust_time[i]
            program_start+=brust_time[i-1]
            print(f'{process_name[i]}\t {arrival_time[i]}\t {brust_time[i]}\t \
                  {program_start}\t {program_finished- arrival_time[i] - brust_time[i]}\t {program_finished- arrival_time[i]}\t {program_finished}')
            
            total_turn_around_time+=(program_finished- arrival_time[i])
            total_waiting_time += (program_start - arrival_time[i])
    
    print(f'Average waiting time {total_waiting_time/number_of_process}')
    print(f'Average turn around time {total_turn_around_time/number_of_process}')

if __name__ == '__main__':
    main()


    
