def main():
    total_p_no = int(input('Enter Total Process Number: '))
    total_time = 0 
    total_time_counted = 0
    proc = []
    wait_time = 0
    turnaround_time = 0
    for _ in range(total_p_no):
        input_info = list(map(int, input('Enter process arrival time and burst time').split(" ")))
        arrival, burst, remaining_time = input_info[0], input_info[1], input_info[1]
        proc.append([arrival, burst, remaining_time, 0])
        total_time += burst
    time_quantum = int(input('Enter time quantum'))
    while total_time != 0:
        for i in range(len(proc)):
            if proc[i][2] <= time_quantum and proc[i][2] >= 0:
                total_time_counted += proc[i][2]
                total_time -= proc[i][2]
                proc[i][2] = 0 
            elif proc[i][2] > 0:
                proc[i][2] -= time_quantum
                total_time -= time_quantum
                total_time_counted += time_quantum
            if proc[i][2] == 0 and proc[i][3] != 1:
                wait_time += total_time_counted - proc[i][0] - proc[i][1]
                turnaround_time += total_time_counted - proc[i][0]
                proc[i][3] = 1 
    print("\nAvg Waiting Time is ", (wait_time * 1) / total_p_no)
    print("Avg Turnaround Time is ", (turnaround_time * 1) / total_p_no)

if __name__ == '__main__':
    main()