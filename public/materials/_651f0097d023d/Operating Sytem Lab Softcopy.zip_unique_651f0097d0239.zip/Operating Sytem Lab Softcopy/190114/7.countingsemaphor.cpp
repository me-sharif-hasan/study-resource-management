
#include<bits/stdc++.h>
using namespace std;
class CountingSemaphore {
public:
    CountingSemaphore(int count) : count_(count) {}

    void Acquire() {
        std::unique_lock<std::mutex> lock(mutex_);
        while (count_ <= 0) {
            condition_.wait(lock);
        }
        count_--;
    }

    void Release() {
        std::unique_lock<std::mutex> lock(mutex_);
        count_++;
        condition_.notify_one();
    }

private:
    int count_;
    std::mutex mutex_;
    std::condition_variable condition_;
};

int main() {
    CountingSemaphore semaphore(3); // Initialize with a count of 3

    // Create multiple threads to demonstrate semaphore usage
    std::thread t1([&semaphore]() {
        semaphore.Acquire();
        std::cout << "Thread 1 acquired the semaphore" << std::endl;
        // Simulate some work
        std::this_thread::sleep_for(std::chrono::seconds(2));
        semaphore.Release();
        std::cout << "Thread 1 released the semaphore" << std::endl;
    });

    std::thread t2([&semaphore]() {
        semaphore.Acquire();
        std::cout << "Thread 2 acquired the semaphore" << std::endl;
        // Simulate some work
        std::this_thread::sleep_for(std::chrono::seconds(1));
        semaphore.Release();
        std::cout << "Thread 2 released the semaphore" << std::endl;
    });

    std::thread t3([&semaphore]() {
        semaphore.Acquire();
        std::cout << "Thread 3 acquired the semaphore" << std::endl;
        // Simulate some work
        std::this_thread::sleep_for(std::chrono::seconds(3));
        semaphore.Release();
        std::cout << "Thread 3 released the semaphore" << std::endl;
    });

    t1.join();
    t2.join();
    t3.join();

    return 0;
}
