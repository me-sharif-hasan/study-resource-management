#include<bits/stdc++.h>
using namespace std;

int main()
{
    queue<int>buffer;
    int produce=0,n,option,var;
   // cout<<"Enter the buffer size"<<endl;
    //cin>>n;
    while(true){
    cout<<endl;
    cout<<endl;
    cout<<"Choose option"<<endl<<"1.Produce"<<endl<<"2.Consume"<<endl<<"3.exit"<<endl<<endl;
    cin>>option;
    if(option == 1){

            cout<<"Enter shared variable:"<<endl;
            cin>>var;
            buffer.push(var);
            produce++;
            cout<<"Producer insert variable "<<var<<" into buffer"<<endl;

    }
    else if(option == 2){
        if(produce>0){
            var = buffer.front();
            buffer.pop();
            cout<<"Consumer get "<<var<<" from buffer"<<endl;
            produce--;
        }
        else{
            cout<<"Buffer is empty!!!"<<endl;
        }
    }else if(option == 3){
         break;
    }
    else{
        cout<<"Enter valid option!!!"<<endl;
    }
    }

    return 0;


}
