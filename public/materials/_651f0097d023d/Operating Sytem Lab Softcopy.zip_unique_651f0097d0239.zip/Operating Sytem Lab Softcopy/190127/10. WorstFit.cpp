#include<iostream>
using namespace std;

int main()
{
    int fragment[20], blockSize[20], processSize[20], i, j, blockNo, processNo, temp, largest = -1;
    static int barray[20], parray[20];

    cout << "\nEnter the number of blocks:";
    cin >> blockNo;
    cout << "\nEnter the size of the blocks:\n";
    for (i = 1; i <= blockNo; i++)
    {
        cin >> blockSize[i];
    }

    cout << "Enter the number of processes:";
    cin >> processNo;
    cout << "\nEnter the size of the processes :\n";
    for (i = 1; i <= processNo; i++)
    {
        cin >> processSize[i];
    }

    for (i = 1; i <= processNo; i++)
    {
        largest = -1; // Initialize to an invalid index
        for (j = 1; j <= blockNo; j++)
        {
            if (barray[j] != 1)
            {
                temp = blockSize[j] - processSize[i];
                if (temp >= 0)
                {
                    if (largest == -1 || blockSize[j] > blockSize[largest])
                    {
                        parray[i] = j;
                        largest = j;
                    }
                }
            }
        }
        if (largest != -1)
        {
            fragment[i] = blockSize[largest] - processSize[i];
            barray[parray[i]] = 1;
        }
    }

    cout << "\nProcess_no\tProcess_size\tBlock_no\tBlock_size\tFragment";
    for (i = 1; i <= processNo && parray[i] != 0; i++)
        cout << "\n" << i << "\t\t" << processSize[i] << "\t\t" << parray[i] << "\t\t" << blockSize[parray[i]] << "\t\t" << fragment[i];
    return 0;
}
