#include <iostream>
#include <mutex>
#include <condition_variable>

class Semaphore {
public:
    int readers;
    int writers;
    std::mutex mutex;
    std::condition_variable read_cv;
    std::condition_variable write_cv;

    Semaphore() : readers(0), writers(0) {}

    void addReader() {
        std::unique_lock<std::mutex> lock(mutex);
        read_cv.wait(lock, [this] { return writers == 0; });
        readers++;
        lock.unlock();
    }

    void removeReader() {
        std::unique_lock<std::mutex> lock(mutex);
        readers--;
        if (readers == 0) {
            write_cv.notify_one();
        }
    }

    void addWriter() {
        std::unique_lock<std::mutex> lock(mutex);
        writers++;
        write_cv.wait(lock, [this] { return readers == 0 && writers == 1; });
    }

    void removeWriter() {
        std::unique_lock<std::mutex> lock(mutex);
        writers--;
        read_cv.notify_all();
        write_cv.notify_one();
    }
};

Semaphore S1;

void addR() {
    S1.addReader();
    std::cout << "Reader added.\n";
}

void addW() {
    S1.addWriter();
    std::cout << "Writer added.\n";
}

void remR() {
    S1.removeReader();
    std::cout << "Reader removed.\n";
}

void remW() {
    S1.removeWriter();
    std::cout << "Writer removed.\n";
}

int main() {
    int ch;

    do {
        std::cout << "Options:\n1. Add Reader\n2. Add Writer\n3. Remove Reader\n4. Remove Writer\n5. Exit\n\nChoice: ";
        std::cin >> ch;

        switch(ch) {
            case 1: addR(); break;
            case 2: addW(); break;
            case 3: remR(); break;
            case 4: remW(); break;
            case 5: std::cout << "\nGoodbye!\n"; break;
            default: std::cout << "\nInvalid Entry!\n";
        }
    } while (ch != 5);

    return 0;
}
