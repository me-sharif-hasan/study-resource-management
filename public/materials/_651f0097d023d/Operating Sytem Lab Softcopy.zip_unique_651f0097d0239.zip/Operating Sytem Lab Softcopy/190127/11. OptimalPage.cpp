#include<iostream>
#include<limits.h>
using namespace std;

int main()
{
    int frames, pages;

    cout << "Enter the number of frames: ";
    cin >> frames;

    cout << "Enter the number of pages: ";
    cin >> pages;

    int pageSequence[pages];
    cout << "Enter the page sequence:\n";
    for (int i = 0; i < pages; i++)
    {
        cin >> pageSequence[i];
    }

    int frameBuffer[frames];
    for (int i = 0; i < frames; i++)
    {
        frameBuffer[i] = -1; // Initialize all frames as empty (-1)
    }

    int pageFaults = 0;
    int pageHits = 0;
    for (int i = 0; i < pages; i++)
    {
        bool pageFound = false;
        for (int j = 0; j < frames; j++)
        {
            if (frameBuffer[j] == pageSequence[i])
            {
                pageFound = true;
                pageHits++;
                break;
            }
        }

        if (!pageFound)
        {
            int indexToReplace = -1;
            int farthestIndex = -1;
            for (int j = 0; j < frames; j++)
            {
                bool foundInFuture = false;
                for (int k = i + 1; k < pages; k++)
                {
                    if (frameBuffer[j] == pageSequence[k])
                    {
                        foundInFuture = true;
                        if (k > farthestIndex)
                        {
                            farthestIndex = k;
                            indexToReplace = j;
                        }
                        break;
                    }
                }
                if (!foundInFuture)
                {
                    indexToReplace = j;
                    break;
                }
            }

            if (indexToReplace != -1)
            {
                frameBuffer[indexToReplace] = pageSequence[i];
                pageFaults++;
            }
        }
    }
    cout << "Total Page Hits: " << pageHits << endl;
    cout << "Total Page Faults: " << pageFaults << endl;

    return 0;

}
