#include<bits/stdc++.h>
using namespace std;

int main() {
    int bt[20], at[10], n, i, j, temp, p[10], st[10], ct[10], wt[10], ta[10];

    int totwt = 0, totta = 0;
    float awt, ata;
    char pn[10][10], t[10];

    cout << "Enter the number of process: ";
    cin >> n;
    for (i = 0; i < n; i++) {
        cout << "Enter process name, priority, arrival time, burst time: ";
        cin >> pn[i] >> p[i]>> at[i] >> bt[i];
    }

    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) {
            if (p[i] < p[j]) {
                temp = p[i];
                p[i] = p[j];
                p[j] = temp;

                temp = at[i];
                at[i] = at[j];
                at[j] = temp;

                temp = bt[i];
                bt[i] = bt[j];
                bt[j] = temp;

                strcpy(t, pn[i]);
                strcpy(pn[i], pn[j]);
                strcpy(pn[j], t);
            }
        }

    for (i = 0; i < n; i++) {
        if (i == 0) {
            st[i] = at[i];
            //wt[i] = st[i] - at[i];
            ct[i] = st[i] + bt[i];
            ta[i] = ct[i] - at[i];
            wt[i] = ta[i] - bt[i];
        }
        else {
            st[i] = ct[i - 1];
            //wt[i] = st[i] - at[i];
            ct[i] = st[i] + bt[i];
            ta[i] = ct[i] - at[i];
            wt[i] = ta[i] - bt[i];
        }
        totwt += wt[i];
        totta += ta[i];
    }

    awt = (float)totwt / n;
    ata = (float)totta / n;

    cout << "\nPname\tarrivaltime\tbursttime\tpriority\twaitingtime\ttatime";
    for (i = 0; i < n; i++)
        cout << "\n" << pn[i] << "\t" << at[i] << "\t\t" << bt[i] << "\t\t" << p[i] << "\t\t" << wt[i] << "\t\t" << ta[i];
    cout << "\nAverage waiting time is: " << awt;
    cout << "\nAverage turnaround time is: " << ata;
    return 0;
}

