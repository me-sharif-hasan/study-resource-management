#include <iostream>
#include <limits.h>
using namespace std;

int main()
{
    int frames, pages;

    cout << "Enter the number of frames: ";
    cin >> frames;

    cout << "Enter the number of pages: ";
    cin >> pages;

    int pageSequence[pages];
    cout << "Enter the page sequence:\n";
    for (int i = 0; i < pages; i++)
    {
        cin >> pageSequence[i];
    }

    int frameBuffer[frames];
    int usedOrder[frames];
    for (int i = 0; i < frames; i++)
    {
        frameBuffer[i] = -1; // Initialize all frames as empty (-1)
        usedOrder[i] = 0;    // Initialize the used order for each frame
    }

    int pageFaults = 0;
    int pageHits = 0;

    for (int i = 0; i < pages; i++)
    {
        bool pageFound = false;
        for (int j = 0; j < frames; j++)
        {
            if (frameBuffer[j] == pageSequence[i])
            {
                pageFound = true;
                pageHits++;
                usedOrder[j] = i + 1; // Update the used order for the page
                break;
            }
        }

        if (!pageFound)
        {
            int lruIndex = 0;
            int oldestUsed = usedOrder[0];
            for (int j = 1; j < frames; j++)
            {
                if (usedOrder[j] < oldestUsed)
                {
                    lruIndex = j;
                    oldestUsed = usedOrder[j];
                }
            }

            frameBuffer[lruIndex] = pageSequence[i];
            usedOrder[lruIndex] = i + 1;
            pageFaults++;
        }


    }

    cout << "Total Page Hits: " << pageHits << endl;
    cout << "Total Page Faults: " << pageFaults << endl;

    return 0;
}
