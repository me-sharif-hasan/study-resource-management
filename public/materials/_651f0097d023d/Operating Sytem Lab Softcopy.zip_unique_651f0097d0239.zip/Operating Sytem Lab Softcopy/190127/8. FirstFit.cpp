#include<iostream>
using namespace std;

int main()
{
    int blockSize[10], processSize[10], blockNo, processNo, flags[10], allocation[10], i, j;

    for(i = 0; i < 10; i++)
    {
        flags[i] = 0;
        allocation[i] = -1;
    }

    cout<<"Enter no. of blocks: ";
    cin>>blockNo;
    cout<<"\nEnter size of each block: ";
    for(i = 0; i < blockNo; i++)
        cin>>blockSize[i];

    cout<<"\nEnter no. of processes: ";
    cin>>processNo;
    cout<<"\nEnter size of each process: ";
    for(i = 0; i < processNo; i++)
        cin>>processSize[i];

    for(i = 0; i < processNo; i++)
        for(j = 0; j < blockNo; j++)
            if(flags[j] == 0 && blockSize[j] >= processSize[i])
            {
                allocation[j] = i;
                flags[j] = 1;
                break;
            }

    cout<<"\nBlock no.\tsize\t\tprocess no.\t\tsize";
    for(i = 0; i < blockNo; i++)
    {
        cout<<"\n"<< i+1<<"\t\t"<<blockSize[i]<<"\t\t";
        if(flags[i] == 1)
            cout<<allocation[i]+1<<"\t\t\t"<<processSize[allocation[i]];
        else
            cout<<"Not allocated";
    }
    return 0;
}
