#include <iostream>
#include <cmath>

using namespace std;

int gcd(int a, int h) {
    int temp;
    while (1) {
        temp = a % h;
        if (temp == 0)
            return h;
        a = h;
        h = temp;
    }
}

int main() {
    double p, q;

    cout << "Enter two prime numbers (p and q): ";
    cin >> p >> q;

int need[n][m];
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
            need[i][j] = Max[i][j] - alloc[i][j];
    }    double n = p * q;
    double count;
    double phi = (p - 1) * (q - 1);

    double e = 2;
    while (e < phi) {
        count = gcd(e, phi);
        if (count == 1)
            break;
        else
            e++;
    }

    double d;
    double k = 2;
    d = (1 + (k * phi)) / e;

    double msg;
    cout << "Enter the message to encrypt: ";
    cin >> msg;

    double c = fmod(pow(msg, e), n);
    double m = fmod(pow(c, d), n);

    cout << "Message data = " << msg << endl;
    cout << "p = " << p << endl;
    cout << "q = " << q << endl;
    cout << "n = pq = " << n << endl;
    cout << "phi = " << phi << endl;
    cout << "e = " << e << endl;
    cout << "d = " << d << endl;
    cout << "Encrypted data = " << c << endl;
    cout << "Original Message sent = " << m << endl;

    return 0;
}

