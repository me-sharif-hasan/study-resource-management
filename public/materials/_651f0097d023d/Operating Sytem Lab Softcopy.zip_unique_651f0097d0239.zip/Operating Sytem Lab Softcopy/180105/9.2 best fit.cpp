#include <bits/stdc++.h>
using namespace std;

void NextFit(int b_size[], int m, int p_size[], int n)
{
   int allocation[n], j = 0;


    memset(allocation, -1, sizeof(allocation));

    for (int i = 0; i < n; i++) {


        while (j < m) {


            if (b_size[j] >= p_size[i]) {

                allocation[i] = j;

                b_size[j] -= p_size[i];

                break;

            }


            j = (j + 1) % m;
        }
    }


    cout << "\nProcess Number\tProcess Size\tBlock Number \n";
    for (int i = 0; i < n; i++) {

        cout << " " << i + 1 << "\t\t" << p_size[i]
             << "\t\t";

        if (allocation[i] != -1)
            cout << allocation[i] + 1;
        else

            cout << "Not Allocated";

        cout<< endl;

    }
}

// Driver program
int main()
{
    int b_size[] = { 5, 10, 20 };
    int p_size[] = { 10, 20, 5 };
    int m = sizeof(b_size) / sizeof(b_size[0]);
    int n = sizeof(p_size) / sizeof(p_size[0]);


    NextFit(b_size, m, p_size, n);

    return 0;
}
