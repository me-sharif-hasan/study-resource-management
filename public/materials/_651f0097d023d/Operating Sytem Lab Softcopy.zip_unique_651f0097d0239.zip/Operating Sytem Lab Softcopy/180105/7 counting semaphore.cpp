#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

class CountingSemaphore {
public:
    CountingSemaphore(int count) : count_(count) {}

    void acquire() {
        std::unique_lock<std::mutex> lock(mutex_);
        while (count_ == 0) {
            condition_.wait(lock);
        }
        count_--;
    }

    void release() {
        std::unique_lock<std::mutex> lock(mutex_);
        count_++;
        condition_.notify_one();
    }

private:
    int count_;
    std::mutex mutex_;
    std::condition_variable condition_;
};

const int MAX_THREADS = 5;
CountingSemaphore semaphore(2); // Initialize with a count of 2

void worker(int id) {
    semaphore.acquire();
    std::cout << "Thread " << id << " acquired the semaphore." << std::endl;
    // Simulate some work
    std::this_thread::sleep_for(std::chrono::seconds(2));
    semaphore.release();
    std::cout << "Thread " << id << " released the semaphore." << std::endl;
}

int main() {
    std::thread threads[MAX_THREADS];

    for (int i = 0; i < MAX_THREADS; ++i) {
        threads[i] = std::thread(worker, i);
    }

    for (int i = 0; i < MAX_THREADS; ++i) {
        threads[i].join();
    }

    return 0;
}

